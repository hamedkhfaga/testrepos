package org.apache.ofbiz.payroll;

import org.apache.ofbiz.entity.*;
import org.apache.ofbiz.entity.util.EntityQuery;
import org.apache.ofbiz.service.*;
import org.apache.ofbiz.base.util.*;

import java.math.BigDecimal;
import java.util.*;

public class PayrollPostingServices {

    /* ===================================================== */
    /* Post Payroll to GL                                    */
    /* ===================================================== */

    public static Map<String, Object> postPayrollToGL(
            DispatchContext dctx, Map<String, ?> context) throws GenericEntityException {

        Delegator delegator = dctx.getDelegator();
        LocalDispatcher dispatcher = dctx.getDispatcher();

        String payrollRunId = (String) context.get("payrollRunId");

        List<GenericValue> items = EntityQuery.use(delegator)
                .from("PayrollRunItem")
                .where("payrollRunId", payrollRunId)
                .queryList();

        for (GenericValue item : items) {

            Map<String, Object> glCtx = UtilMisc.toMap(
                    "glJournalName", "Payroll Run " + payrollRunId,
                    "organizationPartyId", item.get("organizationPartyId"),
                    "accountingTransactionTypeId", "PAYROLL",
                    "transactionDate", UtilDateTime.nowTimestamp(),
                    "debitCreditFlag", "D",
                    "amount", item.getBigDecimal("netAmount"),
                    "userLogin", context.get("userLogin")
            );

            dispatcher.runSync("createAcctgTransAndEntries", glCtx);
        }

        return ServiceUtil.returnSuccess("Posted to GL");
    }

    /* ===================================================== */
    /* Post Payroll to AP Invoice                            */
    /* ===================================================== */

    public static Map<String, Object> postPayrollToInvoice(
            DispatchContext dctx, Map<String, ?> context) throws GenericEntityException {

        Delegator delegator = dctx.getDelegator();
        LocalDispatcher dispatcher = dctx.getDispatcher();

        String payrollRunId = (String) context.get("payrollRunId");

        List<GenericValue> items = EntityQuery.use(delegator)
                .from("PayrollRunItem")
                .where("payrollRunId", payrollRunId)
                .queryList();

        for (GenericValue item : items) {

            Map<String, Object> invCtx = UtilMisc.toMap(
                    "invoiceTypeId", "PAYROLL_AP",
                    "partyIdFrom", item.get("organizationPartyId"),
                    "partyId", item.get("partyId"),
                    "invoiceDate", UtilDateTime.nowTimestamp(),
                    "currencyUomId", "USD",
                    "userLogin", context.get("userLogin")
            );

            dispatcher.runSync("createInvoice", invCtx);
        }

        return ServiceUtil.returnSuccess("Posted to Invoice");
    }
}
