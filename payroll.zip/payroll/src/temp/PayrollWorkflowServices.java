package org.apache.ofbiz.payroll.services;

import org.apache.ofbiz.base.util.Debug;
import org.apache.ofbiz.base.util.UtilDateTime;
import org.apache.ofbiz.base.util.UtilValidate;

import org.apache.ofbiz.entity.Delegator;
import org.apache.ofbiz.entity.GenericEntityException;
import org.apache.ofbiz.entity.GenericValue;
import org.apache.ofbiz.entity.util.EntityQuery;

import org.apache.ofbiz.service.DispatchContext;
import org.apache.ofbiz.service.ServiceUtil;

import java.sql.Timestamp;
import java.util.Map;

public class PayrollWorkflowServices {
    public static final String MODULE = PayrollWorkflowServices.class.getName();

    // You will create these StatusItem values under a StatusType like PAY_RUN_STATUS:
    // PAY_RUN_DRAFT, PAY_RUN_SUBMITTED, PAY_RUN_APPROVED, PAY_RUN_REJECTED, PAY_RUN_LOCKED
    private static final String STATUS_DRAFT = "PAY_RUN_DRAFT";
    private static final String STATUS_SUBMITTED = "PAY_RUN_SUBMITTED";
    private static final String STATUS_APPROVED = "PAY_RUN_APPROVED";
    private static final String STATUS_REJECTED = "PAY_RUN_REJECTED";
    private static final String STATUS_LOCKED = "PAY_RUN_LOCKED";

    private static GenericValue getRun(Delegator delegator, String orgPartyId, String payrollRunId) throws GenericEntityException {
        GenericValue run = EntityQuery.use(delegator)
                .from("PayrollRun")
                .where("payrollRunId", payrollRunId, "orgPartyId", orgPartyId)
                .queryOne();
        if (run == null) throw new GenericEntityException("PayrollRun not found: " + payrollRunId);
        return run;
    }

    public static Map<String, Object> submitPayrollRun(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        try {
            String orgPartyId = (String) context.get("orgPartyId");
            String payrollRunId = (String) context.get("payrollRunId");
            if (UtilValidate.isEmpty(orgPartyId) || UtilValidate.isEmpty(payrollRunId)) {
                return ServiceUtil.returnError("orgPartyId and payrollRunId are required");
            }

            GenericValue run = getRun(delegator, orgPartyId, payrollRunId);
            String statusId = run.getString("statusId");

            if (UtilValidate.isEmpty(statusId)) statusId = STATUS_DRAFT;

            // Only allow submit from draft/rejected
            if (!(STATUS_DRAFT.equals(statusId) || STATUS_REJECTED.equals(statusId))) {
                return ServiceUtil.returnError("Cannot submit run in status: " + statusId);
            }

            run.set("statusId", STATUS_SUBMITTED);
            run.store();

            return ServiceUtil.returnSuccess();
        } catch (Exception e) {
            Debug.logError(e, MODULE);
            return ServiceUtil.returnError("submitPayrollRun failed: " + e.getMessage());
        }
    }

    public static Map<String, Object> approvePayrollRun(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        try {
            String orgPartyId = (String) context.get("orgPartyId");
            String payrollRunId = (String) context.get("payrollRunId");
            if (UtilValidate.isEmpty(orgPartyId) || UtilValidate.isEmpty(payrollRunId)) {
                return ServiceUtil.returnError("orgPartyId and payrollRunId are required");
            }

            GenericValue run = getRun(delegator, orgPartyId, payrollRunId);
            String statusId = run.getString("statusId");

            if (!STATUS_SUBMITTED.equals(statusId)) {
                return ServiceUtil.returnError("Only SUBMITTED runs can be approved. Current: " + statusId);
            }

            run.set("statusId", STATUS_APPROVED);
            run.set("approvedDate", UtilDateTime.nowTimestamp());
            // approvedByUserLoginId should come from service context if you pass userLogin
            run.store();

            return ServiceUtil.returnSuccess();
        } catch (Exception e) {
            Debug.logError(e, MODULE);
            return ServiceUtil.returnError("approvePayrollRun failed: " + e.getMessage());
        }
    }

    public static Map<String, Object> rejectPayrollRun(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        try {
            String orgPartyId = (String) context.get("orgPartyId");
            String payrollRunId = (String) context.get("payrollRunId");
            String reason = (String) context.get("reason");

            if (UtilValidate.isEmpty(orgPartyId) || UtilValidate.isEmpty(payrollRunId)) {
                return ServiceUtil.returnError("orgPartyId and payrollRunId are required");
            }

            GenericValue run = getRun(delegator, orgPartyId, payrollRunId);
            String statusId = run.getString("statusId");

            if (!(STATUS_SUBMITTED.equals(statusId) || STATUS_APPROVED.equals(statusId))) {
                return ServiceUtil.returnError("Run can be rejected only from SUBMITTED/APPROVED. Current: " + statusId);
            }

            run.set("statusId", STATUS_REJECTED);
            if (UtilValidate.isNotEmpty(reason)) {
                run.set("runName", (run.getString("runName") == null ? "" : run.getString("runName")) + " [REJECTED]");
            }
            run.store();

            return ServiceUtil.returnSuccess();
        } catch (Exception e) {
            Debug.logError(e, MODULE);
            return ServiceUtil.returnError("rejectPayrollRun failed: " + e.getMessage());
        }
    }

    public static Map<String, Object> lockPayrollRun(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        try {
            String orgPartyId = (String) context.get("orgPartyId");
            String payrollRunId = (String) context.get("payrollRunId");

            if (UtilValidate.isEmpty(orgPartyId) || UtilValidate.isEmpty(payrollRunId)) {
                return ServiceUtil.returnError("orgPartyId and payrollRunId are required");
            }

            GenericValue run = getRun(delegator, orgPartyId, payrollRunId);
            String statusId = run.getString("statusId");

            if (!STATUS_APPROVED.equals(statusId)) {
                return ServiceUtil.returnError("Only APPROVED runs can be locked. Current: " + statusId);
            }

            run.set("statusId", STATUS_LOCKED);
            run.store();

            return ServiceUtil.returnSuccess();
        } catch (Exception e) {
            Debug.logError(e, MODULE);
            return ServiceUtil.returnError("lockPayrollRun failed: " + e.getMessage());
        }
    }

public static Map<String, Object> generatePayslipPdf(
        DispatchContext dctx, Map<String, ?> context) throws Exception {

    Delegator delegator = dctx.getDelegator();
    String payrollRunItemId = (String) context.get("payrollRunItemId");

    GenericValue item = delegator.findOne(
            "PayrollRunItem",
            UtilMisc.toMap("payrollRunItemId", payrollRunItemId),
            false
    );

    if (item == null) {
        return ServiceUtil.returnError("PayrollRunItem not found");
    }

    String employeeId = item.getString("partyId");
    String period = item.getString("payPeriod");
    String netAmount = item.getBigDecimal("netAmount").toPlainString();

    GenericValue person = EntityQuery.use(delegator)
            .from("Person")
            .where("partyId", employeeId)
            .queryOne();

    String employeeName =
            person.getString("firstName") + " " + person.getString("lastName");

    // Barcode value (unique + verifiable)
    String barcodeValue = employeeId + "-" + payrollRunItemId;

    // Build FO
    String foContent = PayslipFoBuilder.buildFo(
            employeeName, employeeId, period, barcodeValue, netAmount
    );

    // Output file
    String outputDir = "runtime/payslips/";
    String pdfFile = outputDir + "payslip_" + payrollRunItemId + ".pdf";

    // Render PDF via FOP
    FopFactory fopFactory = FopFactory.newInstance(new File(".").toURI());
    FOUserAgent foUserAgent = fopFactory.newFOUserAgent();

    try (OutputStream out = new FileOutputStream(pdfFile)) {
        Fop fop = fopFactory.newFop(MimeConstants.MIME_PDF, foUserAgent, out);

        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer transformer = tf.newTransformer();

        Source src = new StreamSource(new StringReader(foContent));
        Result res = new SAXResult(fop.getDefaultHandler());

        transformer.transform(src, res);
    }

    Map<String, Object> result = ServiceUtil.returnSuccess();
    result.put("pdfFile", pdfFile);
    return result;
}





}
