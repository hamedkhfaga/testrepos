package org.apache.ofbiz.payroll;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.*;

import org.apache.ofbiz.base.util.*;
import org.apache.ofbiz.entity.*;
import org.apache.ofbiz.entity.condition.*;
import org.apache.ofbiz.entity.util.EntityQuery;

import org.apache.ofbiz.service.*;
import org.apache.ofbiz.entity.transaction.TransactionUtil;

public final class PayrollPostingServices {
    public static final String MODULE = PayrollPostingServices.class.getName();

    private PayrollPostingServices() {}

    public static Map<String, Object> postPayrollRunToGl(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        LocalDispatcher dispatcher = dctx.getDispatcher();

        String payrollRunId = (String) context.get("payrollRunId");
        String acctgTransTypeId = (String) context.get("acctgTransTypeId");
        Boolean forceRepost = (Boolean) context.get("forceRepost");
        GenericValue userLogin = (GenericValue) context.get("userLogin");

        if (forceRepost == null) forceRepost = Boolean.FALSE;
        if (UtilValidate.isEmpty(payrollRunId)) return ServiceUtil.returnError("payrollRunId is required");
        if (UtilValidate.isEmpty(acctgTransTypeId)) acctgTransTypeId = "MANUAL_ACCTG_TRANS";

        boolean beganTx = false;
        try {
            beganTx = TransactionUtil.begin();

            GenericValue run = EntityQuery.use(delegator).from("PayrollRun").where("payrollRunId", payrollRunId).queryOne();
            if (run == null) return ServiceUtil.returnError("PayrollRun not found: " + payrollRunId);

            if (!"PAYRUN_APPROVED".equals(run.getString("statusId"))) {
                return ServiceUtil.returnError("PayrollRun must be APPROVED before posting to GL.");
            }

            if ("Y".equals(run.getString("isGlPosted")) && !forceRepost) {
                Map<String, Object> ok = ServiceUtil.returnSuccess("Already posted to GL.");
                ok.put("glJournalId", run.getString("glJournalId"));
                return ok;
            }

            String orgPartyId = run.getString("orgPartyId");
            String currencyUomId = run.getString("currencyUomId");

            // Aggregate amounts by GL account + DR/CR using PayrollGlMapping per lineTypeId
            List<GenericValue> lines = EntityQuery.use(delegator).from("EmployeePayrollResultLine")
                    .where(EntityCondition.makeCondition("payrollResultId", EntityOperator.IN,
                            EntityQuery.use(delegator).from("EmployeePayrollResult")
                                    .where("payrollRunId", payrollRunId)
                                    .queryList()
                                    .stream().map(r -> r.getString("payrollResultId")).toList()
                    ))
                    .queryList();

            Map<String, BigDecimal> drSums = new HashMap<>();
            Map<String, BigDecimal> crSums = new HashMap<>();

            for (GenericValue l : lines) {
                String lineTypeId = l.getString("lineTypeId");
                BigDecimal amt = l.getBigDecimal("amount");
                if (amt == null) amt = BigDecimal.ZERO;
                if (amt.signum() == 0) continue;

                GenericValue map = findActiveGlMapping(delegator, orgPartyId, lineTypeId);
                if (map == null) continue; // strict teams may prefer error; adjust if you want hard enforcement

                String glAccountId = map.getString("glAccountId");
                String drCrFlag = map.getString("drCrFlag");

                BigDecimal abs = amt.abs();
                if ("DR".equals(drCrFlag)) drSums.put(glAccountId, drSums.getOrDefault(glAccountId, BigDecimal.ZERO).add(abs));
                else crSums.put(glAccountId, crSums.getOrDefault(glAccountId, BigDecimal.ZERO).add(abs));
            }

            // Must balance
            BigDecimal drTotal = drSums.values().stream().reduce(BigDecimal.ZERO, BigDecimal::add);
            BigDecimal crTotal = crSums.values().stream().reduce(BigDecimal.ZERO, BigDecimal::add);
            if (drTotal.compareTo(crTotal) != 0) {
                return ServiceUtil.returnError("GL posting not balanced. DR=" + drTotal + " CR=" + crTotal
                        + ". Fix PayrollGlMapping or result lines.");
            }

            // Create AcctgTrans
            String transId = delegator.getNextSeqId("AcctgTrans");
            Timestamp now = UtilDateTime.nowTimestamp();

            // If you have a standard OFBiz service, prefer it. Here we create directly for portability.
            GenericValue trans = delegator.makeValue("AcctgTrans");
            trans.set("acctgTransId", transId);
            trans.set("acctgTransTypeId", acctgTransTypeId);
            trans.set("transactionDate", now);
            trans.set("entryDate", now);
            trans.set("description", "Payroll Run " + payrollRunId);
            trans.set("createdByUserLogin", userLogin.getString("userLoginId"));
            trans.set("postedDate", now);
            delegator.create(trans);

            // Entries (DR)
            long seq = 1;
            for (Map.Entry<String, BigDecimal> e : drSums.entrySet()) {
                createAcctgTransEntry(delegator, transId, seq++, orgPartyId, e.getKey(), currencyUomId, e.getValue(), BigDecimal.ZERO);
            }
            // Entries (CR)
            for (Map.Entry<String, BigDecimal> e : crSums.entrySet()) {
                createAcctgTransEntry(delegator, transId, seq++, orgPartyId, e.getKey(), currencyUomId, BigDecimal.ZERO, e.getValue());
            }

            run.set("glJournalId", transId);
            run.set("glPostedDate", now);
            run.set("isGlPosted", "Y");
            delegator.store(run);

            TransactionUtil.commit(beganTx);

            Map<String, Object> ok = ServiceUtil.returnSuccess("Posted to GL.");
            ok.put("glJournalId", transId);
            return ok;

        } catch (Exception e) {
            Debug.logError(e, "postPayrollRunToGl failed", MODULE);
            try { TransactionUtil.rollback(beganTx, e.getMessage(), e); } catch (Exception ignored) {}
            return ServiceUtil.returnError("postPayrollRunToGl failed: " + e.getMessage());
        }
    }

    public static Map<String, Object> postPayrollRunToInvoice(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        LocalDispatcher dispatcher = dctx.getDispatcher();

        String payrollRunId = (String) context.get("payrollRunId");
        String vendorPartyId = (String) context.get("vendorPartyId");
        String invoiceTypeId = (String) context.get("invoiceTypeId");
        Boolean forceRepost = (Boolean) context.get("forceRepost");
        GenericValue userLogin = (GenericValue) context.get("userLogin");

        if (forceRepost == null) forceRepost = Boolean.FALSE;
        if (UtilValidate.isEmpty(payrollRunId)) return ServiceUtil.returnError("payrollRunId is required");
        if (UtilValidate.isEmpty(invoiceTypeId)) invoiceTypeId = "PURCHASE_INVOICE";

        boolean beganTx = false;
        try {
            beganTx = TransactionUtil.begin();

            GenericValue run = EntityQuery.use(delegator).from("PayrollRun").where("payrollRunId", payrollRunId).queryOne();
            if (run == null) return ServiceUtil.returnError("PayrollRun not found: " + payrollRunId);

            if (!"PAYRUN_APPROVED".equals(run.getString("statusId"))) {
                return ServiceUtil.returnError("PayrollRun must be APPROVED before posting to Invoice.");
            }

            if ("Y".equals(run.getString("isInvoicePosted")) && !forceRepost) {
                Map<String, Object> ok = ServiceUtil.returnSuccess("Already posted to Invoice.");
                ok.put("invoiceId", run.getString("invoiceId"));
                return ok;
            }

            String orgPartyId = run.getString("orgPartyId");

            if (UtilValidate.isEmpty(vendorPartyId)) {
                // per-org vendor resolution
                GenericValue org = EntityQuery.use(delegator).from("PayrollOrganization").where("orgPartyId", orgPartyId).queryOne();
                if (org != null) vendorPartyId = org.getString("payrollVendorPartyId");
            }
            if (UtilValidate.isEmpty(vendorPartyId)) {
                return ServiceUtil.returnError("vendorPartyId is required (or set PayrollOrganization.payrollVendorPartyId).");
            }

            // Create invoice (AP): org is buyer, vendor is seller
            String invoiceId = delegator.getNextSeqId("Invoice");
            Timestamp now = UtilDateTime.nowTimestamp();

            GenericValue inv = delegator.makeValue("Invoice");
            inv.set("invoiceId", invoiceId);
            inv.set("invoiceTypeId", invoiceTypeId);
            inv.set("partyId", orgPartyId);       // bill-to
            inv.set("partyIdFrom", vendorPartyId);// bill-from
            inv.set("invoiceDate", now);
            inv.set("currencyUomId", run.getString("currencyUomId"));
            inv.set("description", "Payroll Run " + payrollRunId);
            inv.set("statusId", "INVOICE_IN_PROCESS");
            delegator.create(inv);

            // Build invoice items based on PayrollInvoiceMapping from result lines
            List<GenericValue> resultLines = EntityQuery.use(delegator).from("EmployeePayrollResultLine")
                    .where(EntityCondition.makeCondition("payrollResultId", EntityOperator.IN,
                            EntityQuery.use(delegator).from("EmployeePayrollResult")
                                    .where("payrollRunId", payrollRunId)
                                    .queryList()
                                    .stream().map(r -> r.getString("payrollResultId")).toList()
                    ))
                    .queryList();

            Map<String, BigDecimal> amountByItemType = new HashMap<>();
            for (GenericValue l : resultLines) {
                String lineTypeId = l.getString("lineTypeId");
                BigDecimal amt = l.getBigDecimal("amount");
                if (amt == null) amt = BigDecimal.ZERO;
                if (amt.signum() == 0) continue;

                GenericValue map = findActiveInvoiceMapping(delegator, orgPartyId, lineTypeId);
                if (map == null) continue;

                String invoiceItemTypeId = map.getString("invoiceItemTypeId");
                amountByItemType.put(invoiceItemTypeId, amountByItemType.getOrDefault(invoiceItemTypeId, BigDecimal.ZERO).add(amt.abs()));
            }

            long seq = 1;
            BigDecimal total = BigDecimal.ZERO;
            for (Map.Entry<String, BigDecimal> e : amountByItemType.entrySet()) {
                String invoiceItemSeqId = leftPad(seq++, 5);
                GenericValue item = delegator.makeValue("InvoiceItem");
                item.set("invoiceId", invoiceId);
                item.set("invoiceItemSeqId", invoiceItemSeqId);
                item.set("invoiceItemTypeId", e.getKey());
                item.set("description", "Payroll " + e.getKey());
                item.set("quantity", BigDecimal.ONE);
                item.set("amount", e.getValue());
                delegator.create(item);
                total = total.add(e.getValue());
            }

            // Mark run
            run.set("invoiceId", invoiceId);
            run.set("isInvoicePosted", "Y");
            run.set("invoicePostedDate", now);
            delegator.store(run);

            TransactionUtil.commit(beganTx);

            Map<String, Object> ok = ServiceUtil.returnSuccess("Posted to Invoice.");
            ok.put("invoiceId", invoiceId);
            return ok;

        } catch (Exception e) {
            Debug.logError(e, "postPayrollRunToInvoice failed", MODULE);
            try { TransactionUtil.rollback(beganTx, e.getMessage(), e); } catch (Exception ignored) {}
            return ServiceUtil.returnError("postPayrollRunToInvoice failed: " + e.getMessage());
        }
    }

    // ---------------- Helpers ----------------

    private static GenericValue findActiveGlMapping(Delegator delegator, String orgPartyId, String lineTypeId) throws GenericEntityException {
        return EntityQuery.use(delegator).from("PayrollGlMapping")
                .where("orgPartyId", orgPartyId, "lineTypeId", lineTypeId, "isActive", "Y")
                .queryFirst();
    }

    private static GenericValue findActiveInvoiceMapping(Delegator delegator, String orgPartyId, String lineTypeId) throws GenericEntityException {
        return EntityQuery.use(delegator).from("PayrollInvoiceMapping")
                .where("orgPartyId", orgPartyId, "lineTypeId", lineTypeId, "isActive", "Y")
                .queryFirst();
    }

    private static void createAcctgTransEntry(Delegator delegator, String acctgTransId, long seq,
                                             String orgPartyId, String glAccountId, String currencyUomId,
                                             BigDecimal debit, BigDecimal credit) throws GenericEntityException {
        GenericValue e = delegator.makeValue("AcctgTransEntry");
        e.set("acctgTransId", acctgTransId);
        e.set("acctgTransEntrySeqId", leftPad(seq, 5));
        e.set("organizationPartyId", orgPartyId);
        e.set("glAccountId", glAccountId);
        e.set("currencyUomId", currencyUomId);
        e.set("debitCreditFlag", debit.signum() > 0 ? "D" : "C");
        e.set("amount", debit.signum() > 0 ? debit : credit);
        delegator.create(e);
    }

    private static String leftPad(long v, int len) {
        String s = String.valueOf(v);
        while (s.length() < len) s = "0" + s;
        return s;
    }
}
