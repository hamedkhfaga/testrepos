package org.apache.ofbiz.payroll.services;

import org.apache.ofbiz.base.util.Debug;
import org.apache.ofbiz.base.util.UtilDateTime;
import org.apache.ofbiz.base.util.UtilValidate;
import org.apache.ofbiz.entity.Delegator;
import org.apache.ofbiz.entity.GenericValue;
import org.apache.ofbiz.entity.condition.EntityCondition;
import org.apache.ofbiz.entity.condition.EntityOperator;
import org.apache.ofbiz.entity.transaction.TransactionUtil;
import org.apache.ofbiz.entity.util.EntityQuery;
import org.apache.ofbiz.service.DispatchContext;
import org.apache.ofbiz.service.ServiceUtil;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Timestamp;
import java.util.*;
/*
3) Updated PayrollWorkflowServices.java (STRICT workflow + idempotent calculate + uniqueness)

*/
public class PayrollWorkflowServices {
    public static final String MODULE = PayrollWorkflowServices.class.getName();

    public static Map<String, Object> calculatePayrollRun(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        GenericValue userLogin = (GenericValue) context.get("userLogin");

        String payrollRunId = (String) context.get("payrollRunId");
        Boolean forceRecalc = (Boolean) context.get("forceRecalc");

        if (UtilValidate.isEmpty(payrollRunId)) return ServiceUtil.returnError("payrollRunId is required");

        boolean beganTx = false;
        try {
            beganTx = TransactionUtil.begin();

            GenericValue run = EntityQuery.use(delegator).from("PayrollRun")
                .where("payrollRunId", payrollRunId)
                .queryOne();

            if (run == null) return ServiceUtil.returnError("PayrollRun not found: " + payrollRunId);

            String orgPartyId = run.getString("orgPartyId");
            PayrollStrictRules.requireNotEmpty("orgPartyId", orgPartyId);

            String status = run.getString("statusId");
            if (PayrollStrictRules.RUN_STATUS_APPROVED.equals(status) ||
                PayrollStrictRules.RUN_STATUS_POSTED.equals(status)) {
                return ServiceUtil.returnError("PayrollRun is approved/posted and cannot be recalculated");
            }

            if (!PayrollStrictRules.RUN_STATUS_DRAFT.equals(status) && !Boolean.TRUE.equals(forceRecalc)) {
                return ServiceUtil.returnError("PayrollRun status must be DRAFT (or forceRecalc=Y). Current=" + status);
            }

            // Period
            String payrollPeriodId = run.getString("payrollPeriodId");
            PayrollStrictRules.requireNotEmpty("payrollPeriodId", payrollPeriodId);

            GenericValue period = EntityQuery.use(delegator).from("PayrollPeriod")
                .where("payrollPeriodId", payrollPeriodId, "orgPartyId", orgPartyId)
                .queryOne();
            if (period == null) return ServiceUtil.returnError("PayrollPeriod not found for orgPartyId: " + payrollPeriodId);

            Timestamp periodStart = UtilDateTime.toTimestamp(period.getDate("startDate"));
            Timestamp periodEnd   = UtilDateTime.toTimestamp(period.getDate("endDate"));

            // Idempotent: if any results exist, clear them (only allowed because not approved)
            clearExistingRunResults(delegator, orgPartyId, payrollRunId);

            // Fetch active assignments in period for org
            List<GenericValue> assignments = EntityQuery.use(delegator)
                .from("EmployeePayrollAssignment")
                .where(EntityCondition.makeCondition(Arrays.asList(
                    EntityCondition.makeCondition("orgPartyId", EntityOperator.EQUALS, orgPartyId),
                    EntityCondition.makeCondition("effectiveDate", EntityOperator.LESS_THAN_EQUAL_TO, periodEnd),
                    EntityCondition.makeCondition(
                        EntityCondition.makeCondition("thruDate", EntityOperator.EQUALS, null),
                        EntityOperator.OR,
                        EntityCondition.makeCondition("thruDate", EntityOperator.GREATER_THAN_EQUAL_TO, periodStart)
                    )
                ), EntityOperator.AND))
                .queryList();

            BigDecimal totalGross = BigDecimal.ZERO;
            BigDecimal totalDed   = BigDecimal.ZERO;
            BigDecimal totalNet   = BigDecimal.ZERO;

            for (GenericValue asg : assignments) {
                String partyId = asg.getString("partyId");
                PayrollStrictRules.requireNotEmpty("partyId", partyId);

                // Uniqueness rule at runtime
                PayrollStrictRules.ensureUniqueEmployeeResult(delegator, payrollRunId, partyId);

                BigDecimal baseSalary = nvl(asg.getBigDecimal("baseSalary"));
                BigDecimal allowances = sumEmployeeAllowances(delegator, orgPartyId, partyId, periodEnd);
                BigDecimal deductions = sumEmployeeDeductions(delegator, orgPartyId, partyId, periodEnd);
                BigDecimal loanDed    = sumLoanInstallmentsDue(delegator, orgPartyId, partyId, periodStart, periodEnd);

                BigDecimal gross = baseSalary.add(allowances);

                // Strict: tax and SS must be derived from config (stub is 0 if no config)
                BigDecimal incomeTax = calculateIncomeTax(delegator, orgPartyId, partyId, gross, periodEnd);
                BigDecimal socialSec = calculateSocialSecurity(delegator, orgPartyId, partyId, gross, periodEnd);

                BigDecimal totalDeductions = deductions.add(loanDed).add(incomeTax).add(socialSec);
                BigDecimal net = gross.subtract(totalDeductions);

                String payrollResultId = delegator.getNextSeqId("EmployeePayrollResult");
                GenericValue res = delegator.makeValue("EmployeePayrollResult");

                res.set("payrollResultId", payrollResultId);
                res.set("orgPartyId", orgPartyId);
                res.set("payrollRunId", payrollRunId);
                res.set("partyId", partyId);

                res.set("basicSalary", baseSalary);
                res.set("allowancesTotal", allowances);
                res.set("grossSalary", gross);

                res.set("incomeTax", incomeTax);
                res.set("socialSecurity", socialSec);
                res.set("loanDeductions", loanDed);
                res.set("otherDeductions", deductions);
                res.set("totalDeductions", totalDeductions);
                res.set("netSalary", net);

                res.set("currencyUomId", run.getString("currencyUomId"));
                res.set("valuationCurrencyUomId", run.getString("valuationCurrencyUomId"));
                res.set("exchangeRate", run.get("exchangeRate"));

                // Payment from assignment (if fields exist)
                if (hasField(delegator, "EmployeePayrollResult", "paymentMethodId")) res.set("paymentMethodId", asg.get("paymentMethodId"));
                if (hasField(delegator, "EmployeePayrollResult", "finAccountId")) res.set("finAccountId", asg.get("finAccountId"));

                res.set("versionNumber", 1L);
                res.set("statusId", PayrollStrictRules.RESULT_STATUS_NEW);

                if (hasField(delegator, "EmployeePayrollResult", "isLocked")) res.set("isLocked", "N");

                res.create();

                // Lines (accounting-style)
                createLine(delegator, orgPartyId, payrollResultId, PayrollStrictRules.LINE_TYPE_BASIC, "Basic Salary", baseSalary, run.getString("currencyUomId"), 10);
                if (allowances.signum() != 0) createLine(delegator, orgPartyId, payrollResultId, PayrollStrictRules.LINE_TYPE_ALLOW, "Allowances", allowances, run.getString("currencyUomId"), 20);
                if (deductions.signum() != 0) createLine(delegator, orgPartyId, payrollResultId, PayrollStrictRules.LINE_TYPE_DEDUCT, "Deductions", deductions.negate(), run.getString("currencyUomId"), 30);
                if (loanDed.signum() != 0) createLine(delegator, orgPartyId, payrollResultId, PayrollStrictRules.LINE_TYPE_LOAN, "Loan Installments", loanDed.negate(), run.getString("currencyUomId"), 40);
                if (incomeTax.signum() != 0) createLine(delegator, orgPartyId, payrollResultId, PayrollStrictRules.LINE_TYPE_TAX, "Income Tax", incomeTax.negate(), run.getString("currencyUomId"), 50);
                if (socialSec.signum() != 0) createLine(delegator, orgPartyId, payrollResultId, PayrollStrictRules.LINE_TYPE_SS, "Social Security", socialSec.negate(), run.getString("currencyUomId"), 60);

                // Update totals
                totalGross = totalGross.add(gross);
                totalDed = totalDed.add(totalDeductions);
                totalNet = totalNet.add(net);
            }

            // Store run totals + move to CALCULATED
            run.set("totalEmployees", (long) assignments.size());
            run.set("totalGrossPay", totalGross);
            run.set("totalDeductions", totalDed);
            run.set("totalNetPay", totalNet);
            run.set("statusId", PayrollStrictRules.RUN_STATUS_CALCULATED);
            run.set("calculatedDate", UtilDateTime.nowTimestamp());
            if (hasField(delegator, "PayrollRun", "calculatedByUserLoginId") && userLogin != null) {
                run.set("calculatedByUserLoginId", userLogin.getString("userLoginId"));
            }
            run.store();

            createAudit(delegator, orgPartyId, "PayrollRun", payrollRunId, "PAY_AUD_CALC", userLogin);

            TransactionUtil.commit(beganTx);
            return ServiceUtil.returnSuccess();
        } catch (Exception e) {
            TransactionUtil.rollback(beganTx, e.getMessage(), e);
            Debug.logError(e, "calculatePayrollRun failed", MODULE);
            return ServiceUtil.returnError("calculatePayrollRun failed: " + e.getMessage());
        }
    }

    public static Map<String, Object> approvePayrollRun(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        GenericValue userLogin = (GenericValue) context.get("userLogin");

        String payrollRunId = (String) context.get("payrollRunId");
        if (UtilValidate.isEmpty(payrollRunId)) return ServiceUtil.returnError("payrollRunId is required");

        boolean beganTx = false;
        try {
            beganTx = TransactionUtil.begin();

            GenericValue run = EntityQuery.use(delegator).from("PayrollRun")
                .where("payrollRunId", payrollRunId).queryOne();
            if (run == null) return ServiceUtil.returnError("PayrollRun not found: " + payrollRunId);

            String orgPartyId = run.getString("orgPartyId");
            PayrollStrictRules.requireNotEmpty("orgPartyId", orgPartyId);

            if (!PayrollStrictRules.RUN_STATUS_CALCULATED.equals(run.getString("statusId"))) {
                return ServiceUtil.returnError("PayrollRun must be CALCULATED before approval");
            }

            // Validate totals == sum(results)
            validateRunTotals(delegator, orgPartyId, payrollRunId, run);

            // Lock results
            List<GenericValue> results = EntityQuery.use(delegator).from("EmployeePayrollResult")
                .where("orgPartyId", orgPartyId, "payrollRunId", payrollRunId)
                .queryList();

            for (GenericValue r : results) {
                r.set("statusId", PayrollStrictRules.RESULT_STATUS_LOCKED);
                if (hasField(delegator, "EmployeePayrollResult", "isLocked")) r.set("isLocked", "Y");
                r.store();
            }

            run.set("statusId", PayrollStrictRules.RUN_STATUS_APPROVED);
            run.set("approvedDate", UtilDateTime.nowTimestamp());
            if (hasField(delegator, "PayrollRun", "approvedByUserLoginId") && userLogin != null) {
                run.set("approvedByUserLoginId", userLogin.getString("userLoginId"));
            }
            run.store();

            createAudit(delegator, orgPartyId, "PayrollRun", payrollRunId, "PAY_AUD_APPROVE", userLogin);

            TransactionUtil.commit(beganTx);
            return ServiceUtil.returnSuccess();
        } catch (Exception e) {
            TransactionUtil.rollback(beganTx, e.getMessage(), e);
            Debug.logError(e, "approvePayrollRun failed", MODULE);
            return ServiceUtil.returnError("approvePayrollRun failed: " + e.getMessage());
        }
    }

    // =========================
    // Internals
    // =========================

    private static void validateRunTotals(Delegator delegator, String orgPartyId, String payrollRunId, GenericValue run) throws Exception {
        List<GenericValue> results = EntityQuery.use(delegator).from("EmployeePayrollResult")
            .where("orgPartyId", orgPartyId, "payrollRunId", payrollRunId)
            .queryList();

        BigDecimal gross = BigDecimal.ZERO;
        BigDecimal ded = BigDecimal.ZERO;
        BigDecimal net = BigDecimal.ZERO;

        for (GenericValue r : results) {
            gross = gross.add(nvl(r.getBigDecimal("grossSalary")));
            ded = ded.add(nvl(r.getBigDecimal("totalDeductions")));
            net = net.add(nvl(r.getBigDecimal("netSalary")));
        }

        if (gross.compareTo(nvl(run.getBigDecimal("totalGrossPay"))) != 0) {
            throw new IllegalArgumentException("Run totalGrossPay mismatch vs sum(results)");
        }
        if (ded.compareTo(nvl(run.getBigDecimal("totalDeductions"))) != 0) {
            throw new IllegalArgumentException("Run totalDeductions mismatch vs sum(results)");
        }
        if (net.compareTo(nvl(run.getBigDecimal("totalNetPay"))) != 0) {
            throw new IllegalArgumentException("Run totalNetPay mismatch vs sum(results)");
        }
    }

    private static void clearExistingRunResults(Delegator delegator, String orgPartyId, String payrollRunId) throws Exception {
        List<GenericValue> resList = EntityQuery.use(delegator).from("EmployeePayrollResult")
            .where("orgPartyId", orgPartyId, "payrollRunId", payrollRunId)
            .queryList();

        for (GenericValue res : resList) {
            String payrollResultId = res.getString("payrollResultId");

            EntityQuery.use(delegator).from("EmployeePayrollResultLine")
                .where("orgPartyId", orgPartyId, "payrollResultId", payrollResultId)
                .queryList().forEach(gv -> safeRemove(gv));

            EntityQuery.use(delegator).from("EmployeeTaxDetail")
                .where("orgPartyId", orgPartyId, "payrollResultId", payrollResultId)
                .queryList().forEach(gv -> safeRemove(gv));

            safeRemove(res);
        }
    }

    private static void safeRemove(GenericValue gv) { try { gv.remove(); } catch (Exception ignored) {} }

    private static BigDecimal sumEmployeeAllowances(Delegator delegator, String orgPartyId, String partyId, Timestamp asOf) throws Exception {
        List<GenericValue> list = EntityQuery.use(delegator).from("EmployeeAllowance")
            .where(EntityCondition.makeCondition(Arrays.asList(
                EntityCondition.makeCondition("orgPartyId", EntityOperator.EQUALS, orgPartyId),
                EntityCondition.makeCondition("partyId", EntityOperator.EQUALS, partyId),
                EntityCondition.makeCondition("effectiveDate", EntityOperator.LESS_THAN_EQUAL_TO, asOf),
                EntityCondition.makeCondition(
                    EntityCondition.makeCondition("thruDate", EntityOperator.EQUALS, null),
                    EntityOperator.OR,
                    EntityCondition.makeCondition("thruDate", EntityOperator.GREATER_THAN_EQUAL_TO, asOf)
                )
            ), EntityOperator.AND))
            .queryList();

        BigDecimal sum = BigDecimal.ZERO;
        for (GenericValue gv : list) sum = sum.add(nvl(gv.getBigDecimal("amount")));
        return sum;
    }

    private static BigDecimal sumEmployeeDeductions(Delegator delegator, String orgPartyId, String partyId, Timestamp asOf) throws Exception {
        List<GenericValue> list = EntityQuery.use(delegator).from("EmployeeDeduction")
            .where(EntityCondition.makeCondition(Arrays.asList(
                EntityCondition.makeCondition("orgPartyId", EntityOperator.EQUALS, orgPartyId),
                EntityCondition.makeCondition("partyId", EntityOperator.EQUALS, partyId),
                EntityCondition.makeCondition("effectiveDate", EntityOperator.LESS_THAN_EQUAL_TO, asOf),
                EntityCondition.makeCondition(
                    EntityCondition.makeCondition("thruDate", EntityOperator.EQUALS, null),
                    EntityOperator.OR,
                    EntityCondition.makeCondition("thruDate", EntityOperator.GREATER_THAN_EQUAL_TO, asOf)
                )
            ), EntityOperator.AND))
            .queryList();

        BigDecimal sum = BigDecimal.ZERO;
        for (GenericValue gv : list) sum = sum.add(nvl(gv.getBigDecimal("amount")));
        return sum;
    }

    private static BigDecimal sumLoanInstallmentsDue(Delegator delegator, String orgPartyId, String partyId, Timestamp start, Timestamp end) throws Exception {
        List<GenericValue> loans = EntityQuery.use(delegator).from("EmployeeLoan")
            .where("orgPartyId", orgPartyId, "partyId", partyId)
            .queryList();

        BigDecimal sum = BigDecimal.ZERO;
        for (GenericValue loan : loans) {
            String loanId = loan.getString("loanId");
            List<GenericValue> inst = EntityQuery.use(delegator).from("LoanInstallment")
                .where(EntityCondition.makeCondition(Arrays.asList(
                    EntityCondition.makeCondition("orgPartyId", EntityOperator.EQUALS, orgPartyId),
                    EntityCondition.makeCondition("loanId", EntityOperator.EQUALS, loanId),
                    EntityCondition.makeCondition("dueDate", EntityOperator.GREATER_THAN_EQUAL_TO, start),
                    EntityCondition.makeCondition("dueDate", EntityOperator.LESS_THAN_EQUAL_TO, end),
                    EntityCondition.makeCondition("paidDate", EntityOperator.EQUALS, null)
                ), EntityOperator.AND))
                .queryList();

            for (GenericValue i : inst) sum = sum.add(nvl(i.getBigDecimal("installmentAmount")));
        }
        return sum;
    }

    // ========= “Strict” tax and SS: 0 only if no config found =========
    private static BigDecimal calculateIncomeTax(Delegator delegator, String orgPartyId, String partyId, BigDecimal gross, Timestamp asOf) throws Exception {
        // You can implement bracket logic using PayrollTaxConfig + EmployeeTaxProfile here.
        // Strict default: if no tax config exists for org/country => 0
        GenericValue taxProfile = EntityQuery.use(delegator).from("EmployeeTaxProfile")
            .where("orgPartyId", orgPartyId, "partyId", partyId)
            .queryFirst();
        if (taxProfile == null) return BigDecimal.ZERO;

        String countryGeoId = taxProfile.getString("countryGeoId");
        if (UtilValidate.isEmpty(countryGeoId)) return BigDecimal.ZERO;

        GenericValue cfg = EntityQuery.use(delegator).from("PayrollTaxConfig")
            .where("orgPartyId", orgPartyId, "countryGeoId", countryGeoId, "isActive", "Y")
            .queryFirst();

        if (cfg == null) return BigDecimal.ZERO;

        // simple rate stub if you keep taxRate column
        BigDecimal rate = BigDecimal.ZERO;
        Object r = cfg.get("taxRate");
        if (r instanceof Double) rate = BigDecimal.valueOf((Double) r);
        if (r instanceof BigDecimal) rate = (BigDecimal) r;

        return gross.multiply(rate).setScale(2, RoundingMode.HALF_UP);
    }

    private static BigDecimal calculateSocialSecurity(Delegator delegator, String orgPartyId, String partyId, BigDecimal gross, Timestamp asOf) throws Exception {
        GenericValue taxProfile = EntityQuery.use(delegator).from("EmployeeTaxProfile")
            .where("orgPartyId", orgPartyId, "partyId", partyId)
            .queryFirst();
        if (taxProfile == null) return BigDecimal.ZERO;

        String countryGeoId = taxProfile.getString("countryGeoId");
        if (UtilValidate.isEmpty(countryGeoId)) return BigDecimal.ZERO;

        GenericValue cfg = EntityQuery.use(delegator).from("SocialSecurityConfig")
            .where("orgPartyId", orgPartyId, "countryGeoId", countryGeoId)
            .orderBy("-effectiveDate")
            .queryFirst();
        if (cfg == null) return BigDecimal.ZERO;

        Object r = cfg.get("employeeRate");
        BigDecimal rate = BigDecimal.ZERO;
        if (r instanceof Double) rate = BigDecimal.valueOf((Double) r);
        if (r instanceof BigDecimal) rate = (BigDecimal) r;

        return gross.multiply(rate).setScale(2, RoundingMode.HALF_UP);
    }

    private static void createLine(Delegator delegator, String orgPartyId, String payrollResultId,
                                   String lineTypeId, String description, BigDecimal amount,
                                   String currencyUomId, int seq) throws Exception {
        GenericValue line = delegator.makeValue("EmployeePayrollResultLine");
        line.set("employeePayrollResultLineId", delegator.getNextSeqId("EmployeePayrollResultLine"));
        line.set("orgPartyId", orgPartyId);
        line.set("payrollResultId", payrollResultId);
        line.set("lineTypeId", lineTypeId);
        line.set("description", description);
        line.set("amount", amount.setScale(2, RoundingMode.HALF_UP));
        line.set("currencyUomId", currencyUomId);
        line.set("sequenceNum", (long) seq);
        line.create();
    }

    private static void createAudit(Delegator delegator, String orgPartyId, String entityName, String recordId,
                                    String actionTypeId, GenericValue userLogin) {
        try {
            GenericValue aud = delegator.makeValue("PayrollAuditLog");
            aud.set("payrollAuditLogId", delegator.getNextSeqId("PayrollAuditLog"));
            aud.set("orgPartyId", orgPartyId);
            aud.set("entityName", entityName);
            aud.set("recordId", recordId);
            aud.set("actionTypeId", actionTypeId);
            aud.set("changedByUserLoginId", userLogin == null ? null : userLogin.getString("userLoginId"));
            aud.set("changedDate", UtilDateTime.nowTimestamp());
            aud.create();
        } catch (Exception e) {
            Debug.logWarning(e, "Audit log failed (non-fatal)", MODULE);
        }
    }

    private static boolean hasField(Delegator delegator, String entityName, String field) {
        return PayrollStrictRules.entityHasField(delegator, entityName, field);
    }

    private static BigDecimal nvl(BigDecimal v) { return v == null ? BigDecimal.ZERO : v; }
}
