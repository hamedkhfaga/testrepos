package org.apache.ofbiz.payroll;

import org.apache.ofbiz.entity.*;
import org.apache.ofbiz.entity.util.EntityQuery;
import org.apache.ofbiz.service.*;
import org.apache.ofbiz.base.util.*;

import java.util.*;

public class PayrollWorkflowServices {

    public static Map<String, Object> createPayrollRun(DispatchContext dctx, Map<String, ?> context)
            throws GenericEntityException {

        Delegator delegator = dctx.getDelegator();

        GenericValue run = delegator.makeValue("PayrollRun");
        run.set("payrollRunId", delegator.getNextSeqId("PayrollRun"));
        run.set("organizationPartyId", context.get("organizationPartyId"));
        run.set("runMonth", context.get("runMonth"));
        run.set("runYear", context.get("runYear"));
        run.set("statusId", "PAYROLL_CREATED");

        delegator.create(run);
        return ServiceUtil.returnSuccess();
    }

    public static Map<String, Object> processPayrollRun(DispatchContext dctx, Map<String, ?> context)
            throws GenericEntityException {

        // Salary calculations placeholder (rules, components, overtime, deductions)
        // Generate PayrollRunItem records
List<GenericValue> assignments = EntityQuery.use(delegator)
    .from("EmployeePayrollAssignment")
    .where("organizationPartyId", context.get("organizationPartyId"))
    .queryList();

for (GenericValue assign : assignments) {

    GenericValue att = EntityQuery.use(delegator)
        .from("AttendancePeriodSummary")
        .where(
            "partyId", assign.get("partyId"),
            "periodMonth", context.get("runMonth"),
            "periodYear", context.get("runYear")
        )
        .queryOne();
if (!"ATT_FROZEN".equals(att.getString("statusId"))) {
    return ServiceUtil.returnError("Attendance not frozen");
}

    if (att == null) continue;
BigDecimal tax = PayrollStatutoryServices.calculateIncomeTax(
        delegator,
        organizationPartyId,
        grossAmount
);

Map<String, BigDecimal> gosi =
    PayrollStatutoryServices.calculateStatutory(
        delegator,
        organizationPartyId,
        grossAmount
);

BigDecimal net =
    grossAmount
        .subtract(tax)
        .subtract(gosi.get("EMPLOYEE"));

// Store deductions
createDeduction("TAX", tax);
createDeduction("GOSI_EMP", gosi.get("EMPLOYEE"));
createDeduction("GOSI_EMPR", gosi.get("EMPLOYER"));

    BigDecimal baseSalary = assign.getBigDecimal("baseSalary");

    BigDecimal dailyRate =
        baseSalary.divide(new BigDecimal(30), 2, RoundingMode.HALF_UP);

    BigDecimal payable =
        dailyRate.multiply(new BigDecimal(att.getLong("payableDays")));

    BigDecimal overtimePay =
        new BigDecimal(att.getLong("overtimeMinutes"))
            .divide(new BigDecimal(60), 2, RoundingMode.HALF_UP)
            .multiply(new BigDecimal("1.5"))
            .multiply(dailyRate.divide(new BigDecimal(8), 2));

    BigDecimal lateDeduction =
        new BigDecimal(att.getLong("lateMinutes"))
            .divide(new BigDecimal(60), 2)
            .multiply(dailyRate.divide(new BigDecimal(8), 2));

    BigDecimal net =
        payable.add(overtimePay).subtract(lateDeduction);

    // create PayrollRunItem here
}

        return ServiceUtil.returnSuccess("Payroll processed");
    }

    public static Map<String, Object> approvePayrollRun(DispatchContext dctx, Map<String, ?> context)
            throws GenericEntityException {

        Delegator delegator = dctx.getDelegator();
        GenericValue run = delegator.findOne("PayrollRun",
                UtilMisc.toMap("payrollRunId", context.get("payrollRunId")), false);

        run.set("statusId", "PAYROLL_APPROVED");
        run.store();
        return ServiceUtil.returnSuccess();
    }

    public static Map<String, Object> postPayrollRun(DispatchContext dctx, Map<String, ?> context)
            throws GenericEntityException {

        String postMode = (String) context.get("postMode");

       if ("GL".equals(postMode)) {
    dispatcher.runSync("postPayrollToGL", context);
} else if ("INVOICE".equals(postMode)) {
    dispatcher.runSync("postPayrollToInvoice", context);
}


        return ServiceUtil.returnSuccess("Payroll posted: " + postMode);
    }

    public static Map<String, Object> generatePayslipPdf(DispatchContext dctx, Map<String, ?> context) {

        // OpenPDF + FOP integration placeholder
        // Barcode generation per employee

        Map<String, Object> result = ServiceUtil.returnSuccess();
        result.put("pdfFile", "/runtime/payslips/payslip_001.pdf");
        return result;
    }
}
