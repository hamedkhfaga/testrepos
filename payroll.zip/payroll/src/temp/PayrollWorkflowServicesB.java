package org.apache.ofbiz.payroll.services;

import org.apache.ofbiz.base.util.Debug;
import org.apache.ofbiz.base.util.UtilDateTime;
import org.apache.ofbiz.base.util.UtilValidate;
import org.apache.ofbiz.entity.Delegator;
import org.apache.ofbiz.entity.GenericEntityException;
import org.apache.ofbiz.entity.GenericValue;
import org.apache.ofbiz.entity.condition.EntityCondition;
import org.apache.ofbiz.entity.condition.EntityOperator;
import org.apache.ofbiz.entity.transaction.TransactionUtil;
import org.apache.ofbiz.entity.util.EntityQuery;
import org.apache.ofbiz.service.DispatchContext;
import org.apache.ofbiz.service.ServiceUtil;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Timestamp;
import java.util.*;

/**
 *3) PayrollWorkflowServices.java (calculate + approve + bank transfer batch)
 * Payroll workflow:
 * - calculatePayrollRun: builds EmployeePayrollResult + Lines + TaxDetail from active assignments
 * - approvePayrollRun: sets approved fields and status
 * - postPayrollRunToGL: flags run posted
 * - generateBankTransferBatchForRun: batch + lines from results
 */
public class PayrollWorkflowServices {

    public static final String MODULE = PayrollWorkflowServices.class.getName();

    // Adjust to your StatusItem IDs
    private static final String RUN_STATUS_DRAFT = "PAY_RUN_DRAFT";
    private static final String RUN_STATUS_CALCULATED = "PAY_RUN_CALC";
    private static final String RUN_STATUS_APPROVED = "PAY_RUN_APPR";

    private static final String LINE_TYPE_BASIC = "PAY_LINE_BASIC";
    private static final String LINE_TYPE_ALLOWANCE = "PAY_LINE_ALLOW";
    private static final String LINE_TYPE_DEDUCTION = "PAY_LINE_DEDUCT";
    private static final String LINE_TYPE_LOAN = "PAY_LINE_LOAN";
    private static final String LINE_TYPE_TAX = "PAY_LINE_TAX";
    private static final String LINE_TYPE_SS = "PAY_LINE_SS";

    public static Map<String, Object> calculatePayrollRun(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        GenericValue userLogin = (GenericValue) context.get("userLogin");

        String payrollRunId = (String) context.get("payrollRunId");
        Boolean forceRecalc = (Boolean) context.get("forceRecalc");
        if (UtilValidate.isEmpty(payrollRunId)) {
            return ServiceUtil.returnError("payrollRunId is required");
        }

        boolean beganTx = false;
        try {
            beganTx = TransactionUtil.begin();

            GenericValue run = EntityQuery.use(delegator).from("PayrollRun")
                .where("payrollRunId", payrollRunId)
                .queryOne();

            if (run == null) {
                return ServiceUtil.returnError("PayrollRun not found: " + payrollRunId);
            }

            String runStatus = run.getString("statusId");
            if (RUN_STATUS_APPROVED.equals(runStatus)) {
                return ServiceUtil.returnError("PayrollRun is approved and cannot be recalculated");
            }

            if (!RUN_STATUS_DRAFT.equals(runStatus) && !Boolean.TRUE.equals(forceRecalc)) {
                // allow re-calc only with force
                return ServiceUtil.returnError("PayrollRun status is not DRAFT. Use forceRecalc=Y to recalc.");
            }

            String orgPartyId = run.getString("orgPartyId");
            String payrollPeriodId = run.getString("payrollPeriodId");

            GenericValue period = EntityQuery.use(delegator).from("PayrollPeriod")
                .where("payrollPeriodId", payrollPeriodId)
                .queryOne();
            if (period == null) {
                return ServiceUtil.returnError("PayrollPeriod not found: " + payrollPeriodId);
            }

            Timestamp periodStart = UtilDateTime.toTimestamp(period.getDate("startDate"));
            Timestamp periodEnd = UtilDateTime.toTimestamp(period.getDate("endDate"));
            Timestamp now = UtilDateTime.nowTimestamp();

            // 1) Clear previous results if forced or draft
            clearExistingRunResults(delegator, payrollRunId);

            // 2) Fetch active assignments for org and within period
            List<GenericValue> assignments = EntityQuery.use(delegator)
                .from("EmployeePayrollAssignment")
                .where(EntityCondition.makeCondition(Arrays.asList(
                    EntityCondition.makeCondition("orgPartyId", EntityOperator.EQUALS, orgPartyId),
                    EntityCondition.makeCondition("effectiveDate", EntityOperator.LESS_THAN_EQUAL_TO, periodEnd),
                    EntityCondition.makeCondition(EntityCondition.makeCondition("thruDate", EntityOperator.EQUALS, null),
                        EntityOperator.OR,
                        EntityCondition.makeCondition("thruDate", EntityOperator.GREATER_THAN_EQUAL_TO, periodStart))
                ), EntityOperator.AND))
                .queryList();

            BigDecimal totalGross = BigDecimal.ZERO;
            BigDecimal totalDed = BigDecimal.ZERO;
            BigDecimal totalNet = BigDecimal.ZERO;

            for (GenericValue asg : assignments) {
                String partyId = asg.getString("partyId");

                // ---- base salary ----
                BigDecimal baseSalary = nvlMoney(asg.getBigDecimal("baseSalary"));
                BigDecimal allowances = sumEmployeeAllowances(delegator, orgPartyId, partyId, periodEnd);
                BigDecimal deductions = sumEmployeeDeductions(delegator, orgPartyId, partyId, periodEnd);
                BigDecimal loanDed = sumLoanInstallmentsDue(delegator, orgPartyId, partyId, periodStart, periodEnd);

                // ---- tax + ss (simple baseline; plug in your full rules) ----
                BigDecimal incomeTax = calculateIncomeTaxStub(delegator, orgPartyId, partyId, baseSalary.add(allowances));
                BigDecimal socialSec = calculateSocialSecurityStub(delegator, orgPartyId, partyId, baseSalary.add(allowances));

                BigDecimal gross = baseSalary.add(allowances);
                BigDecimal totalDeductions = deductions.add(loanDed).add(incomeTax).add(socialSec);
                BigDecimal net = gross.subtract(totalDeductions);

                // create result header
                String payrollResultId = delegator.getNextSeqId("EmployeePayrollResult");
                GenericValue res = delegator.makeValue("EmployeePayrollResult");
                res.set("payrollResultId", payrollResultId);
                res.set("payrollRunId", payrollRunId);
                res.set("orgPartyId", orgPartyId);
                res.set("partyId", partyId);

                res.set("basicSalary", baseSalary);
                res.set("allowancesTotal", allowances);
                res.set("grossSalary", gross);

                res.set("incomeTax", incomeTax);
                res.set("socialSecurity", socialSec);
                res.set("loanDeductions", loanDed);
                res.set("otherDeductions", deductions);
                res.set("totalDeductions", totalDeductions);
                res.set("netSalary", net);

                res.set("currencyUomId", run.getString("currencyUomId"));
                res.set("valuationCurrencyUomId", run.getString("valuationCurrencyUomId"));
                res.set("exchangeRate", run.get("exchangeRate")); // optional

                // payment fields from assignment
                res.set("paymentMethodId", asg.get("paymentMethodId"));
                res.set("finAccountId", asg.get("finAccountId"));
                res.set("versionNumber", 1L);
                res.set("statusId", "PAY_RES_NEW");
                res.set("isPayslipGenerated", "N");
                res.set("isPayslipSent", "N");

                res.create();

                // create result lines (immutable posting style)
                createLine(delegator, payrollResultId, LINE_TYPE_BASIC, null, "Basic Salary", baseSalary, run.getString("currencyUomId"), 10);
                if (allowances.signum() != 0) createLine(delegator, payrollResultId, LINE_TYPE_ALLOWANCE, null, "Allowances", allowances, run.getString("currencyUomId"), 20);
                if (deductions.signum() != 0) createLine(delegator, payrollResultId, LINE_TYPE_DEDUCTION, null, "Deductions", deductions.negate(), run.getString("currencyUomId"), 30);
                if (loanDed.signum() != 0) createLine(delegator, payrollResultId, LINE_TYPE_LOAN, null, "Loan Installments", loanDed.negate(), run.getString("currencyUomId"), 40);
                if (incomeTax.signum() != 0) createLine(delegator, payrollResultId, LINE_TYPE_TAX, null, "Income Tax", incomeTax.negate(), run.getString("currencyUomId"), 50);
                if (socialSec.signum() != 0) createLine(delegator, payrollResultId, LINE_TYPE_SS, null, "Social Security", socialSec.negate(), run.getString("currencyUomId"), 60);

                // tax detail record
                if (incomeTax.signum() != 0) {
                    GenericValue taxDet = delegator.makeValue("EmployeeTaxDetail");
                    taxDet.set("taxDetailId", delegator.getNextSeqId("EmployeeTaxDetail"));
                    taxDet.set("payrollResultId", payrollResultId);
                    taxDet.set("taxTypeId", "PAY_TAX_INCOME");
                    taxDet.set("taxableAmount", gross);
                    taxDet.set("taxRate", null);
                    taxDet.set("calculatedTax", incomeTax);
                    taxDet.create();
                }

                totalGross = totalGross.add(gross);
                totalDed = totalDed.add(totalDeductions);
                totalNet = totalNet.add(net);
            }

            // update run totals + status
            run.set("totalEmployees", (long) assignments.size());
            run.set("totalGrossPay", totalGross);
            run.set("totalDeductions", totalDed);
            run.set("totalNetPay", totalNet);
            run.set("statusId", RUN_STATUS_CALCULATED);
            run.store();

            // audit
            createAudit(delegator, orgPartyId, "PayrollRun", payrollRunId, "PAY_AUD_CALC", userLogin);

            TransactionUtil.commit(beganTx);
            return ServiceUtil.returnSuccess();
        } catch (Exception e) {
            TransactionUtil.rollback(beganTx, e.getMessage(), e);
            Debug.logError(e, "calculatePayrollRun failed", MODULE);
            return ServiceUtil.returnError("calculatePayrollRun failed: " + e.getMessage());
        }
    }

    public static Map<String, Object> approvePayrollRun(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        GenericValue userLogin = (GenericValue) context.get("userLogin");
        String payrollRunId = (String) context.get("payrollRunId");
        if (UtilValidate.isEmpty(payrollRunId)) {
            return ServiceUtil.returnError("payrollRunId is required");
        }

        boolean beganTx = false;
        try {
            beganTx = TransactionUtil.begin();

            GenericValue run = EntityQuery.use(delegator).from("PayrollRun")
                .where("payrollRunId", payrollRunId).queryOne();
            if (run == null) return ServiceUtil.returnError("PayrollRun not found: " + payrollRunId);

            if (!RUN_STATUS_CALCULATED.equals(run.getString("statusId"))) {
                return ServiceUtil.returnError("PayrollRun must be CALCULATED before approval");
            }

            run.set("statusId", RUN_STATUS_APPROVED);
            run.set("approvedByUserLoginId", userLogin == null ? null : userLogin.getString("userLoginId"));
            run.set("approvedDate", UtilDateTime.nowTimestamp());
            run.store();

            createAudit(delegator, run.getString("orgPartyId"), "PayrollRun", payrollRunId, "PAY_AUD_APPROVE", userLogin);

            TransactionUtil.commit(beganTx);
            return ServiceUtil.returnSuccess();
        } catch (Exception e) {
            TransactionUtil.rollback(beganTx, e.getMessage(), e);
            Debug.logError(e, "approvePayrollRun failed", MODULE);
            return ServiceUtil.returnError("approvePayrollRun failed: " + e.getMessage());
        }
    }

    public static Map<String, Object> postPayrollRunToGL(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        GenericValue userLogin = (GenericValue) context.get("userLogin");
        String payrollRunId = (String) context.get("payrollRunId");
        String glJournalId = (String) context.get("glJournalId");

        if (UtilValidate.isEmpty(payrollRunId)) {
            return ServiceUtil.returnError("payrollRunId is required");
        }

        boolean beganTx = false;
        try {
            beganTx = TransactionUtil.begin();

            GenericValue run = EntityQuery.use(delegator).from("PayrollRun")
                .where("payrollRunId", payrollRunId).queryOne();
            if (run == null) return ServiceUtil.returnError("PayrollRun not found: " + payrollRunId);

            if (!RUN_STATUS_APPROVED.equals(run.getString("statusId"))) {
                return ServiceUtil.returnError("PayrollRun must be APPROVED before GL posting");
            }

            run.set("isGlPosted", "Y");
            run.set("glJournalId", glJournalId);
            run.set("glPostedDate", UtilDateTime.nowTimestamp());
            run.store();

            createAudit(delegator, run.getString("orgPartyId"), "PayrollRun", payrollRunId, "PAY_AUD_GLPOST", userLogin);

            TransactionUtil.commit(beganTx);
            return ServiceUtil.returnSuccess();
        } catch (Exception e) {
            TransactionUtil.rollback(beganTx, e.getMessage(), e);
            Debug.logError(e, "postPayrollRunToGL failed", MODULE);
            return ServiceUtil.returnError("postPayrollRunToGL failed: " + e.getMessage());
        }
    }

    public static Map<String, Object> generateBankTransferBatchForRun(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        GenericValue userLogin = (GenericValue) context.get("userLogin");
        String payrollRunId = (String) context.get("payrollRunId");
        String bankTransferConfigId = (String) context.get("bankTransferConfigId");

        if (UtilValidate.isEmpty(payrollRunId) || UtilValidate.isEmpty(bankTransferConfigId)) {
            return ServiceUtil.returnError("payrollRunId and bankTransferConfigId are required");
        }

        boolean beganTx = false;
        try {
            beganTx = TransactionUtil.begin();

            GenericValue run = EntityQuery.use(delegator).from("PayrollRun")
                .where("payrollRunId", payrollRunId).queryOne();
            if (run == null) return ServiceUtil.returnError("PayrollRun not found: " + payrollRunId);

            if (!RUN_STATUS_APPROVED.equals(run.getString("statusId"))) {
                return ServiceUtil.returnError("PayrollRun must be APPROVED before generating bank transfer batch");
            }

            String orgPartyId = run.getString("orgPartyId");
            String currencyUomId = run.getString("currencyUomId");

            // results for run
            List<GenericValue> results = EntityQuery.use(delegator).from("EmployeePayrollResult")
                .where("payrollRunId", payrollRunId).queryList();

            BigDecimal total = BigDecimal.ZERO;
            for (GenericValue r : results) total = total.add(nvlMoney(r.getBigDecimal("netSalary")));

            String batchId = delegator.getNextSeqId("BankTransferBatch");
            GenericValue batch = delegator.makeValue("BankTransferBatch");
            batch.set("bankTransferBatchId", batchId);
            batch.set("orgPartyId", orgPartyId);
            batch.set("payrollRunId", payrollRunId);
            batch.set("bankTransferConfigId", bankTransferConfigId);
            batch.set("totalAmount", total);
            batch.set("currencyUomId", currencyUomId);
            batch.set("totalRecords", (long) results.size());
            batch.set("generatedDate", UtilDateTime.nowTimestamp());
            batch.set("statusId", "PAY_BTB_NEW");
            batch.create();

            long seq = 1;
            for (GenericValue r : results) {
                GenericValue line = delegator.makeValue("BankTransferBatchLine");
                line.set("bankTransferBatchLineId", delegator.getNextSeqId("BankTransferBatchLine"));
                line.set("bankTransferBatchId", batchId);
                line.set("payrollResultId", r.getString("payrollResultId"));
                line.set("partyId", r.getString("partyId"));
                line.set("amount", nvlMoney(r.getBigDecimal("netSalary")));
                line.set("currencyUomId", currencyUomId);
                line.set("beneficiaryName", null);
                line.set("sequenceNum", seq++);
                line.set("statusId", "PAY_BTBL_NEW");
                line.create();
            }

            createAudit(delegator, orgPartyId, "BankTransferBatch", batchId, "PAY_AUD_BTB_GEN", userLogin);

            TransactionUtil.commit(beganTx);
            return ServiceUtil.returnSuccess();
        } catch (Exception e) {
            TransactionUtil.rollback(beganTx, e.getMessage(), e);
            Debug.logError(e, "generateBankTransferBatchForRun failed", MODULE);
            return ServiceUtil.returnError("generateBankTransferBatchForRun failed: " + e.getMessage());
        }
    }

    // =========================================================
    // Internal helpers
    // =========================================================

    private static void clearExistingRunResults(Delegator delegator, String payrollRunId) throws GenericEntityException {
        List<GenericValue> resList = EntityQuery.use(delegator).from("EmployeePayrollResult")
            .where("payrollRunId", payrollRunId).queryList();

        for (GenericValue res : resList) {
            String payrollResultId = res.getString("payrollResultId");

            // delete children first
            EntityQuery.use(delegator).from("EmployeePayrollResultLine")
                .where("payrollResultId", payrollResultId).queryList()
                .forEach(gv -> safeRemove(gv));

            EntityQuery.use(delegator).from("EmployeeTaxDetail")
                .where("payrollResultId", payrollResultId).queryList()
                .forEach(gv -> safeRemove(gv));

            safeRemove(res);
        }
    }

    private static void safeRemove(GenericValue gv) {
        try { gv.remove(); } catch (Exception ignored) { }
    }

    private static BigDecimal sumEmployeeAllowances(Delegator delegator, String orgPartyId, String partyId, Timestamp asOf) throws GenericEntityException {
        List<GenericValue> list = EntityQuery.use(delegator).from("EmployeeAllowance")
            .where(EntityCondition.makeCondition(Arrays.asList(
                EntityCondition.makeCondition("orgPartyId", EntityOperator.EQUALS, orgPartyId),
                EntityCondition.makeCondition("partyId", EntityOperator.EQUALS, partyId),
                EntityCondition.makeCondition("effectiveDate", EntityOperator.LESS_THAN_EQUAL_TO, asOf),
                EntityCondition.makeCondition(EntityCondition.makeCondition("thruDate", EntityOperator.EQUALS, null),
                    EntityOperator.OR,
                    EntityCondition.makeCondition("thruDate", EntityOperator.GREATER_THAN_EQUAL_TO, asOf))
            ), EntityOperator.AND))
            .queryList();

        BigDecimal sum = BigDecimal.ZERO;
        for (GenericValue gv : list) sum = sum.add(nvlMoney(gv.getBigDecimal("amount")));
        return sum;
    }

    private static BigDecimal sumEmployeeDeductions(Delegator delegator, String orgPartyId, String partyId, Timestamp asOf) throws GenericEntityException {
        List<GenericValue> list = EntityQuery.use(delegator).from("EmployeeDeduction")
            .where(EntityCondition.makeCondition(Arrays.asList(
                EntityCondition.makeCondition("orgPartyId", EntityOperator.EQUALS, orgPartyId),
                EntityCondition.makeCondition("partyId", EntityOperator.EQUALS, partyId),
                EntityCondition.makeCondition("effectiveDate", EntityOperator.LESS_THAN_EQUAL_TO, asOf),
                EntityCondition.makeCondition(EntityCondition.makeCondition("thruDate", EntityOperator.EQUALS, null),
                    EntityOperator.OR,
                    EntityCondition.makeCondition("thruDate", EntityOperator.GREATER_THAN_EQUAL_TO, asOf))
            ), EntityOperator.AND))
            .queryList();

        BigDecimal sum = BigDecimal.ZERO;
        for (GenericValue gv : list) sum = sum.add(nvlMoney(gv.getBigDecimal("amount")));
        return sum;
    }

    private static BigDecimal sumLoanInstallmentsDue(Delegator delegator, String orgPartyId, String partyId, Timestamp start, Timestamp end) throws GenericEntityException {
        // active loans for employee
        List<GenericValue> loans = EntityQuery.use(delegator).from("EmployeeLoan")
            .where("orgPartyId", orgPartyId, "partyId", partyId)
            .queryList();

        BigDecimal sum = BigDecimal.ZERO;
        for (GenericValue loan : loans) {
            String loanId = loan.getString("loanId");
            List<GenericValue> inst = EntityQuery.use(delegator).from("LoanInstallment")
                .where(EntityCondition.makeCondition(Arrays.asList(
                    EntityCondition.makeCondition("loanId", EntityOperator.EQUALS, loanId),
                    EntityCondition.makeCondition("dueDate", EntityOperator.GREATER_THAN_EQUAL_TO, start),
                    EntityCondition.makeCondition("dueDate", EntityOperator.LESS_THAN_EQUAL_TO, end),
                    EntityCondition.makeCondition(EntityCondition.makeCondition("paidDate", EntityOperator.EQUALS, null),
                        EntityOperator.OR,
                        EntityCondition.makeCondition("statusId", EntityOperator.NOT_EQUAL, "PAY_INST_PAID"))
                ), EntityOperator.AND))
                .queryList();

            for (GenericValue i : inst) sum = sum.add(nvlMoney(i.getBigDecimal("installmentAmount")));
        }
        return sum;
    }

    private static BigDecimal calculateIncomeTaxStub(Delegator delegator, String orgPartyId, String partyId, BigDecimal taxableBase) {
        // plug your country config rules here using PayrollTaxConfig + EmployeeTaxProfile
        // minimal stub: 0
        return BigDecimal.ZERO;
    }

    private static BigDecimal calculateSocialSecurityStub(Delegator delegator, String orgPartyId, String partyId, BigDecimal base) throws GenericEntityException {
        // plug your SocialSecurityConfig logic; stub can be 0
        return BigDecimal.ZERO;
    }

    private static void createLine(Delegator delegator, String payrollResultId, String lineTypeId,
                                   String referenceId, String description, BigDecimal amount,
                                   String currencyUomId, int seq) throws GenericEntityException {
        GenericValue line = delegator.makeValue("EmployeePayrollResultLine");
        line.set("resultLineId", delegator.getNextSeqId("EmployeePayrollResultLine"));
        line.set("payrollResultId", payrollResultId);
        line.set("lineTypeId", lineTypeId);
        line.set("referenceId", referenceId);
        line.set("description", description);
        line.set("amount", amount.setScale(2, RoundingMode.HALF_UP));
        line.set("currencyUomId", currencyUomId);
        line.set("sequenceNum", (long) seq);
        line.create();
    }

    private static void createAudit(Delegator delegator, String orgPartyId, String entityName, String recordId,
                                    String actionTypeId, GenericValue userLogin) {
        try {
            GenericValue aud = delegator.makeValue("PayrollAuditLog");
            aud.set("payrollAuditLogId", delegator.getNextSeqId("PayrollAuditLog"));
            aud.set("orgPartyId", orgPartyId);
            aud.set("entityName", entityName);
            aud.set("recordId", recordId);
            aud.set("actionTypeId", actionTypeId);
            aud.set("changedByUserLoginId", userLogin == null ? null : userLogin.getString("userLoginId"));
            aud.set("changedDate", UtilDateTime.nowTimestamp());
            aud.create();
        } catch (Exception e) {
            Debug.logWarning(e, "Audit log failed (non-fatal)", MODULE);
        }
    }

    private static BigDecimal nvlMoney(BigDecimal v) {
        return v == null ? BigDecimal.ZERO : v;
    }
}
