package org.apache.ofbiz.payroll;

import org.apache.ofbiz.base.util.Debug;
import org.apache.ofbiz.base.util.UtilDateTime;
import org.apache.ofbiz.base.util.UtilMisc;
import org.apache.ofbiz.base.util.UtilValidate;

import org.apache.ofbiz.entity.Delegator;
import org.apache.ofbiz.entity.GenericEntityException;
import org.apache.ofbiz.entity.GenericValue;

import org.apache.ofbiz.entity.condition.EntityCondition;
import org.apache.ofbiz.entity.condition.EntityOperator;
import org.apache.ofbiz.entity.transaction.TransactionUtil;
import org.apache.ofbiz.entity.util.EntityQuery;

import org.apache.ofbiz.service.DispatchContext;
import org.apache.ofbiz.service.LocalDispatcher;
import org.apache.ofbiz.service.ServiceUtil;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Timestamp;
import java.util.*;

/**
 * PayrollPostingServices
 * - Post approved payroll runs to GL (AcctgTrans) or Invoice (Invoice/InvoiceItem)
 * - Uses mapping tables per org to map payroll lineTypeId -> glAccountId (DR/CR) or invoiceItemTypeId
 * - Idempotent via PayrollPosting record; supports forceRepost.
 */
public class PayrollPostingServices {
    public static final String MODULE = PayrollPostingServices.class.getName();

    // Run statuses (adjust to your status ids)
    public static final String RUN_STATUS_APPROVED = "PAYRUN_APPROVED";
    public static final String RUN_STATUS_POSTED   = "PAYRUN_POSTED";

    // Posting status
    public static final String POSTING_NEW     = "PAYPOST_NEW";
    public static final String POSTING_POSTED  = "PAYPOST_POSTED";
    public static final String POSTING_ERROR   = "PAYPOST_ERROR";
    public static final String POSTING_REVERSED= "PAYPOST_REVERSED";

    // Default accounting types (adjust to your OFBiz accounting setup)
    private static final String DEFAULT_ACCTG_TRANS_TYPE = "MANUAL_ACCTG_TRANS";
    private static final String DEFAULT_INVOICE_TYPE     = "PURCHASE_INVOICE"; // AP invoice
    private static final String DEFAULT_INVOICE_ROLE     = "BILL_FROM_VENDOR"; // vendor role on invoice (common pattern)
    private static final String DEFAULT_CURRENCY_UOM      = "USD";

    // =========================================================
    // Public Service: postPayrollRunToGl
    // =========================================================
    public static Map<String, Object> postPayrollRunToGl(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        LocalDispatcher dispatcher = dctx.getDispatcher();
        GenericValue userLogin = (GenericValue) context.get("userLogin");

        String payrollRunId = (String) context.get("payrollRunId");
        String organizationPartyId = firstOrg(context);
        String glFiscalTypeId = (String) context.get("glFiscalTypeId");
        String glJournalName = (String) context.get("glJournalName");
        Boolean forceRepost = (Boolean) context.get("forceRepost");

        if (UtilValidate.isEmpty(payrollRunId)) return ServiceUtil.returnError("payrollRunId is required");

        boolean beganTx = false;
        try {
            beganTx = TransactionUtil.begin();

            GenericValue run = mustGetRun(delegator, payrollRunId);

            // derive org from run if not provided
            if (UtilValidate.isEmpty(organizationPartyId)) {
                organizationPartyId = run.getString("organizationPartyId");
            }
            requireOrg(organizationPartyId);

            assertRunPostable(run);

            // Idempotency
            GenericValue posting = getOrCreatePosting(delegator, organizationPartyId, payrollRunId, "GL");
            if (isAlreadyPosted(posting) && !Boolean.TRUE.equals(forceRepost)) {
                TransactionUtil.commit(beganTx);
                Map<String, Object> ok = ServiceUtil.returnSuccess("Already posted to GL");
                ok.put("payrollPostingId", posting.getString("payrollPostingId"));
                ok.put("glJournalId", posting.getString("glJournalId"));
                return ok;
            }

            // Load lines grouped by lineTypeId and DR/CR based on mapping
            List<PayrollAmountLine> aggLines = aggregatePayrollLines(delegator, organizationPartyId, payrollRunId);

            if (aggLines.isEmpty()) {
                posting.set("statusId", POSTING_ERROR);
                posting.set("errorMessage", "No payroll result lines found to post");
                posting.store();
                audit(dispatcher, userLogin, organizationPartyId, "POST_GL_ERR", "PayrollPosting",
                        posting.getString("payrollPostingId"), null, "No lines", null);
                TransactionUtil.commit(beganTx);
                return ServiceUtil.returnError("No payroll result lines found for run " + payrollRunId);
            }

            // Apply GL mapping: lineTypeId -> glAccountId, drCrFlag
            List<GlPostingLine> glLines = buildGlLinesFromMapping(delegator, organizationPartyId, aggLines);

            // Build balanced journal: if not balanced, error (mapping wrong)
            assertBalanced(glLines);

            String acctgTransId = createAcctgTrans(delegator, organizationPartyId, payrollRunId,
                    glFiscalTypeId, glJournalName, userLogin);

            createAcctgTransEntries(delegator, acctgTransId, glLines, userLogin);

            // Mark posting
            posting.set("statusId", POSTING_POSTED);
            posting.set("postedDate", UtilDateTime.nowTimestamp());
            posting.set("glJournalId", acctgTransId);
            posting.set("errorMessage", null);
            posting.store();

            // Optionally mark run posted
            markRunPosted(delegator, run, userLogin);

            audit(dispatcher, userLogin, organizationPartyId, "POST_GL_OK", "PayrollRun", payrollRunId,
                    null, "acctgTransId=" + acctgTransId, null);

            TransactionUtil.commit(beganTx);

            Map<String, Object> out = ServiceUtil.returnSuccess();
            out.put("payrollPostingId", posting.getString("payrollPostingId"));
            out.put("glJournalId", acctgTransId);
            return out;

        } catch (Exception e) {
            rollbackQuiet(beganTx, e);
            Debug.logError(e, "postPayrollRunToGl failed", MODULE);
            return ServiceUtil.returnError("postPayrollRunToGl failed: " + e.getMessage());
        }
    }

    // =========================================================
    // Public Service: postPayrollRunToInvoice
    // =========================================================
    public static Map<String, Object> postPayrollRunToInvoice(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        LocalDispatcher dispatcher = dctx.getDispatcher();
        GenericValue userLogin = (GenericValue) context.get("userLogin");

        String payrollRunId = (String) context.get("payrollRunId");
        String organizationPartyId = firstOrg(context);
        String vendorPartyId = (String) context.get("vendorPartyId");
        String invoiceTypeId = (String) context.get("invoiceTypeId");
        Boolean forceRepost = (Boolean) context.get("forceRepost");

        if (UtilValidate.isEmpty(payrollRunId)) return ServiceUtil.returnError("payrollRunId is required");

        boolean beganTx = false;
        try {
            beganTx = TransactionUtil.begin();

            GenericValue run = mustGetRun(delegator, payrollRunId);

            if (UtilValidate.isEmpty(organizationPartyId)) {
                organizationPartyId = run.getString("organizationPartyId");
            }
            requireOrg(organizationPartyId);

            assertRunPostable(run);

            // Vendor: optional, but required to create AP invoice
            if (UtilValidate.isEmpty(vendorPartyId)) {
                vendorPartyId = resolveOrgVendor(delegator, organizationPartyId);
            }
            if (UtilValidate.isEmpty(vendorPartyId)) {
                return ServiceUtil.returnError("vendorPartyId is required (or configure per-org vendor in PayrollOrganization)");
            }
            if (UtilValidate.isEmpty(invoiceTypeId)) invoiceTypeId = DEFAULT_INVOICE_TYPE;

            // Idempotency
            GenericValue posting = getOrCreatePosting(delegator, organizationPartyId, payrollRunId, "INVOICE");
            if (isAlreadyPosted(posting) && !Boolean.TRUE.equals(forceRepost)) {
                TransactionUtil.commit(beganTx);
                Map<String, Object> ok = ServiceUtil.returnSuccess("Already posted to Invoice");
                ok.put("payrollPostingId", posting.getString("payrollPostingId"));
                ok.put("invoiceId", posting.getString("invoiceId"));
                return ok;
            }

            List<PayrollAmountLine> aggLines = aggregatePayrollLines(delegator, organizationPartyId, payrollRunId);
            if (aggLines.isEmpty()) {
                posting.set("statusId", POSTING_ERROR);
                posting.set("errorMessage", "No payroll result lines found to post");
                posting.store();
                audit(dispatcher, userLogin, organizationPartyId, "POST_INV_ERR", "PayrollPosting",
                        posting.getString("payrollPostingId"), null, "No lines", null);
                TransactionUtil.commit(beganTx);
                return ServiceUtil.returnError("No payroll result lines found for run " + payrollRunId);
            }

            // Map to invoice item types
            List<InvoicePostingLine> invLines = buildInvoiceLinesFromMapping(delegator, organizationPartyId, aggLines);

            String invoiceId = createInvoice(delegator, organizationPartyId, vendorPartyId, invoiceTypeId, run, userLogin);

            createInvoiceItems(delegator, invoiceId, invLines, run, userLogin);

            posting.set("statusId", POSTING_POSTED);
            posting.set("postedDate", UtilDateTime.nowTimestamp());
            posting.set("invoiceId", invoiceId);
            posting.set("errorMessage", null);
            posting.store();

            markRunPosted(delegator, run, userLogin);

            audit(dispatcher, userLogin, organizationPartyId, "POST_INV_OK", "PayrollRun", payrollRunId,
                    null, "invoiceId=" + invoiceId, null);

            TransactionUtil.commit(beganTx);

            Map<String, Object> out = ServiceUtil.returnSuccess();
            out.put("payrollPostingId", posting.getString("payrollPostingId"));
            out.put("invoiceId", invoiceId);
            return out;

        } catch (Exception e) {
            rollbackQuiet(beganTx, e);
            Debug.logError(e, "postPayrollRunToInvoice failed", MODULE);
            return ServiceUtil.returnError("postPayrollRunToInvoice failed: " + e.getMessage());
        }
    }

    // =========================================================
    // Helpers: Run checks + org
    // =========================================================
    private static String firstOrg(Map<String, ?> context) {
        String organizationPartyId = (String) context.get("organizationPartyId");
        if (UtilValidate.isEmpty(organizationPartyId)) organizationPartyId = (String) context.get("orgPartyId");
        return organizationPartyId;
    }

    private static void requireOrg(String organizationPartyId) {
        if (UtilValidate.isEmpty(organizationPartyId)) throw new IllegalArgumentException("organizationPartyId is required");
    }

    private static GenericValue mustGetRun(Delegator delegator, String payrollRunId) throws GenericEntityException {
        GenericValue run = EntityQuery.use(delegator).from("PayrollRun").where("payrollRunId", payrollRunId).queryOne();
        if (run == null) throw new IllegalArgumentException("PayrollRun not found: " + payrollRunId);
        return run;
    }

    private static void assertRunPostable(GenericValue run) {
        String st = run.getString("statusId");
        if (!RUN_STATUS_APPROVED.equals(st) && !RUN_STATUS_POSTED.equals(st)) {
            throw new IllegalArgumentException("PayrollRun must be APPROVED before posting. Current status=" + st);
        }
    }

    private static void markRunPosted(Delegator delegator, GenericValue run, GenericValue userLogin) throws GenericEntityException {
        // If already posted keep it posted
        if (RUN_STATUS_POSTED.equals(run.getString("statusId"))) return;
        run.set("statusId", RUN_STATUS_POSTED);
        if (hasField(delegator, "PayrollRun", "postedDate")) run.set("postedDate", UtilDateTime.nowTimestamp());
        if (hasField(delegator, "PayrollRun", "postedByUserLoginId") && userLogin != null) {
            run.set("postedByUserLoginId", userLogin.getString("userLoginId"));
        }
        run.store();
    }

    private static boolean hasField(Delegator delegator, String entityName, String fieldName) {
        try {
            return delegator.getModelEntity(entityName).isField(fieldName);
        } catch (Exception e) {
            return false;
        }
    }

    // =========================================================
    // Idempotency: PayrollPosting entity (recommended)
    // =========================================================
    private static GenericValue getOrCreatePosting(Delegator delegator, String organizationPartyId, String payrollRunId, String postTarget)
            throws GenericEntityException {

        // If you don't have PayrollPosting entity, you MUST create it. This code assumes it exists.
        GenericValue posting = EntityQuery.use(delegator).from("PayrollPosting")
                .where("organizationPartyId", organizationPartyId,
                       "payrollRunId", payrollRunId,
                       "postTarget", postTarget)
                .queryFirst();

        if (posting == null) {
            posting = delegator.makeValue("PayrollPosting");
            posting.set("payrollPostingId", delegator.getNextSeqId("PayrollPosting"));
            posting.set("organizationPartyId", organizationPartyId);
            posting.set("payrollRunId", payrollRunId);
            posting.set("postTarget", postTarget); // "GL" or "INVOICE"
            posting.set("statusId", POSTING_NEW);
            posting.set("createdDate", UtilDateTime.nowTimestamp());
            delegator.create(posting);
        }
        return posting;
    }

    private static boolean isAlreadyPosted(GenericValue posting) {
        return posting != null && POSTING_POSTED.equals(posting.getString("statusId"));
    }

    // =========================================================
    // Load + aggregate payroll result lines for a run
    // =========================================================
    private static List<PayrollAmountLine> aggregatePayrollLines(Delegator delegator, String organizationPartyId, String payrollRunId)
            throws GenericEntityException {

        // Join:
        // EmployeePayrollResult (org + run) -> EmployeePayrollResultLine (org + payrollResultId)
        List<GenericValue> results = EntityQuery.use(delegator).from("EmployeePayrollResult")
                .where("organizationPartyId", organizationPartyId, "payrollRunId", payrollRunId)
                .queryList();

        Map<String, BigDecimal> sumByLineType = new LinkedHashMap<>();
        String currencyUomId = null;

        for (GenericValue r : results) {
            if (currencyUomId == null && hasField(delegator, "EmployeePayrollResult", "currencyUomId")) {
                currencyUomId = r.getString("currencyUomId");
            }
            String payrollResultId = r.getString("payrollResultId");

            List<GenericValue> lines = EntityQuery.use(delegator).from("EmployeePayrollResultLine")
                    .where("organizationPartyId", organizationPartyId, "payrollResultId", payrollResultId)
                    .queryList();

            for (GenericValue l : lines) {
                String lineTypeId = l.getString("lineTypeId");
                BigDecimal amt = nvl(l.getBigDecimal("amount"));
                // Note: your lines store deductions negative already in workflow; keep as-is
                sumByLineType.put(lineTypeId, nvl(sumByLineType.get(lineTypeId)).add(amt));
                if (currencyUomId == null && hasField(delegator, "EmployeePayrollResultLine", "currencyUomId")) {
                    currencyUomId = l.getString("currencyUomId");
                }
            }
        }

        if (UtilValidate.isEmpty(currencyUomId)) currencyUomId = DEFAULT_CURRENCY_UOM;

        List<PayrollAmountLine> out = new ArrayList<>();
        for (Map.Entry<String, BigDecimal> e : sumByLineType.entrySet()) {
            if (e.getValue().compareTo(BigDecimal.ZERO) == 0) continue;
            out.add(new PayrollAmountLine(e.getKey(), e.getValue().setScale(2, RoundingMode.HALF_UP), currencyUomId));
        }
        return out;
    }

    // =========================================================
    // GL mapping + GL posting
    // =========================================================
    private static List<GlPostingLine> buildGlLinesFromMapping(Delegator delegator, String organizationPartyId, List<PayrollAmountLine> aggLines)
            throws GenericEntityException {

        List<GlPostingLine> glLines = new ArrayList<>();

        for (PayrollAmountLine pl : aggLines) {
            // Find active mapping for this lineTypeId
            GenericValue map = EntityQuery.use(delegator).from("PayrollGlMapping")
                    .where(EntityCondition.makeCondition(Arrays.asList(
                            EntityCondition.makeCondition("organizationPartyId", EntityOperator.EQUALS, organizationPartyId),
                            EntityCondition.makeCondition("lineTypeId", EntityOperator.EQUALS, pl.lineTypeId),
                            EntityCondition.makeCondition("isActive", EntityOperator.EQUALS, "Y")
                    ), EntityOperator.AND))
                    .orderBy("-fromDate")
                    .queryFirst();

            if (map == null) {
                throw new IllegalArgumentException("Missing PayrollGlMapping for lineTypeId=" + pl.lineTypeId + " (org=" + organizationPartyId + ")");
            }

            String glAccountId = map.getString("glAccountId");
            String drCrFlag = map.getString("drCrFlag"); // "D" or "C"
            if (UtilValidate.isEmpty(glAccountId) || UtilValidate.isEmpty(drCrFlag)) {
                throw new IllegalArgumentException("Invalid PayrollGlMapping for lineTypeId=" + pl.lineTypeId);
            }

            BigDecimal amt = pl.amount.abs().setScale(2, RoundingMode.HALF_UP);

            // If your line is negative, mapping still determines side. We use abs() here.
            glLines.add(new GlPostingLine(glAccountId, drCrFlag, amt, pl.currencyUomId, pl.lineTypeId));
        }

        return glLines;
    }

    private static void assertBalanced(List<GlPostingLine> glLines) {
        BigDecimal dr = BigDecimal.ZERO;
        BigDecimal cr = BigDecimal.ZERO;
        for (GlPostingLine l : glLines) {
            if ("D".equalsIgnoreCase(l.drCrFlag)) dr = dr.add(l.amount);
            else if ("C".equalsIgnoreCase(l.drCrFlag)) cr = cr.add(l.amount);
            else throw new IllegalArgumentException("Invalid drCrFlag: " + l.drCrFlag);
        }
        if (dr.setScale(2, RoundingMode.HALF_UP).compareTo(cr.setScale(2, RoundingMode.HALF_UP)) != 0) {
            throw new IllegalArgumentException("GL journal not balanced. DR=" + dr + " CR=" + cr + ". Fix mappings.");
        }
    }

    private static String createAcctgTrans(Delegator delegator,
                                          String organizationPartyId,
                                          String payrollRunId,
                                          String glFiscalTypeId,
                                          String glJournalName,
                                          GenericValue userLogin) throws GenericEntityException {

        String acctgTransId = delegator.getNextSeqId("AcctgTrans");
        GenericValue at = delegator.makeValue("AcctgTrans");
        at.set("acctgTransId", acctgTransId);

        // You may want a specific trans type for payroll
        at.set("acctgTransTypeId", DEFAULT_ACCTG_TRANS_TYPE);

        // transactionDate + entryDate
        Timestamp now = UtilDateTime.nowTimestamp();
        if (hasField(delegator, "AcctgTrans", "transactionDate")) at.set("transactionDate", now);
        if (hasField(delegator, "AcctgTrans", "entryDate")) at.set("entryDate", now);

        // description reference
        if (hasField(delegator, "AcctgTrans", "description")) {
            at.set("description", "Payroll Run Posting: " + payrollRunId);
        }

        if (UtilValidate.isNotEmpty(glFiscalTypeId) && hasField(delegator, "AcctgTrans", "glFiscalTypeId")) {
            at.set("glFiscalTypeId", glFiscalTypeId);
        }
        if (UtilValidate.isNotEmpty(glJournalName) && hasField(delegator, "AcctgTrans", "glJournalName")) {
            at.set("glJournalName", glJournalName);
        }

        // Optional: link to org as partyId if your accounting uses partyId
        if (hasField(delegator, "AcctgTrans", "partyId")) {
            at.set("partyId", organizationPartyId);
        }

        if (userLogin != null && hasField(delegator, "AcctgTrans", "createdByUserLogin")) {
            at.set("createdByUserLogin", userLogin.getString("userLoginId"));
        }

        delegator.create(at);
        return acctgTransId;
    }

    private static void createAcctgTransEntries(Delegator delegator, String acctgTransId, List<GlPostingLine> lines, GenericValue userLogin)
            throws GenericEntityException {

        long seq = 1;
        for (GlPostingLine l : lines) {
            String entryId = delegator.getNextSeqId("AcctgTransEntry");
            GenericValue e = delegator.makeValue("AcctgTransEntry");
            e.set("acctgTransEntryId", entryId);
            e.set("acctgTransId", acctgTransId);

            if (hasField(delegator, "AcctgTransEntry", "acctgTransEntrySeqId")) {
                e.set("acctgTransEntrySeqId", String.valueOf(seq++));
            }

            e.set("glAccountId", l.glAccountId);

            // Debit/Credit
            if ("D".equalsIgnoreCase(l.drCrFlag)) {
                if (hasField(delegator, "AcctgTransEntry", "debitCreditFlag")) e.set("debitCreditFlag", "D");
                if (hasField(delegator, "AcctgTransEntry", "amount")) e.set("amount", l.amount);
                if (hasField(delegator, "AcctgTransEntry", "debitAmount")) e.set("debitAmount", l.amount);
            } else {
                if (hasField(delegator, "AcctgTransEntry", "debitCreditFlag")) e.set("debitCreditFlag", "C");
                if (hasField(delegator, "AcctgTransEntry", "amount")) e.set("amount", l.amount);
                if (hasField(delegator, "AcctgTransEntry", "creditAmount")) e.set("creditAmount", l.amount);
            }

            if (hasField(delegator, "AcctgTransEntry", "currencyUomId")) e.set("currencyUomId", l.currencyUomId);

            if (hasField(delegator, "AcctgTransEntry", "description")) {
                e.set("description", "Payroll " + l.lineTypeId);
            }

            if (userLogin != null && hasField(delegator, "AcctgTransEntry", "createdByUserLogin")) {
                e.set("createdByUserLogin", userLogin.getString("userLoginId"));
            }

            delegator.create(e);
        }
    }

    // =========================================================
    // Invoice mapping + invoice posting
    // =========================================================
    private static List<InvoicePostingLine> buildInvoiceLinesFromMapping(Delegator delegator, String organizationPartyId, List<PayrollAmountLine> aggLines)
            throws GenericEntityException {

        List<InvoicePostingLine> inv = new ArrayList<>();

        for (PayrollAmountLine pl : aggLines) {
            GenericValue map = EntityQuery.use(delegator).from("PayrollInvoiceMapping")
                    .where(EntityCondition.makeCondition(Arrays.asList(
                            EntityCondition.makeCondition("organizationPartyId", EntityOperator.EQUALS, organizationPartyId),
                            EntityCondition.makeCondition("lineTypeId", EntityOperator.EQUALS, pl.lineTypeId),
                            EntityCondition.makeCondition("isActive", EntityOperator.EQUALS, "Y")
                    ), EntityOperator.AND))
                    .orderBy("-fromDate")
                    .queryFirst();

            if (map == null) {
                throw new IllegalArgumentException("Missing PayrollInvoiceMapping for lineTypeId=" + pl.lineTypeId + " (org=" + organizationPartyId + ")");
            }

            String invoiceItemTypeId = map.getString("invoiceItemTypeId");
            if (UtilValidate.isEmpty(invoiceItemTypeId)) {
                throw new IllegalArgumentException("Invalid PayrollInvoiceMapping for lineTypeId=" + pl.lineTypeId);
            }

            // Invoice items usually use positive amounts
            BigDecimal amt = pl.amount.abs().setScale(2, RoundingMode.HALF_UP);
            if (amt.compareTo(BigDecimal.ZERO) == 0) continue;

            inv.add(new InvoicePostingLine(invoiceItemTypeId, amt, pl.currencyUomId, pl.lineTypeId));
        }
        return inv;
    }

    private static String createInvoice(Delegator delegator,
                                        String organizationPartyId,
                                        String vendorPartyId,
                                        String invoiceTypeId,
                                        GenericValue run,
                                        GenericValue userLogin) throws GenericEntityException {

        String invoiceId = delegator.getNextSeqId("Invoice");
        GenericValue inv = delegator.makeValue("Invoice");
        inv.set("invoiceId", invoiceId);

        inv.set("invoiceTypeId", invoiceTypeId);
        if (hasField(delegator, "Invoice", "invoiceDate")) inv.set("invoiceDate", UtilDateTime.nowTimestamp());

        // Common fields: partyIdFrom (vendor), partyId (org / bill-to)
        if (hasField(delegator, "Invoice", "partyIdFrom")) inv.set("partyIdFrom", vendorPartyId);
        if (hasField(delegator, "Invoice", "partyId")) inv.set("partyId", organizationPartyId);

        if (hasField(delegator, "Invoice", "description")) {
            inv.set("description", "Payroll Run " + run.getString("payrollRunId"));
        }

        // Currency
        String currencyUomId = run.getString("currencyUomId");
        if (UtilValidate.isEmpty(currencyUomId)) currencyUomId = DEFAULT_CURRENCY_UOM;
        if (hasField(delegator, "Invoice", "currencyUomId")) inv.set("currencyUomId", currencyUomId);

        if (userLogin != null && hasField(delegator, "Invoice", "createdByUserLogin")) {
            inv.set("createdByUserLogin", userLogin.getString("userLoginId"));
        }

        delegator.create(inv);
        return invoiceId;
    }

    private static void createInvoiceItems(Delegator delegator,
                                          String invoiceId,
                                          List<InvoicePostingLine> lines,
                                          GenericValue run,
                                          GenericValue userLogin) throws GenericEntityException {

        String currencyUomId = run.getString("currencyUomId");
        if (UtilValidate.isEmpty(currencyUomId)) currencyUomId = DEFAULT_CURRENCY_UOM;

        long seq = 1;
        for (InvoicePostingLine l : lines) {
            String itemSeqId = String.format("%05d", seq++);

            GenericValue ii = delegator.makeValue("InvoiceItem");
            ii.set("invoiceId", invoiceId);
            ii.set("invoiceItemSeqId", itemSeqId);
            ii.set("invoiceItemTypeId", l.invoiceItemTypeId);

            if (hasField(delegator, "InvoiceItem", "quantity")) ii.set("quantity", BigDecimal.ONE);
            if (hasField(delegator, "InvoiceItem", "amount")) ii.set("amount", l.amount);
            if (hasField(delegator, "InvoiceItem", "currencyUomId")) ii.set("currencyUomId", currencyUomId);

            if (hasField(delegator, "InvoiceItem", "description")) {
                ii.set("description", "Payroll " + l.lineTypeId);
            }

            if (userLogin != null && hasField(delegator, "InvoiceItem", "createdByUserLogin")) {
                ii.set("createdByUserLogin", userLogin.getString("userLoginId"));
            }

            delegator.create(ii);
        }
    }

    private static String resolveOrgVendor(Delegator delegator, String organizationPartyId) {
        try {
            GenericValue org = EntityQuery.use(delegator).from("PayrollOrganization")
                    .where("organizationPartyId", organizationPartyId)
                    .queryFirst();
            if (org == null) return null;
            // adjust field name based on your entity model
            if (org.getModelEntity().isField("payrollVendorPartyId")) return org.getString("payrollVendorPartyId");
            if (org.getModelEntity().isField("vendorPartyId")) return org.getString("vendorPartyId");
            return null;
        } catch (Exception e) {
            return null;
        }
    }

    // =========================================================
    // Audit helper: uses service if available
    // =========================================================
    private static void audit(LocalDispatcher dispatcher, GenericValue userLogin, String organizationPartyId,
                              String eventTypeId, String entityName, String recordId,
                              String oldValue, String newValue, String sourceIp) {
        try {
            Map<String, Object> ctx = UtilMisc.toMap(
                    "organizationPartyId", organizationPartyId,
                    "eventTypeId", eventTypeId,
                    "entityName", entityName,
                    "recordId", recordId,
                    "oldValue", oldValue,
                    "newValue", newValue,
                    "sourceIp", sourceIp,
                    "userLogin", userLogin
            );
            dispatcher.runSync("recordPayrollAuditEvent", ctx);
        } catch (Exception ignored) {
            // Never block posting for audit
        }
    }

    // =========================================================
    // Utility
    // =========================================================
    private static void rollbackQuiet(boolean beganTx, Exception e) {
        try {
            if (beganTx) TransactionUtil.rollback(beganTx, e.getMessage(), e);
        } catch (Exception ignored) {}
    }

    private static BigDecimal nvl(BigDecimal v) {
        return v == null ? BigDecimal.ZERO : v;
    }

    // =========================================================
    // Data structures
    // =========================================================
    private static final class PayrollAmountLine {
        final String lineTypeId;
        final BigDecimal amount;
        final String currencyUomId;
        PayrollAmountLine(String lineTypeId, BigDecimal amount, String currencyUomId) {
            this.lineTypeId = lineTypeId;
            this.amount = amount;
            this.currencyUomId = currencyUomId;
        }
    }

    private static final class GlPostingLine {
        final String glAccountId;
        final String drCrFlag; // D/C
        final BigDecimal amount;
        final String currencyUomId;
        final String lineTypeId;
        GlPostingLine(String glAccountId, String drCrFlag, BigDecimal amount, String currencyUomId, String lineTypeId) {
            this.glAccountId = glAccountId;
            this.drCrFlag = drCrFlag;
            this.amount = amount;
            this.currencyUomId = currencyUomId;
            this.lineTypeId = lineTypeId;
        }
    }

    private static final class InvoicePostingLine {
        final String invoiceItemTypeId;
        final BigDecimal amount;
        final String currencyUomId;
        final String lineTypeId;
        InvoicePostingLine(String invoiceItemTypeId, BigDecimal amount, String currencyUomId, String lineTypeId) {
            this.invoiceItemTypeId = invoiceItemTypeId;
            this.amount = amount;
            this.currencyUomId = currencyUomId;
            this.lineTypeId = lineTypeId;
        }
    }
}
