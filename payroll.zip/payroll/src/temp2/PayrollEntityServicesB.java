package org.apache.ofbiz.payroll.services;

import org.apache.ofbiz.base.util.Debug;
import org.apache.ofbiz.base.util.UtilDateTime;
import org.apache.ofbiz.base.util.UtilValidate;
import org.apache.ofbiz.entity.Delegator;
import org.apache.ofbiz.entity.GenericEntityException;
import org.apache.ofbiz.entity.GenericValue;
import org.apache.ofbiz.entity.model.ModelEntity;
import org.apache.ofbiz.entity.transaction.TransactionUtil;
import org.apache.ofbiz.entity.util.EntityQuery;
import org.apache.ofbiz.service.DispatchContext;
import org.apache.ofbiz.service.ServiceUtil;

import java.sql.Timestamp;
import java.util.*;

public class PayrollEntityServices {
    public static final String MODULE = PayrollEntityServices.class.getName();

    // ✅ strict mode: reject unknown fields instead of silently ignoring
    private static final boolean STRICT_FIELD_MODE = true;

    // safety whitelist
    private static final Set<String> ALLOWED_ENTITIES = PayrollStrictRules.TENANT_ENTITIES; // simplest: same set
    // If you have non-tenant entities too, add them here.

    // ============ GENERIC CRUD ============

    public static Map<String, Object> createEntity(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        String entityName = (String) context.get("entityName");
        GenericValue userLogin = (GenericValue) context.get("userLogin");
        String orgPartyId = (String) context.get("orgPartyId");

        Map<String, Object> fields = extractFields(delegator, entityName, context);

        if (!isAllowed(entityName)) return ServiceUtil.returnError("Entity not allowed: " + entityName);

        boolean beganTx = false;
        try {
            beganTx = TransactionUtil.begin();

            PayrollStrictRules.enforceTenant(delegator, entityName, fields, orgPartyId);

            GenericValue value = delegator.makeValue(entityName);
            setFieldsStrict(delegator, entityName, value, fields);

            setMissingPrimaryKeyIfPossible(delegator, entityName, value);

            // audit stamp style (if your entity has these fields)
            if (hasField(delegator, entityName, "createdDate") && value.get("createdDate") == null) {
                value.set("createdDate", UtilDateTime.nowTimestamp());
            }
            if (hasField(delegator, entityName, "createdByUserLoginId") && value.get("createdByUserLoginId") == null && userLogin != null) {
                value.set("createdByUserLoginId", userLogin.getString("userLoginId"));
            }

            value.create();

            Map<String, Object> out = ServiceUtil.returnSuccess();
            out.put("recordId", firstPkValue(delegator, entityName, value));

            TransactionUtil.commit(beganTx);
            return out;
        } catch (Exception e) {
            TransactionUtil.rollback(beganTx, e.getMessage(), e);
            Debug.logError(e, "createEntity failed: " + entityName, MODULE);
            return ServiceUtil.returnError("createEntity failed for " + entityName + ": " + e.getMessage());
        }
    }

    public static Map<String, Object> updateEntity(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        String entityName = (String) context.get("entityName");
        GenericValue userLogin = (GenericValue) context.get("userLogin");
        String orgPartyId = (String) context.get("orgPartyId");

        if (!isAllowed(entityName)) return ServiceUtil.returnError("Entity not allowed: " + entityName);

        Map<String, Object> pk = extractPk(delegator, entityName, context);
        Map<String, Object> fields = extractFields(delegator, entityName, context);

        boolean beganTx = false;
        try {
            beganTx = TransactionUtil.begin();

            PayrollStrictRules.enforceTenant(delegator, entityName, pk, orgPartyId);

            GenericValue existing = EntityQuery.use(delegator).from(entityName).where(pk).queryOne();
            if (existing == null) return ServiceUtil.returnError("Record not found: " + entityName + " pk=" + pk);

            // Optional lock rule: block updates if record has isLocked=Y
            if (hasField(delegator, entityName, "isLocked") && "Y".equals(existing.getString("isLocked"))) {
                return ServiceUtil.returnError("Record is locked and cannot be updated: " + entityName + " pk=" + pk);
            }

            PayrollStrictRules.enforceTenant(delegator, entityName, fields, orgPartyId);
            setFieldsStrict(delegator, entityName, existing, fields);

            if (hasField(delegator, entityName, "lastModifiedDate")) {
                existing.set("lastModifiedDate", UtilDateTime.nowTimestamp());
            }
            if (hasField(delegator, entityName, "lastModifiedByUserLoginId") && userLogin != null) {
                existing.set("lastModifiedByUserLoginId", userLogin.getString("userLoginId"));
            }

            existing.store();

            TransactionUtil.commit(beganTx);
            return ServiceUtil.returnSuccess();
        } catch (Exception e) {
            TransactionUtil.rollback(beganTx, e.getMessage(), e);
            Debug.logError(e, "updateEntity failed: " + entityName, MODULE);
            return ServiceUtil.returnError("updateEntity failed for " + entityName + ": " + e.getMessage());
        }
    }

    public static Map<String, Object> deleteEntity(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        String entityName = (String) context.get("entityName");
        String orgPartyId = (String) context.get("orgPartyId");

        if (!isAllowed(entityName)) return ServiceUtil.returnError("Entity not allowed: " + entityName);

        Map<String, Object> pk = extractPk(delegator, entityName, context);

        boolean beganTx = false;
        try {
            beganTx = TransactionUtil.begin();

            PayrollStrictRules.enforceTenant(delegator, entityName, pk, orgPartyId);

            GenericValue existing = EntityQuery.use(delegator).from(entityName).where(pk).queryOne();
            if (existing == null) return ServiceUtil.returnError("Record not found: " + entityName + " pk=" + pk);

            if (hasField(delegator, entityName, "isLocked") && "Y".equals(existing.getString("isLocked"))) {
                return ServiceUtil.returnError("Record is locked and cannot be deleted: " + entityName + " pk=" + pk);
            }

            existing.remove();

            TransactionUtil.commit(beganTx);
            return ServiceUtil.returnSuccess();
        } catch (Exception e) {
            TransactionUtil.rollback(beganTx, e.getMessage(), e);
            Debug.logError(e, "deleteEntity failed: " + entityName, MODULE);
            return ServiceUtil.returnError("deleteEntity failed for " + entityName + ": " + e.getMessage());
        }
    }

    public static Map<String, Object> findEntity(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        String entityName = (String) context.get("entityName");
        String orgPartyId = (String) context.get("orgPartyId");

        if (!isAllowed(entityName)) return ServiceUtil.returnError("Entity not allowed: " + entityName);

        try {
            Map<String, Object> pk = extractPk(delegator, entityName, context);
            PayrollStrictRules.enforceTenant(delegator, entityName, pk, orgPartyId);

            GenericValue gv = EntityQuery.use(delegator).from(entityName).where(pk).queryOne();

            Map<String, Object> out = ServiceUtil.returnSuccess();
            out.put("record", gv == null ? null : gv.getAllFields());
            return out;
        } catch (Exception e) {
            Debug.logError(e, "findEntity failed: " + entityName, MODULE);
            return ServiceUtil.returnError("findEntity failed for " + entityName + ": " + e.getMessage());
        }
    }

    public static Map<String, Object> listEntity(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        String entityName = (String) context.get("entityName");
        String orgPartyId = (String) context.get("orgPartyId");

        if (!isAllowed(entityName)) return ServiceUtil.returnError("Entity not allowed: " + entityName);

        Integer viewSize = (Integer) context.get("viewSize");
        Integer viewIndex = (Integer) context.get("viewIndex");
        @SuppressWarnings("unchecked")
        List<String> orderBy = (List<String>) context.get("orderBy");

        try {
            Map<String, Object> filters = extractFilters(delegator, entityName, context);
            if (filters == null) filters = new HashMap<>();
            PayrollStrictRules.enforceTenant(delegator, entityName, filters, orgPartyId);

            int size = (viewSize == null || viewSize <= 0) ? 50 : viewSize;
            int index = (viewIndex == null || viewIndex < 0) ? 0 : viewIndex;
            int offset = index * size;

            EntityQuery q = EntityQuery.use(delegator).from(entityName).where(filters);
            if (orderBy != null && !orderBy.isEmpty()) q = q.orderBy(orderBy);

            List<GenericValue> all = q.queryList();
            int total = all.size();

            List<Map<String, Object>> page = new ArrayList<>();
            for (int i = offset; i < Math.min(offset + size, total); i++) {
                page.add(all.get(i).getAllFields());
            }

            Map<String, Object> out = ServiceUtil.returnSuccess();
            out.put("list", page);
            out.put("listSize", total);
            return out;
        } catch (Exception e) {
            Debug.logError(e, "listEntity failed: " + entityName, MODULE);
            return ServiceUtil.returnError("listEntity failed for " + entityName + ": " + e.getMessage());
        }
    }

    // =========================
    // Per-entity wrappers
    // (Keep same signatures as before)
    // =========================
    private static Map<String, Object> createWrap(DispatchContext dctx, Map<String, ?> ctx, String entity) {
        Map<String, Object> m = new HashMap<>();
        m.put("entityName", entity);
        m.putAll(ctx);
        return createEntity(dctx, m);
    }
    private static Map<String, Object> updateWrap(DispatchContext dctx, Map<String, ?> ctx, String entity) {
        Map<String, Object> m = new HashMap<>();
        m.put("entityName", entity);
        m.putAll(ctx);
        return updateEntity(dctx, m);
    }
    private static Map<String, Object> deleteWrap(DispatchContext dctx, Map<String, ?> ctx, String entity) {
        Map<String, Object> m = new HashMap<>();
        m.put("entityName", entity);
        m.putAll(ctx);
        return deleteEntity(dctx, m);
    }
    private static Map<String, Object> findWrap(DispatchContext dctx, Map<String, ?> ctx, String entity) {
        Map<String, Object> m = new HashMap<>();
        m.put("entityName", entity);
        m.putAll(ctx);
        return findEntity(dctx, m);
    }
    private static Map<String, Object> listWrap(DispatchContext dctx, Map<String, ?> ctx, String entity) {
        Map<String, Object> m = new HashMap<>();
        m.put("entityName", entity);
        m.putAll(ctx);
        return listEntity(dctx, m);
    }

    // Example wrappers (you already have the full set in your project)
    public static Map<String, Object> createPayrollRun(DispatchContext dctx, Map<String, ?> c) { return createWrap(dctx, c, "PayrollRun"); }
    public static Map<String, Object> updatePayrollRun(DispatchContext dctx, Map<String, ?> c) { return updateWrap(dctx, c, "PayrollRun"); }
    public static Map<String, Object> deletePayrollRun(DispatchContext dctx, Map<String, ?> c) { return deleteWrap(dctx, c, "PayrollRun"); }
    public static Map<String, Object> findPayrollRun(DispatchContext dctx, Map<String, ?> c) { return findWrap(dctx, c, "PayrollRun"); }
    public static Map<String, Object> listPayrollRun(DispatchContext dctx, Map<String, ?> c) { return listWrap(dctx, c, "PayrollRun"); }

    // =========================
    // Internals
    // =========================
    private static boolean isAllowed(String entityName) {
        return UtilValidate.isNotEmpty(entityName) && ALLOWED_ENTITIES.contains(entityName);
    }

    private static boolean hasField(Delegator delegator, String entityName, String field) {
        return PayrollStrictRules.entityHasField(delegator, entityName, field);
    }

    private static Map<String, Object> extractPk(Delegator delegator, String entityName, Map<String, ?> ctx) throws Exception {
        Object pkObj = ctx.get("pk");
        if (pkObj instanceof Map) {
            @SuppressWarnings("unchecked") Map<String, Object> m = (Map<String, Object>) pkObj;
            return new HashMap<>(m);
        }
        ModelEntity me = delegator.getModelEntity(entityName);
        Map<String, Object> pk = new HashMap<>();
        for (String pkField : me.getPkFieldNames()) {
            Object v = ctx.get(pkField);
            if (v != null) pk.put(pkField, v);
        }
        if (pk.isEmpty()) throw new IllegalArgumentException("PK is required for " + entityName);
        return pk;
    }

    private static Map<String, Object> extractFields(Delegator delegator, String entityName, Map<String, ?> ctx) {
        Object fieldsObj = ctx.get("fields");
        Map<String, Object> out = new HashMap<>();
        if (fieldsObj instanceof Map) {
            @SuppressWarnings("unchecked") Map<String, Object> m = (Map<String, Object>) fieldsObj;
            out.putAll(m);
            return out;
        }
        // direct params
        for (Map.Entry<String, ?> e : ctx.entrySet()) {
            String k = e.getKey();
            if (Set.of("userLogin","locale","timeZone","entityName","pk","filters","orderBy","viewSize","viewIndex").contains(k)) continue;
            out.put(k, e.getValue());
        }
        return out;
    }

    private static Map<String, Object> extractFilters(Delegator delegator, String entityName, Map<String, ?> ctx) {
        Object filtersObj = ctx.get("filters");
        if (filtersObj instanceof Map) {
            @SuppressWarnings("unchecked") Map<String, Object> m = (Map<String, Object>) filtersObj;
            return new HashMap<>(m);
        }
        Map<String, Object> filters = new HashMap<>();
        // allow passing common filter fields directly
        for (String k : List.of("orgPartyId","statusId","partyId","payrollRunId","payrollPeriodId","payrollStructureId")) {
            if (ctx.get(k) != null) filters.put(k, ctx.get(k));
        }
        return filters.isEmpty() ? null : filters;
    }

    private static void setFieldsStrict(Delegator delegator, String entityName, GenericValue target, Map<String, Object> fields) throws Exception {
        ModelEntity me = delegator.getModelEntity(entityName);

        for (Map.Entry<String, Object> e : fields.entrySet()) {
            String fieldName = e.getKey();
            if (!me.isField(fieldName)) {
                if (STRICT_FIELD_MODE) {
                    throw new IllegalArgumentException("Unknown field for " + entityName + ": " + fieldName);
                }
                continue;
            }
            // never null out PK
            if (me.getPksByName().containsKey(fieldName) && e.getValue() == null) continue;
            target.set(fieldName, e.getValue());
        }
    }

    private static void setMissingPrimaryKeyIfPossible(Delegator delegator, String entityName, GenericValue value) throws GenericEntityException {
        ModelEntity me = delegator.getModelEntity(entityName);
        List<String> pks = me.getPkFieldNames();
        if (pks == null || pks.isEmpty()) return;

        if (pks.size() == 1) {
            String pk = pks.get(0);
            if (value.get(pk) == null) {
                value.set(pk, delegator.getNextSeqId(entityName));
            }
        }
    }

    private static String firstPkValue(Delegator delegator, String entityName, GenericValue value) throws Exception {
        ModelEntity me = delegator.getModelEntity(entityName);
        List<String> pks = me.getPkFieldNames();
        if (pks == null || pks.isEmpty()) return null;
        Object v = value.get(pks.get(0));
        return v == null ? null : String.valueOf(v);
    }
	
	
	public static Map<String, Object> createPayrollRunStrict(DispatchContext dctx, Map<String, ?> context) {
    try {
        Delegator delegator = dctx.getDelegator();
        String orgPartyId = (String) context.get("orgPartyId");
        String payrollPeriodId = (String) context.get("payrollPeriodId");
        String runTypeId = (String) context.get("runTypeId"); // if exists
        PayrollStrictRules.ensureUniquePayrollRun(delegator, orgPartyId, payrollPeriodId, runTypeId, null);
        // then call normal createPayrollRun
        return createPayrollRun(dctx, context);
    } catch (Exception e) {
        return ServiceUtil.returnError(e.getMessage());
    }
}

}
