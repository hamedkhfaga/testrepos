package org.apache.ofbiz.payroll.services;

import org.apache.ofbiz.base.util.Debug;
import org.apache.ofbiz.base.util.UtilValidate;
import org.apache.ofbiz.entity.*;
import org.apache.ofbiz.entity.model.ModelEntity;
import org.apache.ofbiz.entity.model.ModelField;
import org.apache.ofbiz.entity.util.EntityQuery;
import org.apache.ofbiz.service.DispatchContext;
import org.apache.ofbiz.service.ServiceUtil;

import java.util.*;

public class PayrollCrudServices {
    public static final String MODULE = PayrollCrudServices.class.getName();

    public static Map<String, Object> genericCreate(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        try {
            String entityName = (String) context.get("entityName");
            Map<String, Object> fields = castMap(context.get("fields"));

            if (UtilValidate.isEmpty(entityName) || fields == null) {
                return ServiceUtil.returnError("entityName and fields are required");
            }

            ModelEntity me = delegator.getModelEntity(entityName);
            if (me == null) return ServiceUtil.returnError("Unknown entityName: " + entityName);

            // build value
            GenericValue gv = delegator.makeValue(entityName);
            setAllowedFields(me, gv, fields);

            // auto PK if single id and missing
            List<String> pkFields = me.getPkFieldNames();
            if (pkFields.size() == 1) {
                String pk = pkFields.get(0);
                if (gv.get(pk) == null || UtilValidate.isEmpty(String.valueOf(gv.get(pk)))) {
                    gv.set(pk, delegator.getNextSeqId(entityName));
                }
            }

            delegator.create(gv);

            Map<String, Object> res = ServiceUtil.returnSuccess();
            Map<String, Object> pkOut = new HashMap<>();
            for (String pk : me.getPkFieldNames()) pkOut.put(pk, gv.get(pk));
            res.put("pk", pkOut);
            return res;

        } catch (Exception e) {
            Debug.logError(e, "genericCreate failed", MODULE);
            return ServiceUtil.returnError("genericCreate failed: " + e.getMessage());
        }
    }

    public static Map<String, Object> genericUpdate(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        try {
            String entityName = (String) context.get("entityName");
            Map<String, Object> pk = castMap(context.get("pk"));
            Map<String, Object> fields = castMap(context.get("fields"));

            if (UtilValidate.isEmpty(entityName) || pk == null || fields == null) {
                return ServiceUtil.returnError("entityName, pk, fields are required");
            }

            ModelEntity me = delegator.getModelEntity(entityName);
            GenericValue gv = EntityQuery.use(delegator).from(entityName).where(pk).queryOne();
            if (gv == null) return ServiceUtil.returnError("Record not found: " + entityName + " pk=" + pk);

            setAllowedFields(me, gv, fields);
            gv.store();

            return ServiceUtil.returnSuccess();

        } catch (Exception e) {
            Debug.logError(e, "genericUpdate failed", MODULE);
            return ServiceUtil.returnError("genericUpdate failed: " + e.getMessage());
        }
    }

    public static Map<String, Object> genericDelete(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        try {
            String entityName = (String) context.get("entityName");
            Map<String, Object> pk = castMap(context.get("pk"));

            if (UtilValidate.isEmpty(entityName) || pk == null) {
                return ServiceUtil.returnError("entityName and pk are required");
            }

            GenericValue gv = EntityQuery.use(delegator).from(entityName).where(pk).queryOne();
            if (gv == null) return ServiceUtil.returnError("Record not found: " + entityName + " pk=" + pk);

            gv.remove();
            return ServiceUtil.returnSuccess();

        } catch (Exception e) {
            Debug.logError(e, "genericDelete failed", MODULE);
            return ServiceUtil.returnError("genericDelete failed: " + e.getMessage());
        }
    }

    public static Map<String, Object> genericFindOne(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        try {
            String entityName = (String) context.get("entityName");
            Map<String, Object> pk = castMap(context.get("pk"));

            if (UtilValidate.isEmpty(entityName) || pk == null) {
                return ServiceUtil.returnError("entityName and pk are required");
            }

            GenericValue gv = EntityQuery.use(delegator).from(entityName).where(pk).queryOne();
            if (gv == null) return ServiceUtil.returnError("Record not found: " + entityName + " pk=" + pk);

            Map<String, Object> out = ServiceUtil.returnSuccess();
            out.put("record", gv.getAllFields());
            return out;

        } catch (Exception e) {
            Debug.logError(e, "genericFindOne failed", MODULE);
            return ServiceUtil.returnError("genericFindOne failed: " + e.getMessage());
        }
    }

    public static Map<String, Object> genericList(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        try {
            String entityName = (String) context.get("entityName");
            Map<String, Object> conditions = castMap(context.get("conditions"));
            List<String> orderBy = (List<String>) context.get("orderBy");
            Integer viewIndex = (Integer) context.get("viewIndex");
            Integer viewSize = (Integer) context.get("viewSize");

            if (UtilValidate.isEmpty(entityName)) {
                return ServiceUtil.returnError("entityName is required");
            }

            EntityQuery q = EntityQuery.use(delegator).from(entityName);
            if (conditions != null && !conditions.isEmpty()) q = q.where(conditions);
            if (orderBy != null && !orderBy.isEmpty()) q = q.orderBy(orderBy);

            // simple pagination
            int vi = viewIndex == null ? 0 : viewIndex;
            int vs = viewSize == null ? 50 : viewSize;
            EntityFindOptions efo = new EntityFindOptions();
            efo.setOffset(vi * vs);
            efo.setMaxRows(vs);

            List<GenericValue> list = q.queryList(efo);

            Map<String, Object> out = ServiceUtil.returnSuccess();
            out.put("list", list);
            out.put("listSize", list.size());
            return out;

        } catch (Exception e) {
            Debug.logError(e, "genericList failed", MODULE);
            return ServiceUtil.returnError("genericList failed: " + e.getMessage());
        }
    }

    private static void setAllowedFields(ModelEntity me, GenericValue gv, Map<String, Object> fields) {
        for (Map.Entry<String, Object> en : fields.entrySet()) {
            String fn = en.getKey();
            if (me.getField(fn) == null) continue; // ignore unknown fields (safe)
            ModelField mf = me.getField(fn);
            if (mf != null && mf.getIsAutoCreatedInternal()) continue; // safety
            gv.set(fn, en.getValue());
        }
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> castMap(Object o) {
        if (o == null) return null;
        return (Map<String, Object>) o;
    }
}
