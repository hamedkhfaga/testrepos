package org.apache.ofbiz.payroll.util;

import com.lowagie.text.pdf.Barcode128;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfTemplate;

public class BarcodeUtil {

    public static PdfTemplate generateCode128(PdfContentByte cb, String value) {
        Barcode128 barcode = new Barcode128();
        barcode.setCodeType(Barcode128.CODE128);
        barcode.setCode(value);
        barcode.setBarHeight(40f);
        barcode.setX(1.2f);
        return barcode.createTemplateWithBarcode(cb, null, null);
    }
}
