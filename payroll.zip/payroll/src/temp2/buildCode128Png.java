// Add to BarcodeUtil
import com.google.zxing.oned.Code128Writer;

public static byte[] buildCode128Png(String text, int widthPx, int heightPx) throws Exception {
    com.google.zxing.oned.Code128Writer w = new com.google.zxing.oned.Code128Writer();
    BitMatrix matrix = w.encode(text, BarcodeFormat.CODE_128, widthPx, heightPx);

    ByteArrayOutputStream out = new ByteArrayOutputStream();
    MatrixToImageWriter.writeToStream(matrix, "PNG", out);
    return out.toByteArray();
}
