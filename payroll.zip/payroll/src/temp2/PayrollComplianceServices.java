public static Map<String, Object> generatePayrollComplianceReport(DispatchContext dctx, Map<String, ?> ctx) {
    Delegator d = dctx.getDelegator();
    GenericValue u = (GenericValue) ctx.get("userLogin");

    String orgId = (String) ctx.get("organizationPartyId");
    Integer y = (Integer) ctx.get("periodYear");
    Integer m = (Integer) ctx.get("periodMonth");
    String type = (String) ctx.get("reportTypeId");

    if (UtilValidate.isAnyEmpty(orgId, y, m, type))
        return ServiceUtil.returnError("organizationPartyId, periodYear, periodMonth, reportTypeId required");

    try {
        String repId = d.getNextSeqId("PayrollComplianceReport");
        GenericValue rep = d.makeValue("PayrollComplianceReport");
        rep.set("payrollComplianceReportId", repId);
        rep.set("organizationPartyId", orgId);
        rep.set("reportTypeId", type);
        rep.set("periodYear", y);
        rep.set("periodMonth", m);
        rep.set("generatedDate", UtilDateTime.nowTimestamp());
        rep.set("generatedByUserLoginId", u != null ? u.getString("userLoginId") : null);
        rep.set("statusId", "REP_NEW");
        d.create(rep);

        // Example aggregation (align to your schema)
        BigDecimal totalTax = BigDecimal.ZERO;
        List<GenericValue> items = EntityQuery.use(d)
            .from("PayrollRunItem")
            .where("runYear", y, "runMonth", m, "organizationPartyId", orgId)
            .queryList();

        for (GenericValue it : items) {
            totalTax = totalTax.add(nvl(it.getBigDecimal("taxAmount")));
        }

        GenericValue line = d.makeValue("PayrollComplianceReportLine");
        line.set("payrollComplianceReportLineId", d.getNextSeqId("PayrollComplianceReportLine"));
        line.set("payrollComplianceReportId", repId);
        line.set("metricTypeId", "TAX");
        line.set("amount", totalTax);
        d.create(line);

        return UtilMisc.toMap("responseMessage","success","payrollComplianceReportId",repId);
    } catch (Exception e) {
        return ServiceUtil.returnError(e.getMessage());
    }
}
