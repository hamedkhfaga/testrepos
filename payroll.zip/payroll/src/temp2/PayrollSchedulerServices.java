package org.apache.ofbiz.payroll;

import org.apache.ofbiz.service.*;
import org.apache.ofbiz.entity.*;
import org.apache.ofbiz.entity.util.EntityQuery;
import org.apache.ofbiz.base.util.*;

import java.util.*;

public class PayrollSchedulerServices {

    public static Map<String, Object> runMonthlyPayroll(
            DispatchContext dctx, Map<String, ?> context) throws GenericEntityException {

        Delegator delegator = dctx.getDelegator();
        LocalDispatcher dispatcher = dctx.getDispatcher();

        List<GenericValue> orgs = EntityQuery.use(delegator)
                .from("PartyRole")
                .where("roleTypeId", "INTERNAL_ORGANIZATION")
                .queryList();

        Calendar cal = Calendar.getInstance();
        int month = cal.get(Calendar.MONTH) + 1;
        int year = cal.get(Calendar.YEAR);

        for (GenericValue org : orgs) {
            Map<String, Object> runCtx = UtilMisc.toMap(
                    "organizationPartyId", org.getString("partyId"),
                    "runMonth", month,
                    "runYear", year,
                    "userLogin", context.get("userLogin")
            );

            dispatcher.runSync("createPayrollRun", runCtx);
            dispatcher.runSync("processPayrollRun", runCtx);
			dispatcher.runSync("buildAttendancePeriodSummary", ctx);
            dispatcher.runSync("processPayrollRun", ctx);

        }

        return ServiceUtil.returnSuccess("Monthly payroll executed");
    }
}
