package org.apache.ofbiz.payroll.services;

import org.apache.ofbiz.base.util.*;
import org.apache.ofbiz.entity.*;
import org.apache.ofbiz.entity.util.EntityQuery;
import org.apache.ofbiz.service.*;
import org.apache.ofbiz.payroll.services.engine.PayrollProcessingEngine;

import java.sql.Timestamp;
import java.util.Map;

public class PayrollRunWorkflowServices {
    public static final String MODULE = PayrollRunWorkflowServices.class.getName();

    // Use your own StatusItem IDs (recommended to define in seed/demo):
    private static final String RUN_NEW = "PAYRUN_NEW";
    private static final String RUN_APPROVED = "PAYRUN_APPROVED";
    private static final String RUN_PROCESSED = "PAYRUN_PROCESSED";

    public static Map<String, Object> createPayrollRun(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        try {
            String orgPartyId = (String) context.get("orgPartyId");
            String payrollPeriodId = (String) context.get("payrollPeriodId");
            String currencyUomId = (String) context.get("currencyUomId");
            String createdByUserLoginId = (String) context.get("createdByUserLoginId");
            String runName = (String) context.get("runName");

            if (UtilValidate.isEmpty(orgPartyId) || UtilValidate.isEmpty(payrollPeriodId)
                    || UtilValidate.isEmpty(currencyUomId) || UtilValidate.isEmpty(createdByUserLoginId)) {
                return ServiceUtil.returnError("Missing required fields");
            }

            String payrollRunId = delegator.getNextSeqId("PayrollRun");
            Timestamp now = UtilDateTime.nowTimestamp();

            GenericValue run = delegator.makeValue("PayrollRun",
                    "payrollRunId", payrollRunId,
                    "orgPartyId", orgPartyId,
                    "payrollPeriodId", payrollPeriodId,
                    "runName", UtilValidate.isEmpty(runName) ? ("Run-" + payrollRunId) : runName,
                    "runDate", now,
                    "currencyUomId", currencyUomId,
                    "statusId", RUN_NEW,
                    "createdByUserLoginId", createdByUserLoginId,
                    "createdDate", now,
                    "isGlPosted", "N",
                    "isCompliant", "N"
            );
            delegator.create(run);

            Map<String, Object> out = ServiceUtil.returnSuccess();
            out.put("payrollRunId", payrollRunId);
            return out;

        } catch (Exception e) {
            Debug.logError(e, "createPayrollRun failed", MODULE);
            return ServiceUtil.returnError("createPayrollRun failed: " + e.getMessage());
        }
    }

    public static Map<String, Object> approvePayrollRun(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        try {
            String payrollRunId = (String) context.get("payrollRunId");
            String approvedByUserLoginId = (String) context.get("approvedByUserLoginId");
            if (UtilValidate.isEmpty(payrollRunId) || UtilValidate.isEmpty(approvedByUserLoginId)) {
                return ServiceUtil.returnError("payrollRunId and approvedByUserLoginId are required");
            }

            GenericValue run = EntityQuery.use(delegator).from("PayrollRun")
                    .where("payrollRunId", payrollRunId).queryOne();
            if (run == null) return ServiceUtil.returnError("PayrollRun not found: " + payrollRunId);

            String statusId = run.getString("statusId");
            if (!RUN_NEW.equals(statusId)) {
                return ServiceUtil.returnError("PayrollRun must be NEW to approve. Current=" + statusId);
            }

            run.set("statusId", RUN_APPROVED);
            run.set("approvedByUserLoginId", approvedByUserLoginId);
            run.set("approvedDate", UtilDateTime.nowTimestamp());
            run.store();

            return ServiceUtil.returnSuccess();

        } catch (Exception e) {
            Debug.logError(e, "approvePayrollRun failed", MODULE);
            return ServiceUtil.returnError("approvePayrollRun failed: " + e.getMessage());
        }
    }

    public static Map<String, Object> processPayrollRun(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        try {
            String payrollRunId = (String) context.get("payrollRunId");
            String processedByUserLoginId = (String) context.get("processedByUserLoginId");

            if (UtilValidate.isEmpty(payrollRunId) || UtilValidate.isEmpty(processedByUserLoginId)) {
                return ServiceUtil.returnError("payrollRunId and processedByUserLoginId are required");
            }

            GenericValue run = EntityQuery.use(delegator).from("PayrollRun")
                    .where("payrollRunId", payrollRunId).queryOne();
            if (run == null) return ServiceUtil.returnError("PayrollRun not found: " + payrollRunId);

            if (!RUN_APPROVED.equals(run.getString("statusId"))) {
                return ServiceUtil.returnError("PayrollRun must be APPROVED before processing.");
            }

            PayrollProcessingEngine.process(delegator, run, processedByUserLoginId);

            run.set("statusId", RUN_PROCESSED);
            run.store();

            return ServiceUtil.returnSuccess();

        } catch (Exception e) {
            Debug.logError(e, "processPayrollRun failed", MODULE);
            return ServiceUtil.returnError("processPayrollRun failed: " + e.getMessage());
        }
    }
}
