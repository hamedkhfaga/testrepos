package org.apache.ofbiz.payroll.export;

import org.apache.ofbiz.base.util.Debug;
import org.apache.ofbiz.base.util.UtilDateTime;
import org.apache.ofbiz.base.util.UtilValidate;
import org.apache.ofbiz.entity.Delegator;
import org.apache.ofbiz.entity.GenericEntityException;
import org.apache.ofbiz.entity.GenericValue;
import org.apache.ofbiz.entity.util.EntityQuery;
import org.apache.ofbiz.service.DispatchContext;
import org.apache.ofbiz.service.ServiceUtil;

import java.io.File;
import java.io.FileOutputStream;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.*;

public class PayrollExportServices {

    public static final String MODULE = PayrollExportServices.class.getName();

    // ----- Status IDs (use your own StatusItem values) -----
    private static final String STAT_NEW = "EXP_NEW";
    private static final String STAT_PROCESSING = "EXP_PROCESSING";
    private static final String STAT_COMPLETED = "EXP_COMPLETED";
    private static final String STAT_FAILED = "EXP_FAILED";

    // ----- Format Types -----
    private static final String FMT_PDF_OPENPDF = "PDF_OPENPDF";
    private static final String FMT_PDF_FOP = "PDF_FOP";

    /**
     * Create export request row.
     */
    public static Map<String, Object> createPayrollExportRequest(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        Map<String, Object> result = ServiceUtil.returnSuccess();

        try {
            String orgPartyId = (String) context.get("orgPartyId");
            String payrollRunId = (String) context.get("payrollRunId");
            String payrollResultId = (String) context.get("payrollResultId");
            String exportTypeId = (String) context.get("exportTypeId");
            String formatTypeId = (String) context.get("formatTypeId");
            String requestedByUserLoginId = (String) context.get("requestedByUserLoginId");

            if (UtilValidate.isEmpty(orgPartyId) || UtilValidate.isEmpty(exportTypeId)
                    || UtilValidate.isEmpty(formatTypeId) || UtilValidate.isEmpty(requestedByUserLoginId)) {
                return ServiceUtil.returnError("Missing required fields: orgPartyId/exportTypeId/formatTypeId/requestedByUserLoginId");
            }
            if (UtilValidate.isEmpty(payrollRunId) && UtilValidate.isEmpty(payrollResultId)) {
                return ServiceUtil.returnError("Either payrollRunId or payrollResultId must be provided.");
            }

            String exportRequestId = delegator.getNextSeqId("PayrollExportRequest");
            GenericValue req = delegator.makeValue("PayrollExportRequest",
                    "exportRequestId", exportRequestId,
                    "orgPartyId", orgPartyId,
                    "payrollRunId", payrollRunId,
                    "payrollResultId", payrollResultId,
                    "exportTypeId", exportTypeId,
                    "formatTypeId", formatTypeId,
                    "requestedByUserLoginId", requestedByUserLoginId,
                    "requestedDate", UtilDateTime.nowTimestamp(),
                    "statusId", STAT_NEW
            );
            delegator.create(req);

            result.put("exportRequestId", exportRequestId);
            return result;

        } catch (Exception e) {
            Debug.logError(e, "createPayrollExportRequest failed", MODULE);
            return ServiceUtil.returnError("createPayrollExportRequest failed: " + e.getMessage());
        }
    }

    /**
     * Process export request. Generates one PDF per EmployeePayrollResult.
     */
    public static Map<String, Object> processPayrollExportRequest(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        Map<String, Object> result = ServiceUtil.returnSuccess();

        String exportRequestId = (String) context.get("exportRequestId");
        if (UtilValidate.isEmpty(exportRequestId)) {
            return ServiceUtil.returnError("exportRequestId is required");
        }

        try {
            GenericValue req = EntityQuery.use(delegator).from("PayrollExportRequest")
                    .where("exportRequestId", exportRequestId)
                    .queryOne();

            if (req == null) return ServiceUtil.returnError("PayrollExportRequest not found: " + exportRequestId);

            // mark processing
            req.set("statusId", STAT_PROCESSING);
            req.store();

            String formatTypeId = req.getString("formatTypeId");
            String orgPartyId = req.getString("orgPartyId");
            String payrollRunId = req.getString("payrollRunId");
            String payrollResultId = req.getString("payrollResultId");

            List<String> payrollResultIds = new ArrayList<>();

            if (UtilValidate.isNotEmpty(payrollResultId)) {
                payrollResultIds.add(payrollResultId);
            } else {
                // per employee result in run
                List<GenericValue> results = EntityQuery.use(delegator).from("EmployeePayrollResult")
                        .where("payrollRunId", payrollRunId)
                        .queryList();
                for (GenericValue r : results) {
                    payrollResultIds.add(r.getString("payrollResultId"));
                }
            }

            if (payrollResultIds.isEmpty()) {
                req.set("statusId", STAT_FAILED);
                req.set("errorMessage", "No EmployeePayrollResult found to export.");
                req.store();
                return ServiceUtil.returnError("No EmployeePayrollResult found for export.");
            }

            // generate one file per payrollResultId
            for (String prId : payrollResultIds) {
                ExportPayload payload = buildPayslipPayload(delegator, orgPartyId, prId);

                // barcode values
                String code128Value = "PAYSLIP:" + payload.payrollResultId + ":V:" + payload.versionNumber;

                // QR value: tokenized URL (replace host)
                String token = BarcodeUtil.buildSimpleToken(payload.payrollResultId, payload.versionNumber);
                String qrText = "https://yourhost/portal/payslip?token=" + token;

                // persist barcodes (audit)
                createPayslipBarcode(delegator, payload.payrollResultId, code128Value, "PAY_CODE128");
                createPayslipBarcode(delegator, payload.payrollResultId, qrText, "PAY_QR");

                GeneratedFile gf;
                if (FMT_PDF_OPENPDF.equalsIgnoreCase(formatTypeId)) {
                    gf = PayslipPdfOpenPdf.generate(payload, code128Value, qrText);
                } else if (FMT_PDF_FOP.equalsIgnoreCase(formatTypeId)) {
                    gf = PayslipPdfFop.generate(payload, code128Value, qrText);
                } else {
                    throw new IllegalArgumentException("Unsupported formatTypeId: " + formatTypeId);
                }

                // write file + create PayrollExportFile row
                String exportFileId = saveExportFile(delegator, exportRequestId, gf);
                // optional: link employee access/audit/delivery here
                Debug.logInfo("Generated payslip exportFileId=" + exportFileId + " for payrollResultId=" + prId, MODULE);
            }

            req.set("statusId", STAT_COMPLETED);
            req.store();

            return result;

        } catch (Exception e) {
            Debug.logError(e, "processPayrollExportRequest failed", MODULE);
            try {
                GenericValue req = EntityQuery.use(delegator).from("PayrollExportRequest")
                        .where("exportRequestId", exportRequestId)
                        .queryOne();
                if (req != null) {
                    req.set("statusId", STAT_FAILED);
                    req.set("errorMessage", e.getMessage());
                    req.store();
                }
            } catch (Exception ignored) {}
            return ServiceUtil.returnError("processPayrollExportRequest failed: " + e.getMessage());
        }
    }

    // -------------------- Payload builder --------------------

    private static ExportPayload buildPayslipPayload(Delegator delegator, String orgPartyId, String payrollResultId) throws GenericEntityException {
        GenericValue r = EntityQuery.use(delegator).from("EmployeePayrollResult")
                .where("payrollResultId", payrollResultId)
                .queryOne();
        if (r == null) throw new IllegalArgumentException("EmployeePayrollResult not found: " + payrollResultId);

        List<GenericValue> lines = EntityQuery.use(delegator).from("EmployeePayrollResultLine")
                .where("payrollResultId", payrollResultId)
                .orderBy("sequenceNum")
                .queryList();

        String partyId = r.getString("partyId");

        String employeeName = partyId; // fallback
        GenericValue person = EntityQuery.use(delegator).from("Person").where("partyId", partyId).queryOne();
        if (person != null) {
            employeeName = safe(person.getString("firstName")) + " " + safe(person.getString("lastName"));
        }

        Long version = r.getLong("versionNumber");
        if (version == null) version = 1L;

        ExportPayload p = new ExportPayload();
        p.orgPartyId = orgPartyId != null ? orgPartyId : r.getString("orgPartyId");
        p.payrollRunId = r.getString("payrollRunId");
        p.payrollResultId = payrollResultId;
        p.partyId = partyId;
        p.employeeName = employeeName.trim();
        p.currencyUomId = r.getString("currencyUomId");
        p.generatedAt = UtilDateTime.nowTimestamp();
        p.versionNumber = version;

        p.grossSalary = r.getBigDecimal("grossSalary");
        p.totalDeductions = r.getBigDecimal("totalDeductions");
        p.netSalary = r.getBigDecimal("netSalary");

        p.resultLines = lines;
        return p;
    }

    // -------------------- Persistence helpers --------------------

    private static void createPayslipBarcode(Delegator delegator, String payrollResultId, String barcodeValue, String barcodeTypeId)
            throws GenericEntityException {

        String id = delegator.getNextSeqId("PayslipBarcode");
        GenericValue bc = delegator.makeValue("PayslipBarcode",
                "payslipBarcodeId", id,
                "payrollResultId", payrollResultId,
                "barcodeValue", barcodeValue,
                "barcodeTypeId", barcodeTypeId,
                "generatedDate", UtilDateTime.nowTimestamp(),
                "scanCount", Long.valueOf(0)
        );
        delegator.create(bc);
    }

    private static String saveExportFile(Delegator delegator, String exportRequestId, GeneratedFile gf) throws Exception {
        String exportFileId = delegator.getNextSeqId("PayrollExportFile");

        String ofbizHome = System.getProperty("ofbiz.home");
        File dir = new File(ofbizHome, "runtime/tmp/payroll/export");
        if (!dir.exists() && !dir.mkdirs()) {
            throw new IllegalStateException("Cannot create export dir: " + dir.getAbsolutePath());
        }

        File f = new File(dir, gf.fileName);
        try (FileOutputStream fos = new FileOutputStream(f)) {
            fos.write(gf.bytes);
        }

        GenericValue ef = delegator.makeValue("PayrollExportFile",
                "exportFileId", exportFileId,
                "exportRequestId", exportRequestId,
                "fileName", gf.fileName,
                "filePath", f.getAbsolutePath(),
                "mimeTypeId", "application/pdf", // or store real mimeTypeId mapping
                "fileSize", Long.valueOf(gf.bytes.length),
                "generatedDate", UtilDateTime.nowTimestamp(),
                "downloadCount", Long.valueOf(0)
        );
        delegator.create(ef);

        return exportFileId;
    }

    private static String safe(String s) { return s == null ? "" : s; }

    // -------------------- DTOs --------------------

    public static class ExportPayload {
        public String orgPartyId;
        public String payrollRunId;
        public String payrollResultId;
        public String partyId;
        public String employeeName;
        public String currencyUomId;
        public Timestamp generatedAt;
        public long versionNumber;

        public BigDecimal grossSalary;
        public BigDecimal totalDeductions;
        public BigDecimal netSalary;

        public List<GenericValue> resultLines = Collections.emptyList();
    }

    public static class GeneratedFile {
        public final String fileName;
        public final String mimeType;
        public final byte[] bytes;

        private GeneratedFile(String fileName, String mimeType, byte[] bytes) {
            this.fileName = fileName;
            this.mimeType = mimeType;
            this.bytes = bytes;
        }

        public static GeneratedFile of(String fileName, String mimeType, byte[] bytes) {
            return new GeneratedFile(fileName, mimeType, bytes);
        }
    }
}
