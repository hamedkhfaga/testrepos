package org.apache.ofbiz.payroll.export;

import com.lowagie.text.*;
import com.lowagie.text.pdf.*;

import org.apache.ofbiz.base.util.*;
import org.apache.ofbiz.entity.*;
import org.apache.ofbiz.entity.util.EntityQuery;
import org.apache.ofbiz.service.*;

import javax.xml.transform.*;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.fop.apps.*;

import java.io.*;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.sql.Timestamp;
import java.util.*;

/**
 * Payroll Export Services
 * - Creates PayrollExportRequest
 * - Processes request
 * - Generates one PDF per EmployeePayrollResult
 * - Supports OpenPDF and Apache FOP
 * - Generates Code128 + QR, stores PayslipBarcode rows
 */
public class PayrollExportServices {
    public static final String MODULE = PayrollExportServices.class.getName();

    // ===== Statuses (you can map to StatusItem later) =====
    private static final String STATUS_NEW = "EXP_NEW";
    private static final String STATUS_PROCESSING = "EXP_PROCESSING";
    private static final String STATUS_DONE = "EXP_DONE";
    private static final String STATUS_ERROR = "EXP_ERROR";

    // ===== Formats =====
    private static final String FORMAT_PDF_OPENPDF = "PDF_OPENPDF";
    private static final String FORMAT_PDF_FOP = "PDF_FOP";

    // ===== Export Type =====
    private static final String EXPORT_TYPE_PAYSLIP = "PAYSLIP";

    // ===== Filesystem =====
    private static final String SUBDIR_EXPORTS = "payroll/exports";
    private static final String SUBDIR_BARCODES = "payroll/barcodes";

    // ====== Public Services ======

    public static Map<String, Object> createPayrollExportRequest(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        Map<String, Object> result = ServiceUtil.returnSuccess();

        try {
            String orgPartyId = (String) context.get("orgPartyId");
            String payrollRunId = (String) context.get("payrollRunId");
            String payrollResultId = (String) context.get("payrollResultId");
            String exportTypeId = (String) context.get("exportTypeId");
            String formatTypeId = (String) context.get("formatTypeId");
            String requestedByUserLoginId = (String) context.get("requestedByUserLoginId");

            if (UtilValidate.isEmpty(orgPartyId)) return ServiceUtil.returnError("orgPartyId is required");
            if (UtilValidate.isEmpty(exportTypeId)) return ServiceUtil.returnError("exportTypeId is required");
            if (UtilValidate.isEmpty(formatTypeId)) return ServiceUtil.returnError("formatTypeId is required");
            if (UtilValidate.isEmpty(requestedByUserLoginId)) return ServiceUtil.returnError("requestedByUserLoginId is required");

            // Require at least one target
            if (UtilValidate.isEmpty(payrollRunId) && UtilValidate.isEmpty(payrollResultId)) {
                return ServiceUtil.returnError("Either payrollRunId or payrollResultId must be provided");
            }

            String exportRequestId = delegator.getNextSeqId("PayrollExportRequest");
            Timestamp now = UtilDateTime.nowTimestamp();

            GenericValue req = delegator.makeValue("PayrollExportRequest",
                    "exportRequestId", exportRequestId,
                    "orgPartyId", orgPartyId,
                    "payrollRunId", payrollRunId,
                    "payrollResultId", payrollResultId,
                    "exportTypeId", exportTypeId,
                    "formatTypeId", formatTypeId,
                    "localeString", (String) context.get("localeString"),
                    "timeZoneString", (String) context.get("timeZoneString"),
                    "requestedByUserLoginId", requestedByUserLoginId,
                    "requestedDate", now,
                    "statusId", STATUS_NEW,
                    "errorMessage", null
            );

            delegator.create(req);

            result.put("exportRequestId", exportRequestId);
            return result;

        } catch (Exception e) {
            Debug.logError(e, "createPayrollExportRequest failed", MODULE);
            return ServiceUtil.returnError("createPayrollExportRequest failed: " + e.getMessage());
        }
    }

    public static Map<String, Object> processPayrollExportRequest(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        Map<String, Object> result = ServiceUtil.returnSuccess();

        String exportRequestId = (String) context.get("exportRequestId");
        if (UtilValidate.isEmpty(exportRequestId)) return ServiceUtil.returnError("exportRequestId is required");

        List<String> generatedFileIds = new ArrayList<>();
        long generatedCount = 0;

        try {
            GenericValue req = EntityQuery.use(delegator)
                    .from("PayrollExportRequest")
                    .where("exportRequestId", exportRequestId)
                    .cache(false)
                    .queryOne();

            if (req == null) return ServiceUtil.returnError("PayrollExportRequest not found: " + exportRequestId);

            // Mark processing
            req.set("statusId", STATUS_PROCESSING);
            req.set("errorMessage", null);
            delegator.store(req);

            String exportTypeId = req.getString("exportTypeId");
            String formatTypeId = req.getString("formatTypeId");

            if (!EXPORT_TYPE_PAYSLIP.equals(exportTypeId)) {
                return failAndStore(delegator, req, "Unsupported exportTypeId: " + exportTypeId);
            }
            if (!FORMAT_PDF_OPENPDF.equals(formatTypeId) && !FORMAT_PDF_FOP.equals(formatTypeId)) {
                return failAndStore(delegator, req, "Unsupported formatTypeId: " + formatTypeId);
            }

            // Determine results to export (one PDF per EmployeePayrollResult)
            List<GenericValue> resultsToExport = resolveResultsToExport(delegator, req);

            if (resultsToExport.isEmpty()) {
                req.set("statusId", STATUS_DONE);
                req.set("errorMessage", null);
                delegator.store(req);
                result.put("generatedExportFileIds", generatedFileIds);
                result.put("generatedCount", Long.valueOf(0));
                return result;
            }

            for (GenericValue empRes : resultsToExport) {
                ExportFileOutcome out;
                if (FORMAT_PDF_OPENPDF.equals(formatTypeId)) {
                    out = generatePayslipPdfOpenPdf(delegator, req, empRes);
                } else {
                    out = generatePayslipPdfFop(delegator, req, empRes);
                }

                generatedFileIds.add(out.exportFileId);
                generatedCount++;
            }

            req.set("statusId", STATUS_DONE);
            req.set("errorMessage", null);
            delegator.store(req);

            result.put("generatedExportFileIds", generatedFileIds);
            result.put("generatedCount", Long.valueOf(generatedCount));
            return result;

        } catch (Exception e) {
            Debug.logError(e, "processPayrollExportRequest failed", MODULE);
            try {
                GenericValue req = EntityQuery.use(delegator).from("PayrollExportRequest")
                        .where("exportRequestId", exportRequestId).cache(false).queryOne();
                if (req != null) {
                    req.set("statusId", STATUS_ERROR);
                    req.set("errorMessage", shorten(e.getMessage(), 3900));
                    delegator.store(req);
                }
            } catch (Exception storeEx) {
                Debug.logError(storeEx, "Failed updating request status after error", MODULE);
            }
            return ServiceUtil.returnError("processPayrollExportRequest failed: " + e.getMessage());
        }
    }

    // ====== Core Logic ======

    private static List<GenericValue> resolveResultsToExport(Delegator delegator, GenericValue req) throws GenericEntityException {
        String payrollResultId = req.getString("payrollResultId");
        String payrollRunId = req.getString("payrollRunId");

        if (UtilValidate.isNotEmpty(payrollResultId)) {
            GenericValue one = EntityQuery.use(delegator)
                    .from("EmployeePayrollResult")
                    .where("payrollResultId", payrollResultId)
                    .cache(false)
                    .queryOne();
            return one == null ? Collections.emptyList() : Collections.singletonList(one);
        }

        // If run requested: export each employee result
        return EntityQuery.use(delegator)
                .from("EmployeePayrollResult")
                .where("payrollRunId", payrollRunId)
                .orderBy("partyId")
                .cache(false)
                .queryList();
    }

    // ===== OpenPDF payslip =====

    private static ExportFileOutcome generatePayslipPdfOpenPdf(Delegator delegator, GenericValue req, GenericValue empRes) throws Exception {
        String payrollResultId = empRes.getString("payrollResultId");
        String orgPartyId = empRes.getString("orgPartyId");
        String partyId = empRes.getString("partyId");
        Long version = safeLong(empRes.getLong("versionNumber"), 1L);

        // Lines
        List<GenericValue> lines = EntityQuery.use(delegator)
                .from("EmployeePayrollResultLine")
                .where("payrollResultId", payrollResultId)
                .orderBy("sequenceNum")
                .cache(false)
                .queryList();

        // Barcodes (store)
        BarcodeBundle barcodes = buildAndPersistBarcodes(delegator, payrollResultId, version);

        // Create PDF bytes
        ByteArrayOutputStream baos = new ByteArrayOutputStream(64 * 1024);
        Document doc = new Document(PageSize.A4, 36, 36, 36, 36);
        PdfWriter writer = PdfWriter.getInstance(doc, baos);
        doc.open();

        // Header
        Font h = new Font(Font.HELVETICA, 16, Font.BOLD);
        Font n = new Font(Font.HELVETICA, 10, Font.NORMAL);

        Paragraph title = new Paragraph("Payslip", h);
        title.setAlignment(Element.ALIGN_LEFT);
        doc.add(title);

        Paragraph meta = new Paragraph(
                "PayrollResultId: " + payrollResultId + "   PartyId: " + partyId, n);
        meta.setSpacingAfter(8);
        doc.add(meta);

        // Barcode + QR
        Image code128Img = OpenPdfBarcodeRenderer.buildCode128Image(writer, barcodes.code128Value);
        Image qrImg = OpenPdfBarcodeRenderer.buildQrImage(barcodes.qrText, 220);

        code128Img.setAlignment(Image.ALIGN_RIGHT);
        qrImg.setAlignment(Image.ALIGN_RIGHT);
        doc.add(code128Img);
        doc.add(qrImg);

        doc.add(Chunk.NEWLINE);

        // Summary table
        PdfPTable t = new PdfPTable(2);
        t.setWidthPercentage(100f);
        t.setWidths(new float[]{35f, 65f});
        addRow(t, "Basic Salary", money(empRes.getBigDecimal("basicSalary")), n);
        addRow(t, "Overtime", money(empRes.getBigDecimal("overtimeAmount")), n);
        addRow(t, "Allowances Total", money(empRes.getBigDecimal("allowancesTotal")), n);
        addRow(t, "Gross", money(empRes.getBigDecimal("grossSalary")), n);
        addRow(t, "Tax", money(empRes.getBigDecimal("incomeTax")), n);
        addRow(t, "Social Security", money(empRes.getBigDecimal("socialSecurity")), n);
        addRow(t, "Loan Deductions", money(empRes.getBigDecimal("loanDeductions")), n);
        addRow(t, "Other Deductions", money(empRes.getBigDecimal("otherDeductions")), n);
        addRow(t, "Total Deductions", money(empRes.getBigDecimal("totalDeductions")), n);
        addRow(t, "Net", money(empRes.getBigDecimal("netSalary")), new Font(Font.HELVETICA, 10, Font.BOLD));
        t.setSpacingAfter(10);
        doc.add(t);

        // Lines table
        PdfPTable lt = new PdfPTable(3);
        lt.setWidthPercentage(100f);
        lt.setWidths(new float[]{20f, 60f, 20f});

        addHeader(lt, "Type", n);
        addHeader(lt, "Description", n);
        addHeader(lt, "Amount", n);

        for (GenericValue line : lines) {
            lt.addCell(new Phrase(nvl(line.getString("lineTypeId")), n));
            lt.addCell(new Phrase(nvl(line.getString("description")), n));
            lt.addCell(new Phrase(money(line.getBigDecimal("amount")), n));
        }
        doc.add(lt);

        doc.close();
        writer.close();

        // Write file to disk
        String fileName = "PAYSLIP_" + payrollResultId + ".pdf";
        String absPath = writeExportFile(baos.toByteArray(), fileName);

        // Persist PayrollExportFile
        String exportFileId = createPayrollExportFile(delegator, req, fileName, absPath, "application/pdf");

        // Mark result as generated
        markPayslipGenerated(delegator, payrollResultId);

        return new ExportFileOutcome(exportFileId, absPath);
    }

    // ===== FOP payslip =====

    private static ExportFileOutcome generatePayslipPdfFop(Delegator delegator, GenericValue req, GenericValue empRes) throws Exception {
        String payrollResultId = empRes.getString("payrollResultId");
        String partyId = empRes.getString("partyId");
        Long version = safeLong(empRes.getLong("versionNumber"), 1L);

        List<GenericValue> lines = EntityQuery.use(delegator)
                .from("EmployeePayrollResultLine")
                .where("payrollResultId", payrollResultId)
                .orderBy("sequenceNum")
                .cache(false)
                .queryList();

        // Barcodes (create PNGs for FOP) + store rows
        BarcodeBundle barcodes = buildAndPersistBarcodes(delegator, payrollResultId, version);

        // Create barcode images for FO
        String code128Url = writeBarcodePngAsFileUrl(
                BarcodeUtil.buildCode128Png(barcodes.code128Value, 520, 140),
                "code128_" + payrollResultId + ".png");

        String qrUrl = writeBarcodePngAsFileUrl(
                BarcodeUtil.buildQrPng(barcodes.qrText, 240),
                "qr_" + payrollResultId + ".png");

        // Build XML payload
        String xml = buildPayslipXml(empRes, lines, barcodes.code128Value, code128Url, qrUrl);

        // Transform XML -> FO using embedded XSL
        String xsl = FopTemplates.PAYSLIP_XSL;

        ByteArrayOutputStream foOut = new ByteArrayOutputStream(64 * 1024);
        transformXmlToFo(xml, xsl, foOut);

        // Render FO -> PDF using FOP
        byte[] pdfBytes = renderFoToPdf(foOut.toByteArray());

        // Write file
        String fileName = "PAYSLIP_" + payrollResultId + ".pdf";
        String absPath = writeExportFile(pdfBytes, fileName);

        String exportFileId = createPayrollExportFile(delegator, req, fileName, absPath, "application/pdf");

        markPayslipGenerated(delegator, payrollResultId);

        return new ExportFileOutcome(exportFileId, absPath);
    }

    // ===== Helpers: barcodes, persistence =====

    private static BarcodeBundle buildAndPersistBarcodes(Delegator delegator, String payrollResultId, Long version) throws Exception {
        // Code128 value (stable)
        String code128 = "PAYSLIP:" + payrollResultId + ":V:" + version;

        // QR text (tokenized link example)
        String token = BarcodeUtil.buildSimpleToken(payrollResultId, version);
        String qrText = "https://yourhost/portal/payslip?token=" + token;

        // Store rows in PayslipBarcode (audit-friendly: create new rows)
        insertPayslipBarcode(delegator, payrollResultId, code128, "PAY_CODE128");
        insertPayslipBarcode(delegator, payrollResultId, qrText, "PAY_QR");

        return new BarcodeBundle(code128, qrText);
    }

    private static void insertPayslipBarcode(Delegator delegator, String payrollResultId, String value, String typeId)
            throws GenericEntityException {
        String id = delegator.getNextSeqId("PayslipBarcode");
        GenericValue bc = delegator.makeValue("PayslipBarcode",
                "payslipBarcodeId", id,
                "payrollResultId", payrollResultId,
                "barcodeValue", value,
                "barcodeTypeId", typeId,
                "generatedDate", UtilDateTime.nowTimestamp(),
                "scanCount", Long.valueOf(0)
        );
        delegator.create(bc);
    }

    private static void markPayslipGenerated(Delegator delegator, String payrollResultId) throws GenericEntityException {
        GenericValue r = EntityQuery.use(delegator).from("EmployeePayrollResult")
                .where("payrollResultId", payrollResultId).cache(false).queryOne();
        if (r != null) {
            r.set("isPayslipGenerated", "Y");
            delegator.store(r);
        }
    }

    private static String createPayrollExportFile(Delegator delegator, GenericValue req,
                                                  String fileName, String absPath, String mime)
            throws GenericEntityException {
        String exportFileId = delegator.getNextSeqId("PayrollExportFile");
        GenericValue f = delegator.makeValue("PayrollExportFile",
                "exportFileId", exportFileId,
                "exportRequestId", req.getString("exportRequestId"),
                "fileName", fileName,
                "filePath", absPath,
                "mimeTypeId", mimeTypeToMimeTypeId(mime), // optional mapping
                "fileSize", Long.valueOf(new File(absPath).length()),
                "generatedDate", UtilDateTime.nowTimestamp(),
                "downloadCount", Long.valueOf(0),
                "checksum", null
        );
        delegator.create(f);
        return exportFileId;
    }

    private static String mimeTypeToMimeTypeId(String mime) {
        // If your MimeType table uses mimeTypeId like "application/pdf", keep it.
        // Otherwise, map to your IDs.
        return mime;
    }

    // ===== Filesystem =====

    private static String writeExportFile(byte[] bytes, String fileName) throws Exception {
        String ofbizHome = System.getProperty("ofbiz.home");
        File dir = new File(ofbizHome, "runtime/tmp/" + SUBDIR_EXPORTS);
        if (!dir.exists() && !dir.mkdirs()) {
            throw new IllegalStateException("Cannot create export dir: " + dir.getAbsolutePath());
        }
        File f = new File(dir, fileName);
        try (FileOutputStream fos = new FileOutputStream(f)) {
            fos.write(bytes);
        }
        return f.getAbsolutePath();
    }

    private static String writeBarcodePngAsFileUrl(byte[] pngBytes, String fileName) throws Exception {
        String abs = BarcodeUtil.writeTempFile(pngBytes, fileName, SUBDIR_BARCODES);
        return FopBarcodeAssets.toFileUrl(abs);
    }

    // ===== FOP pipeline =====

    private static void transformXmlToFo(String xml, String xsl, OutputStream foOut) throws Exception {
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer t = tf.newTransformer(new StreamSource(new StringReader(xsl)));
        t.transform(new StreamSource(new StringReader(xml)), new StreamResult(foOut));
    }

    private static byte[] renderFoToPdf(byte[] foBytes) throws Exception {
        FopFactory fopFactory = FopFactory.newInstance(new File(".").toURI());
        FOUserAgent foUserAgent = fopFactory.newFOUserAgent();

        try (ByteArrayOutputStream pdfOut = new ByteArrayOutputStream(128 * 1024)) {
            Fop fop = fopFactory.newFop(MimeConstants.MIME_PDF, foUserAgent, pdfOut);

            TransformerFactory factory = TransformerFactory.newInstance();
            Transformer transformer = factory.newTransformer(); // identity transformer
            Source src = new StreamSource(new ByteArrayInputStream(foBytes));
            Result res = new SAXResult(fop.getDefaultHandler());
            transformer.transform(src, res);

            return pdfOut.toByteArray();
        }
    }

    // ===== OpenPDF helpers =====

    private static void addRow(PdfPTable t, String k, String v, Font f) {
        PdfPCell c1 = new PdfPCell(new Phrase(k, f));
        PdfPCell c2 = new PdfPCell(new Phrase(v, f));
        c1.setBorder(Rectangle.BOX);
        c2.setBorder(Rectangle.BOX);
        t.addCell(c1);
        t.addCell(c2);
    }

    private static void addHeader(PdfPTable t, String text, Font f) {
        PdfPCell c = new PdfPCell(new Phrase(text, new Font(Font.HELVETICA, 10, Font.BOLD)));
        c.setBackgroundColor(new java.awt.Color(240, 240, 240));
        t.addCell(c);
    }

    // ===== XML building for FOP =====

    private static String buildPayslipXml(GenericValue empRes,
                                         List<GenericValue> lines,
                                         String code128Value,
                                         String code128Url,
                                         String qrUrl) {

        StringBuilder sb = new StringBuilder(16 * 1024);
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
        sb.append("<payslip>");

        sb.append(tag("payrollResultId", empRes.getString("payrollResultId")));
        sb.append(tag("payrollRunId", empRes.getString("payrollRunId")));
        sb.append(tag("partyId", empRes.getString("partyId")));

        sb.append(tag("basicSalary", money(empRes.getBigDecimal("basicSalary"))));
        sb.append(tag("overtimeAmount", money(empRes.getBigDecimal("overtimeAmount"))));
        sb.append(tag("allowancesTotal", money(empRes.getBigDecimal("allowancesTotal"))));
        sb.append(tag("grossSalary", money(empRes.getBigDecimal("grossSalary"))));
        sb.append(tag("incomeTax", money(empRes.getBigDecimal("incomeTax"))));
        sb.append(tag("socialSecurity", money(empRes.getBigDecimal("socialSecurity"))));
        sb.append(tag("loanDeductions", money(empRes.getBigDecimal("loanDeductions"))));
        sb.append(tag("otherDeductions", money(empRes.getBigDecimal("otherDeductions"))));
        sb.append(tag("totalDeductions", money(empRes.getBigDecimal("totalDeductions"))));
        sb.append(tag("netSalary", money(empRes.getBigDecimal("netSalary"))));

        sb.append("<barcode>");
        sb.append(tag("code128Value", code128Value));
        sb.append(tag("code128Url", code128Url));
        sb.append(tag("qrUrl", qrUrl));
        sb.append("</barcode>");

        sb.append("<lines>");
        for (GenericValue l : lines) {
            sb.append("<line>");
            sb.append(tag("lineTypeId", l.getString("lineTypeId")));
            sb.append(tag("description", l.getString("description")));
            sb.append(tag("amount", money(l.getBigDecimal("amount"))));
            sb.append("</line>");
        }
        sb.append("</lines>");

        sb.append("</payslip>");
        return sb.toString();
    }

    private static String tag(String name, String value) {
        return "<" + name + ">" + xmlEsc(value) + "</" + name + ">";
    }

    private static String xmlEsc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&apos;");
    }

    private static String money(BigDecimal bd) {
        if (bd == null) return "0.00";
        return bd.toPlainString();
    }

    private static String nvl(String s) { return s == null ? "" : s; }

    private static Long safeLong(Long v, Long d) { return v == null ? d : v; }

    private static Map<String, Object> failAndStore(Delegator delegator, GenericValue req, String msg) throws GenericEntityException {
        req.set("statusId", STATUS_ERROR);
        req.set("errorMessage", shorten(msg, 3900));
        delegator.store(req);
        return ServiceUtil.returnError(msg);
    }

    private static String shorten(String s, int max) {
        if (s == null) return null;
        return s.length() <= max ? s : s.substring(0, max);
    }

    // ===== Value objects =====

    private static class ExportFileOutcome {
        final String exportFileId;
        final String absPath;
        ExportFileOutcome(String exportFileId, String absPath) {
            this.exportFileId = exportFileId;
            this.absPath = absPath;
        }
    }

    private static class BarcodeBundle {
        final String code128Value;
        final String qrText;
        BarcodeBundle(String code128Value, String qrText) {
            this.code128Value = code128Value;
            this.qrText = qrText;
        }
    }

    // ===== Embedded FOP XSL Template =====
    private static class FopTemplates {
        // Minimal payslip XSL -> FO. Adjust layout as needed.
        static final String PAYSLIP_XSL =
                "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
              + "<xsl:stylesheet version=\"1.0\" xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\""
              + " xmlns:fo=\"http://www.w3.org/1999/XSL/Format\">"

              + "<xsl:template match=\"/payslip\">"
              + "<fo:root>"
              + " <fo:layout-master-set>"
              + "  <fo:simple-page-master master-name=\"A4\" page-height=\"29.7cm\" page-width=\"21cm\""
              + "   margin-top=\"1.2cm\" margin-bottom=\"1.2cm\" margin-left=\"1.2cm\" margin-right=\"1.2cm\">"
              + "   <fo:region-body/>"
              + "  </fo:simple-page-master>"
              + " </fo:layout-master-set>"

              + " <fo:page-sequence master-reference=\"A4\">"
              + "  <fo:flow flow-name=\"xsl-region-body\">"

              + "   <fo:block font-size=\"16pt\" font-weight=\"bold\">Payslip</fo:block>"
              + "   <fo:block font-size=\"10pt\" space-after=\"6pt\">"
              + "    PayrollResultId: <xsl:value-of select=\"payrollResultId\"/>"
              + "    &#160;&#160;PartyId: <xsl:value-of select=\"partyId\"/>"
              + "   </fo:block>"

              + "   <fo:block text-align=\"right\" space-after=\"4pt\">"
              + "     <fo:external-graphic content-width=\"6cm\" content-height=\"1.6cm\">"
              + "       <xsl:attribute name=\"src\">"
              + "         <xsl:text>url('</xsl:text><xsl:value-of select=\"barcode/code128Url\"/><xsl:text>')</xsl:text>"
              + "       </xsl:attribute>"
              + "     </fo:external-graphic>"
              + "   </fo:block>"

              + "   <fo:block text-align=\"right\" space-after=\"8pt\">"
              + "     <fo:external-graphic content-width=\"2.8cm\" content-height=\"2.8cm\">"
              + "       <xsl:attribute name=\"src\">"
              + "         <xsl:text>url('</xsl:text><xsl:value-of select=\"barcode/qrUrl\"/><xsl:text>')</xsl:text>"
              + "       </xsl:attribute>"
              + "     </fo:external-graphic>"
              + "   </fo:block>"

              + "   <fo:table table-layout=\"fixed\" width=\"100%\" font-size=\"10pt\" space-after=\"8pt\">"
              + "    <fo:table-column column-width=\"35%\"/>"
              + "    <fo:table-column column-width=\"65%\"/>"
              + "    <fo:table-body>"
              + row("Basic Salary", "basicSalary")
              + row("Overtime", "overtimeAmount")
              + row("Allowances Total", "allowancesTotal")
              + row("Gross", "grossSalary")
              + row("Tax", "incomeTax")
              + row("Social Security", "socialSecurity")
              + row("Loan Deductions", "loanDeductions")
              + row("Other Deductions", "otherDeductions")
              + row("Total Deductions", "totalDeductions")
              + rowBold("Net", "netSalary")
              + "    </fo:table-body>"
              + "   </fo:table>"

              + "   <fo:block font-size=\"12pt\" font-weight=\"bold\" space-before=\"6pt\" space-after=\"4pt\">Result Lines</fo:block>"
              + "   <fo:table table-layout=\"fixed\" width=\"100%\" font-size=\"10pt\">"
              + "    <fo:table-column column-width=\"20%\"/>"
              + "    <fo:table-column column-width=\"60%\"/>"
              + "    <fo:table-column column-width=\"20%\"/>"
              + "    <fo:table-header>"
              + "      <fo:table-row background-color=\"#F0F0F0\">"
              + "        <fo:table-cell border=\"1pt solid #CCCCCC\"><fo:block font-weight=\"bold\">Type</fo:block></fo:table-cell>"
              + "        <fo:table-cell border=\"1pt solid #CCCCCC\"><fo:block font-weight=\"bold\">Description</fo:block></fo:table-cell>"
              + "        <fo:table-cell border=\"1pt solid #CCCCCC\"><fo:block font-weight=\"bold\">Amount</fo:block></fo:table-cell>"
              + "      </fo:table-row>"
              + "    </fo:table-header>"
              + "    <fo:table-body>"
              + "      <xsl:for-each select=\"lines/line\">"
              + "       <fo:table-row>"
              + "        <fo:table-cell border=\"1pt solid #CCCCCC\"><fo:block><xsl:value-of select=\"lineTypeId\"/></fo:block></fo:table-cell>"
              + "        <fo:table-cell border=\"1pt solid #CCCCCC\"><fo:block><xsl:value-of select=\"description\"/></fo:block></fo:table-cell>"
              + "        <fo:table-cell border=\"1pt solid #CCCCCC\"><fo:block><xsl:value-of select=\"amount\"/></fo:block></fo:table-cell>"
              + "       </fo:table-row>"
              + "      </xsl:for-each>"
              + "    </fo:table-body>"
              + "   </fo:table>"

              + "  </fo:flow>"
              + " </fo:page-sequence>"
              + "</fo:root>"
              + "</xsl:template>"
              + "</xsl:stylesheet>";

        private static String row(String label, String field) {
            return " <fo:table-row>"
                 + "  <fo:table-cell border=\"1pt solid #CCCCCC\"><fo:block>" + label + "</fo:block></fo:table-cell>"
                 + "  <fo:table-cell border=\"1pt solid #CCCCCC\"><fo:block><xsl:value-of select=\"" + field + "\"/></fo:block></fo:table-cell>"
                 + " </fo:table-row>";
        }

        private static String rowBold(String label, String field) {
            return " <fo:table-row>"
                 + "  <fo:table-cell border=\"1pt solid #CCCCCC\"><fo:block font-weight=\"bold\">" + label + "</fo:block></fo:table-cell>"
                 + "  <fo:table-cell border=\"1pt solid #CCCCCC\"><fo:block font-weight=\"bold\"><xsl:value-of select=\"" + field + "\"/></fo:block></fo:table-cell>"
                 + " </fo:table-row>";
        }
    }
}
