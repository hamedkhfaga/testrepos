/* =========================================================
 * PayrollValidationQueries.java
 * Purpose:
 *   - Centralize ALL DB checks/queries for payroll run V2
 *   - Keep service logic clean (service calls these methods)
 *
 * Works with your entities:
 *   PayrollPeriod (DATE)
 *   PayrollRun
 *   EmployeePayrollAssignment (TIMESTAMP)
 *   EmployeePayrollResult
 *   PayrollPosting
 *   PayrollOrganization
 *
 * OFBiz 24 compatible (EntityQuery)
 * ========================================================= */
package org.apache.ofbiz.payroll.services;

import org.apache.ofbiz.base.util.Debug;
import org.apache.ofbiz.base.util.UtilValidate;
import org.apache.ofbiz.entity.Delegator;
import org.apache.ofbiz.entity.GenericEntityException;
import org.apache.ofbiz.entity.GenericValue;
import org.apache.ofbiz.entity.condition.EntityCondition;
import org.apache.ofbiz.entity.condition.EntityOperator;
import org.apache.ofbiz.entity.util.EntityQuery;
import org.apache.ofbiz.service.DispatchContext;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.*;
import org.apache.ofbiz.base.util.UtilMisc;

public final class PayrollValidationQueries {
    private static final String MODULE = PayrollValidationQueries.class.getName();

    private PayrollValidationQueries() {}

    /* =========================================================
     * CONTRACT DTO (required by PayrollSchedulerServicesV2 notes)
     * ========================================================= */
    public static final class ValidationResult {
        private final boolean ok;
        private final boolean hardFail;
        private final long eligibleCount;
        private final long okCount;
        private final long errorCount;
        private final String summaryText;
        private final List<String> messages;

        public ValidationResult(boolean ok,
                                boolean hardFail,
                                long eligibleCount,
                                long okCount,
                                long errorCount,
                                String summaryText,
                                List<String> messages) {
            this.ok = ok;
            this.hardFail = hardFail;
            this.eligibleCount = eligibleCount;
            this.okCount = okCount;
            this.errorCount = errorCount;
            this.summaryText = summaryText == null ? "" : summaryText;
            this.messages = messages == null
                    ? Collections.emptyList()
                    : Collections.unmodifiableList(new ArrayList<>(messages));
        }

        public boolean isOk() { return ok; }
        public boolean isHardFail() { return hardFail; }
        public long getEligibleCount() { return eligibleCount; }
        public long getOkCount() { return okCount; }
        public long getErrorCount() { return errorCount; }
        public String getSummaryText() { return summaryText; }
        public List<String> getMessages() { return messages; }
    }

  
// Scheduler-required overload
public static ValidationResult validateForMonthlyRun(Delegator delegator,
                                                    String organizationPartyId,
                                                    String payrollRunId,
                                                    String payrollPeriodId) {
    return validateForMonthlyRun(delegator, organizationPartyId, payrollRunId, payrollPeriodId,
            null, null, null);
}



  /* =========================================================
     * CONTRACT METHOD (required): validateForMonthlyRun(...)
     * Add overloads to match common OFBiz service calls.
     * ========================================================= */

    /** OFBiz-service friendly overload. */
  public static ValidationResult validateForMonthlyRun(DispatchContext dctx, Map<String, Object> context) {
    Delegator delegator = dctx != null ? dctx.getDelegator() : null;

    String orgId = asString(context, "organizationPartyId");
    String runId = asString(context, "payrollRunId");
    String periodId = asString(context, "payrollPeriodId");
    String currencyUomId = asString(context, "currencyUomId");
    String accountingPostOptionId = asString(context, "accountingPostOptionId");
    String partyId = asString(context, "partyId"); // optional filter (employee)

    return validateForMonthlyRun(delegator, orgId, runId, periodId, currencyUomId, accountingPostOptionId, partyId);
}

/**
 * Primary validation API for Monthly Payroll Run.
 *
 * Validation policy:
 * - HARD FAIL: missing delegator/org/period, invalid period, period not OPEN, org not configured,
 *              payroll structure missing (optional but recommended), and NO ELIGIBLE ASSIGNMENTS.
 * - SOFT WARN: missing/unknown currency or posting option (does not block calculation).
 */
public static ValidationResult validateForMonthlyRun(Delegator delegator,
                                                    String organizationPartyId,
                                                    String payrollRunId,
                                                    String payrollPeriodId,
                                                    String currencyUomId,
                                                    String accountingPostOptionId,
                                                    String partyIdOrNull) {

    final List<String> msgs = new ArrayList<>();
    boolean hardFail = false;

    // -------------------------
    // 0) Required inputs
    // -------------------------
    if (delegator == null) {
        hardFail = true;
        msgs.add("Delegator is null (service context not initialized).");
    }
    if (UtilValidate.isEmpty(organizationPartyId)) {
        hardFail = true;
        msgs.add("Missing organizationPartyId.");
    }
    if (UtilValidate.isEmpty(payrollPeriodId)) {
        hardFail = true;
        msgs.add("Missing payrollPeriodId (monthly validation requires an explicit period).");
    }

    // Friendly identifiers
    if (UtilValidate.isNotEmpty(payrollRunId)) msgs.add("payrollRunId=" + payrollRunId);
    if (UtilValidate.isNotEmpty(payrollPeriodId)) msgs.add("payrollPeriodId=" + payrollPeriodId);

    // If already hard-failed on basics, return early (keeps logs clean)
    if (hardFail) {
        return new ValidationResult(false, true, 0L, 0L, 1L, "Validation HARD FAIL", msgs);
    }

    // -------------------------
    // 1) Org exists + active (hard requirement)
    // -------------------------
    try {
        if (!existsPayrollOrganization(delegator, organizationPartyId)) {
            hardFail = true;
            msgs.add("PayrollOrganization not found or not active for organizationPartyId=" + organizationPartyId);
        }
    } catch (Exception e) {
        hardFail = true;
        msgs.add("DB error checking PayrollOrganization: " + safeMsg(e));
    }

    // -------------------------
    // 2) PayrollStructure exists (recommended hard requirement in your model)
    // -------------------------
    if (!hardFail) {
        try {
            if (!existsActivePayrollStructure(delegator, organizationPartyId)) {
                hardFail = true;
                msgs.add("PayrollStructure is missing or not active for org=" + organizationPartyId
                        + " (expected at least one PayrollStructure with statusId=P_ACT).");
            }
        } catch (Exception e) {
            hardFail = true;
            msgs.add("DB error checking PayrollStructure: " + safeMsg(e));
        }
    }

    // -------------------------
    // 3) Period exists + belongs to org + status OPEN (hard requirement)
    // -------------------------
    GenericValue period = null;
    Timestamp periodStartTs = null;
    Timestamp periodEndTs = null;

    if (!hardFail) {
        try {
            period = findPayrollPeriodById(delegator, payrollPeriodId);
            if (period == null) {
                hardFail = true;
                msgs.add("PayrollPeriod not found: payrollPeriodId=" + payrollPeriodId);
            } else {
                // Ensure period belongs to the org (prevents accidental cross-org processing)
                String periodOrg = period.getString("organizationPartyId");
                if (UtilValidate.isNotEmpty(periodOrg) && !organizationPartyId.equals(periodOrg)) {
                    hardFail = true;
                    msgs.add("PayrollPeriod org mismatch: period.organizationPartyId=" + periodOrg
                            + " but requested organizationPartyId=" + organizationPartyId);
                }

                // Validate status is OPEN (your sample uses WT_PER_OPEN)
                String statusId = period.getString("statusId");
                if (UtilValidate.isEmpty(statusId)) {
                    hardFail = true;
                    msgs.add("PayrollPeriod has empty statusId: " + payrollPeriodId);
                } else if (!isOpenPeriodStatus(statusId)) {
                    hardFail = true;
                    msgs.add("PayrollPeriod is not OPEN: statusId=" + statusId + " (periodId=" + payrollPeriodId + ")");
                }

                Date sd = period.getDate("startDate");
                Date ed = period.getDate("endDate");
                periodStartTs = startOfDay(sd);
                periodEndTs = endOfDay(ed);

                if (periodStartTs == null || periodEndTs == null) {
                    hardFail = true;
                    msgs.add("PayrollPeriod has invalid startDate/endDate: periodId=" + payrollPeriodId);
                }
            }
        } catch (Exception e) {
            hardFail = true;
            msgs.add("DB error resolving PayrollPeriod: " + safeMsg(e));
        }
    }

    // -------------------------
    // 4) Currency (soft warn)
    // -------------------------
    if (!hardFail && UtilValidate.isNotEmpty(currencyUomId)) {
        try {
            if (!hasCurrency(delegator, currencyUomId)) {
                msgs.add("WARN: Currency not found in Uom: currencyUomId=" + currencyUomId);
            }
        } catch (Exception e) {
            msgs.add("WARN: DB error checking currency: " + safeMsg(e));
        }
    }

    // -------------------------
    // 5) Posting option (soft info)
    // -------------------------
    if (!hardFail && UtilValidate.isNotEmpty(accountingPostOptionId)) {
        msgs.add("PostingMode=" + resolvePostingMode(accountingPostOptionId) + " (accountingPostOptionId=" + accountingPostOptionId + ")");
    }

    // -------------------------
    // 6) Eligible assignments (HARD FAIL if 0)
    // -------------------------
    long eligibleCount = 0L;
    long okCount = 0L;
    long errorCount = 0L;

    if (!hardFail) {
        try {
            eligibleCount = countEligibleAssignments(delegator, organizationPartyId, periodStartTs, periodEndTs, partyIdOrNull);

            if (eligibleCount <= 0) {
                hardFail = true;
                errorCount = 1L;

                msgs.add("No eligible employees found: eligibleCount=0.");
                msgs.add("Cause: no ACTIVE EmployeePayrollAssignment overlapping the payroll period "
                        + "[" + periodStartTs + " .. " + periodEndTs + "] for org=" + organizationPartyId
                        + (UtilValidate.isNotEmpty(partyIdOrNull) ? (" partyId=" + partyIdOrNull) : "") + ".");

                // Optional diagnostics (never crash validation)
                try {
                    Map<String, Object> diag = eligibilityDiagnostics(delegator, organizationPartyId);
                    msgs.add("Diagnostics=" + diag);
                } catch (Exception ignore) {
                    // keep stable
                }
            } else {
                okCount = eligibleCount;
                errorCount = 0L;
                msgs.add("eligibleCount=" + eligibleCount);
            }
        } catch (Exception e) {
            hardFail = true;
            msgs.add("DB error counting eligible assignments: " + safeMsg(e));
            errorCount = 1L;
        }
    }

    boolean ok = !hardFail;

    String summary = ok
            ? "Validation OK"
            : "Validation HARD FAIL";

    return new ValidationResult(ok, hardFail, eligibleCount, okCount, errorCount, summary, msgs);
}

/** Treat your OPEN statuses here (adjust as needed). */
private static boolean isOpenPeriodStatus(String statusId) {
    // Your sample: WT_PER_OPEN
    return "WT_PER_OPEN".equals(statusId) || "P_ACT".equals(statusId) || "PER_OPEN".equals(statusId);
}

/** Optional helper if you want payroll structure to be a hard prerequisite. */
private static boolean existsActivePayrollStructure(Delegator delegator, String organizationPartyId) throws GenericEntityException {
    long cnt = EntityQuery.use(delegator)
            .from("PayrollStructure")
            .where("organizationPartyId", organizationPartyId,
                   "statusId", "P_ACT")
            .queryCount();
    return cnt > 0;
}

private static String safeMsg(Throwable t) {
    if (t == null) return "null";
    return UtilValidate.isNotEmpty(t.getMessage()) ? t.getMessage() : t.toString();
}

    /* ----------------------------
     * Time helpers (PayrollPeriod = DATE)
     * ---------------------------- */

    /** Start of day 00:00:00.000 */
    public static Timestamp startOfDay(Date d) {
        if (d == null) return null;
        return new Timestamp(d.getTime());
    }

    /** End of day 23:59:59.999 */
    public static Timestamp endOfDay(Date d) {
        if (d == null) return null;
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(d.getTime());
        cal.set(Calendar.HOUR_OF_DAY, 23);
        cal.set(Calendar.MINUTE, 59);
        cal.set(Calendar.SECOND, 59);
        cal.set(Calendar.MILLISECOND, 999);
        return new Timestamp(cal.getTimeInMillis());
    }

    /* ----------------------------
     * Basic existence checks
     * ---------------------------- */

    public static boolean existsPayrollOrganization(Delegator delegator, String organizationPartyId) throws GenericEntityException {
        if (UtilValidate.isEmpty(organizationPartyId)) return false;
        GenericValue gv = EntityQuery.use(delegator)
                .from("PayrollOrganization")
                .where("organizationPartyId", organizationPartyId)
                .queryOne();
        return gv != null;
    }

    public static boolean existsStatusItem(Delegator delegator, String statusId) throws GenericEntityException {
        if (UtilValidate.isEmpty(statusId)) return false;
        GenericValue gv = EntityQuery.use(delegator)
                .from("StatusItem")
                .where("statusId", statusId)
                .queryOne();
        return gv != null;
    }

    /* ----------------------------
     * PayrollPeriod resolution + diagnostics
     * ---------------------------- */

    public static GenericValue findPayrollPeriodById(Delegator delegator, String payrollPeriodId) throws GenericEntityException {
        if (UtilValidate.isEmpty(payrollPeriodId)) return null;
        return EntityQuery.use(delegator)
                .from("PayrollPeriod")
                .where("payrollPeriodId", payrollPeriodId)
                .queryOne();
    }

    /** Find latest open period for org. Default open status is WT_PER_OPEN (your POC). */
    public static GenericValue findLatestOpenPeriod(Delegator delegator,
                                                    String organizationPartyId,
                                                    String openStatusId) throws GenericEntityException {
        if (UtilValidate.isEmpty(openStatusId)) openStatusId = "WT_PER_OPEN";

        return EntityQuery.use(delegator)
                .from("PayrollPeriod")
                .where("organizationPartyId", organizationPartyId,
                       "statusId", openStatusId)
                .orderBy("-startDate")
                .queryFirst();
    }

    public static Map<String, List<String>> findDuplicatePeriodNames(Delegator delegator, String organizationPartyId)
            throws GenericEntityException {
        Map<String, List<String>> dupMap = new LinkedHashMap<>();

        List<GenericValue> periods = EntityQuery.use(delegator)
                .from("PayrollPeriod")
                .where("organizationPartyId", organizationPartyId)
                .orderBy("periodName", "payrollPeriodId")
                .queryList();

        Map<String, List<String>> byName = new LinkedHashMap<>();
        for (GenericValue p : periods) {
            String periodName = p.getString("periodName");
            String periodId = p.getString("payrollPeriodId");
            if (UtilValidate.isEmpty(periodName)) continue;
            byName.computeIfAbsent(periodName, k -> new ArrayList<>()).add(periodId);
        }

        for (Map.Entry<String, List<String>> e : byName.entrySet()) {
            if (e.getValue().size() > 1) dupMap.put(e.getKey(), e.getValue());
        }
        return dupMap;
    }

    /* ----------------------------
     * PayrollRun resolution
     * ---------------------------- */

    public static GenericValue findPayrollRunByOrgPeriod(Delegator delegator, String organizationPartyId, String payrollPeriodId)
            throws GenericEntityException {
        if (UtilValidate.isEmpty(organizationPartyId) || UtilValidate.isEmpty(payrollPeriodId)) return null;

        return EntityQuery.use(delegator)
                .from("PayrollRun")
                .where("organizationPartyId", organizationPartyId,
                       "payrollPeriodId", payrollPeriodId)
                .orderBy("-runDate")
                .queryFirst();
    }

    public static GenericValue findPayrollRunById(Delegator delegator, String payrollRunId) throws GenericEntityException {
        if (UtilValidate.isEmpty(payrollRunId)) return null;
        return EntityQuery.use(delegator)
                .from("PayrollRun")
                .where("payrollRunId", payrollRunId)
                .queryOne();
    }

    /* ----------------------------
     * Eligibility (EmployeePayrollAssignment overlap)
     * ---------------------------- */

public static int countEligibleAssignments(Delegator delegator,
                                           String organizationPartyId,
                                           Timestamp periodStart,
                                           Timestamp periodEnd,
                                           String partyIdOrNull) throws GenericEntityException {

    // Active statuses in YOUR DB (confirmed):
    // PAY_ASG_ACT (60 rows), P_ACT (3 rows)
    EntityCondition statusCond = EntityCondition.makeCondition(
            "statusId", EntityOperator.IN, UtilMisc.toList("PAY_ASG_ACT", "P_ACT")
    );

    EntityCondition overlapCond = EntityCondition.makeCondition(
            Arrays.asList(
                    EntityCondition.makeCondition("organizationPartyId", EntityOperator.EQUALS, organizationPartyId),
                    statusCond,
                    EntityCondition.makeCondition("effectiveDate", EntityOperator.LESS_THAN_EQUAL_TO, periodEnd),
                    EntityCondition.makeCondition(
                            EntityCondition.makeCondition("thruDate", EntityOperator.EQUALS, null),
                            EntityOperator.OR,
                            EntityCondition.makeCondition("thruDate", EntityOperator.GREATER_THAN_EQUAL_TO, periodStart)
                    )
            ),
            EntityOperator.AND
    );

    if (UtilValidate.isNotEmpty(partyIdOrNull)) {
        overlapCond = EntityCondition.makeCondition(
                overlapCond,
                EntityOperator.AND,
                EntityCondition.makeCondition("partyId", EntityOperator.EQUALS, partyIdOrNull)
        );
    }

    long cnt = EntityQuery.use(delegator)
            .from("EmployeePayrollAssignment")
            .where(overlapCond)
            .queryCount();

    return (int) Math.min(Integer.MAX_VALUE, cnt);
}

	public static Map<String, Object> eligibilityDiagnostics(Delegator delegator, String organizationPartyId)
            throws GenericEntityException {
        Map<String, Object> out = new LinkedHashMap<>();

     long total = EntityQuery.use(delegator)
        .from("EmployeePayrollAssignment")
        .where("organizationPartyId", organizationPartyId)
        .queryCount();
out.put("assignmentTotalCount", (int) Math.min(Integer.MAX_VALUE, total));

        GenericValue minEff = EntityQuery.use(delegator)
                .from("EmployeePayrollAssignment")
                .where("organizationPartyId", organizationPartyId)
                .orderBy("effectiveDate")
                .queryFirst();
        GenericValue maxEff = EntityQuery.use(delegator)
                .from("EmployeePayrollAssignment")
                .where("organizationPartyId", organizationPartyId)
                .orderBy("-effectiveDate")
                .queryFirst();

        out.put("minEffectiveDate", minEff == null ? null : minEff.getTimestamp("effectiveDate"));
        out.put("maxEffectiveDate", maxEff == null ? null : maxEff.getTimestamp("effectiveDate"));
        return out;
    }

    /* ----------------------------
     * Results / Posting counts for stages
     * ---------------------------- */

    /** Keep your original int-returning method (used elsewhere). */
    public static int countResultsForRun(Delegator delegator, String payrollRunId) throws GenericEntityException {
        if (UtilValidate.isEmpty(payrollRunId)) return 0;
        long cnt = EntityQuery.use(delegator)
                .from("EmployeePayrollResult")
                .where("payrollRunId", payrollRunId)
                .queryCount();
        return (int) Math.min(Integer.MAX_VALUE, cnt);
    }

    /** CONTRACT ALIAS: if scheduler expects long, this provides it. */
    public static long countResultsForRunLong(Delegator delegator, String payrollRunId) throws GenericEntityException {
        return (long) countResultsForRun(delegator, payrollRunId);
    }

    /** Your existing posting count. */
    public static int countPostingsForRun(Delegator delegator, String organizationPartyId, String payrollRunId) throws GenericEntityException {
        if (UtilValidate.isEmpty(payrollRunId) || UtilValidate.isEmpty(organizationPartyId)) return 0;
        long  cnt = EntityQuery.use(delegator)
                .from("PayrollPosting")
                .where("organizationPartyId", organizationPartyId,
                       "payrollRunId", payrollRunId)
                .queryCount();
        return (int) Math.min(Integer.MAX_VALUE, cnt);
    }

    /**
     * CONTRACT METHOD: countPostingLinesForRun(...)
     * Your scheduler notes mention this exact name.
     * For now, map it to PayrollPosting row count.
     * If you later create PayrollPostingLine, update implementation here only.
     */
public static int countPostingLinesForRun(Delegator delegator, String payrollRunId) throws GenericEntityException {
    if (UtilValidate.isEmpty(payrollRunId)) return 0;

    long cnt = EntityQuery.use(delegator)
            .from("PayrollPosting")
            .where("payrollRunId", payrollRunId)
            .queryCount();

    return (int) Math.min(Integer.MAX_VALUE, cnt);
}

    /* ----------------------------
     * Posting mode detection (from accountingPostOptionId)
     * ---------------------------- */

    public static String resolvePostingMode(String accountingPostOptionId) {
        if (UtilValidate.isEmpty(accountingPostOptionId)) return "NONE";

        String v = accountingPostOptionId.trim().toUpperCase(Locale.ROOT);

        if (v.contains("GL")) return "GL";
        if (v.contains("INV") || v.contains("INVOICE")) return "INVOICE";
        if (v.contains("BANK")) return "BANK";
        if (v.contains("NONE") || v.equals("PO_NONE")) return "NONE";

        return v;
    }

    /* ----------------------------
     * Utility: resolve period name duplicates message
     * ---------------------------- */

    public static String formatDuplicatePeriodsMessage(Map<String, List<String>> dupMap) {
        if (dupMap == null || dupMap.isEmpty()) return null;

        StringBuilder sb = new StringBuilder();
        sb.append("Duplicate PayrollPeriod detected. Use payrollPeriodId explicitly. ");
        boolean first = true;
        for (Map.Entry<String, List<String>> e : dupMap.entrySet()) {
            if (!first) sb.append(" | ");
            first = false;
            sb.append(e.getKey()).append(": ").append(e.getValue());
        }
        return sb.toString();
    }

    /* ----------------------------
     * Safe wrappers (optional use)
     * ---------------------------- */

    public static GenericValue safeFindPeriod(Delegator d, String periodId) {
        try {
            return findPayrollPeriodById(d, periodId);
        } catch (Exception e) {
            Debug.logError(e, "safeFindPeriod failed", MODULE);
            return null;
        }
    }

    /* =========================================================
     * FINANCIAL / POSTING PREREQUISITE VALIDATIONS
     * ========================================================= */

    public static boolean hasCurrency(Delegator delegator, String currencyUomId)
            throws GenericEntityException {

        if (UtilValidate.isEmpty(currencyUomId)) return false;

        GenericValue gv = EntityQuery.use(delegator)
                .from("Uom")
                .where("uomId", currencyUomId)
                .queryOne();

        return gv != null;
    }

    public static boolean hasFxRate(Delegator delegator,
                                    String organizationPartyId,
                                    String fromCurrency,
                                    String toCurrency)
            throws GenericEntityException {

        if (UtilValidate.isEmpty(fromCurrency) || UtilValidate.isEmpty(toCurrency))
            return true;

        if (fromCurrency.equals(toCurrency))
            return true;

        GenericValue rate = EntityQuery.use(delegator)
                .from("PayrollCurrencyRate")
                .where("organizationPartyId", organizationPartyId,
                       "fromCurrencyUomId", fromCurrency,
                       "toCurrencyUomId", toCurrency)
                .orderBy("-rateDate")
                .queryFirst();

        return rate != null;
    }

    public static boolean hasGlPostingMode(String accountingPostOptionId) {
        if (UtilValidate.isEmpty(accountingPostOptionId)) return false;
        return accountingPostOptionId.toUpperCase(Locale.ROOT).contains("GL");
    }

    public static boolean hasInvoicePostingMode(String accountingPostOptionId) {
        if (UtilValidate.isEmpty(accountingPostOptionId)) return false;
        return accountingPostOptionId.toUpperCase(Locale.ROOT).contains("INV");
    }

    public static boolean hasBankTransferConfig(Delegator delegator,
                                               String organizationPartyId,
                                               String bankTransferConfigId)
            throws GenericEntityException {

        if (UtilValidate.isEmpty(bankTransferConfigId)) return false;

        GenericValue gv = EntityQuery.use(delegator)
                .from("BankTransferConfig")
                .where("organizationPartyId", organizationPartyId,
                       "bankTransferConfigId", bankTransferConfigId,
                       "isActive", "Y")
                .queryOne();

        return gv != null;
    }

    public static boolean hasGlMappings(Delegator delegator, String organizationPartyId)
            throws GenericEntityException {

   long cnt = EntityQuery.use(delegator)
        .from("PayrollGlMapping")
        .where("organizationPartyId", organizationPartyId)
        .queryCount();

return cnt > 0;

    }

    public static boolean hasAnyAssignments(Delegator delegator, String organizationPartyId)
            throws GenericEntityException {

        long  cnt = EntityQuery.use(delegator)
                .from("EmployeePayrollAssignment")
                .where("organizationPartyId", organizationPartyId)
                .queryCount();

        return cnt > 0;

    }

    // ----------------------------
    // local helper
    // ----------------------------
    private static String asString(Map<String, Object> ctx, String key) {
        if (ctx == null) return null;
        Object v = ctx.get(key);
        return v == null ? null : String.valueOf(v);
    }
}
