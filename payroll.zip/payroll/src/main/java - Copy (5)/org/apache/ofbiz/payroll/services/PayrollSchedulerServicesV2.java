package org.apache.ofbiz.payroll.services;

import org.apache.ofbiz.base.util.Debug;
import org.apache.ofbiz.base.util.UtilDateTime;
import org.apache.ofbiz.base.util.UtilMisc;
import org.apache.ofbiz.base.util.UtilValidate;

import org.apache.ofbiz.entity.Delegator;
import org.apache.ofbiz.entity.GenericEntityException;
import org.apache.ofbiz.entity.GenericValue;
import org.apache.ofbiz.entity.util.EntityQuery;

import org.apache.ofbiz.service.DispatchContext;
import org.apache.ofbiz.service.LocalDispatcher;
import org.apache.ofbiz.service.ModelService;
import org.apache.ofbiz.service.ServiceUtil;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.io.PrintWriter;
import java.io.StringWriter;

import org.apache.commons.lang3.exception.ExceptionUtils;

import java.util.Map;
import java.util.List;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashMap;

import org.apache.ofbiz.entity.GenericEntityException;
import org.apache.ofbiz.entity.GenericValue;
import org.apache.ofbiz.entity.util.EntityQuery;
import org.apache.ofbiz.base.util.UtilValidate;

import org.apache.ofbiz.base.util.Debug;
import org.apache.ofbiz.base.util.UtilValidate;
import org.apache.ofbiz.entity.Delegator;
import org.apache.ofbiz.entity.GenericEntityException;
import org.apache.ofbiz.entity.GenericValue;
import org.apache.ofbiz.entity.util.EntityQuery;
import org.apache.ofbiz.service.DispatchContext;
import org.apache.ofbiz.service.LocalDispatcher;
import org.apache.ofbiz.service.ServiceUtil;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.List;
import java.util.Map;


/**
 * PayrollSchedulerServicesV2 (PRODUCTION SAFE + ENHANCED RESPONSE)
 *
 * Enhancements added:
 * - Uses PayrollRunResolver to resolve payrollRunId vs payrollPeriodId (one-and-only-one policy)
 * - Uses PayrollValidationQueries to produce explicit prereq messages + eligible counts
 * - Uses PayrollRunResponseBuilder to return stage-by-stage execution summary
 * - Prevents "success but nothing processed" by reporting WHY (validation + stage statuses)
 *
 * NOTE:
 * This file expects the following new classes (as requested by you):
 *  - PayrollStageIds
 *  - PayrollRunResolver
 *  - PayrollValidationQueries
 *  - PayrollRunResponseBuilder
 *
 * Existing behavior preserved:
 * - Idempotent get-or-create PayrollRun
 * - Safe approve/post with skip logic
 * - Workers self-reschedule and avoid duplicate JobSandbox rows
 */
public class PayrollSchedulerServicesV2 {
    public static final String MODULE = PayrollSchedulerServicesV2.class.getName();

    // ----------------------------
    // V2 Job Names (avoid collision with existing jobs)
    // ----------------------------
    public static final String JOB_MONTHLY_PAYROLL_V2   = "PAYROLL_MONTHLY_RUNNER_V2";
    public static final String JOB_EMAIL_WORKER_V2      = "PAYROLL_EMAIL_WORKER_V2";
    public static final String JOB_SMS_WORKER_V2        = "PAYROLL_SMS_WORKER_V2";
    public static final String JOB_EXPORT_WORKER_V2     = "PAYROLL_EXPORT_WORKER_V2";
    public static final String JOB_COMPLIANCE_WORKER_V2 = "PAYROLL_COMPLIANCE_WORKER_V2";
   // final String STAGE_APPROVE = "APPROVE";

    // ----------------------------
    // Worker intervals
    // ----------------------------
    private static final long EMAIL_INTERVAL_MS  = 5L * 60L * 1000L;
    private static final long SMS_INTERVAL_MS    = 5L * 60L * 1000L;
    private static final long EXPORT_INTERVAL_MS = 10L * 60L * 1000L;

    // Daily compliance time
    private static final int COMPLIANCE_HOUR = 2; // 02:00 daily

    // Monthly run time (scheduler)
    private static final int MONTHLY_RUN_DAY  = 1;
    private static final int MONTHLY_RUN_HOUR = 1;

    // ----------------------------
    // Full-cycle switches (safe defaults)
    // ----------------------------
    private static final boolean AUTO_APPROVE = true;
    private static final boolean AUTO_POST    = true;

    /**
     * Default posting option if PayrollRun.accountingPostOptionId is empty.
     * Align with your data:
     * PAY_POST_NONE / PAY_POST_GL / PAY_POST_INVOICE / PAY_POST_BOTH
     */
    private static final String DEFAULT_POST_OPTION = "PAY_POST_BOTH";

    // ----------------------------
    // PayrollRun statuses (align with your data)
    // ----------------------------
   // ----------------------------
// PayrollRun statuses (align with your data)
// ----------------------------
// PayrollRun statuses (align with your imported XML data)
// Source: plugins/payroll/data/PayrollStatusData.xml (PAY_RUN_STAT)
// ----------------------------

// Your dataset does NOT define PR_NEW, so treat "NEW" as DRAFT for control-flow checks.
private static final String ST_NEW        = "PR_DRAFT";  // "Draft" (acts as NEW in your workflow)
private static final String ST_SUBMITTED  = "PR_SUBM";   // "Submitted"
private static final String ST_APPROVED   = "PR_APPR";   // "Approved"
private static final String ST_PROCESSING = "PR_PROC";   // "Processing"
private static final String ST_DONE       = "PR_DONE";   // "Completed"
private static final String ST_POSTED     = "PR_POST";   // "Posted"
private static final String ST_FAILED     = "PR_FAIL";   // "Failed"
private static final String ST_VOID       = "PR_VOID";   // "Voided"
 
private static final String RUN_STATUS_NEW = "PR_DRAFT";
private static final String RUN_STATUS_DRAFT = "PR_DRAFT";
private static final String RUN_STATUS_PROCESSED = "PR_PROC";   // required by processPayrollRun

// Put it HERE (class scope)
    



    /**
     * Main entry: Run monthly payroll for requested org or all active PayrollOrganization records.
     *
     * Inputs (typical):
     * - userLogin (required) or userLoginId
     * - currencyUomId (required)
     * - organizationPartyId (optional; if empty -> all PayrollOrganization isActive=Y)
     * - payrollPeriodId (optional; resolver can choose latest open period)
     * - accountingPostOptionId (optional; if empty -> DEFAULT_POST_OPTION)
     * - vendorPartyId / invoiceTypeId (optional for invoice posting)
     * - bankTransferConfigId (optional)
     * - dryRun/testMode (optional)
     *
     * Enhanced Output:
     * - In addition to okCount/errorCount/nextRunTime/message, it can return:
     *   data.payrollRunIdResolved, data.periodIdResolved, data.stages[], data.messages[], etc.
     */
public static java.util.Map<String, Object> runMonthlyPayrollV2(DispatchContext dctx, java.util.Map<String, ?> context) {
    final Delegator delegator = dctx.getDelegator();
    final LocalDispatcher dispatcher = dctx.getDispatcher();
final String STAGE_APPROVE = "APPROVE";

    // ----------------------------
    // Identity
    // ----------------------------
    GenericValue userLogin = (GenericValue) context.get("userLogin");
    final String userLoginId = (String) context.get("userLoginId");

    if (userLogin == null && UtilValidate.isNotEmpty(userLoginId)) {
        try {
            userLogin = EntityQuery.use(delegator)
                    .from("UserLogin")
                    .where("userLoginId", userLoginId)
                    .cache(false)
                    .queryOne();
        } catch (Exception e) {
            Debug.logError(e, "runMonthlyPayrollV2 failed loading UserLogin userLoginId=" + userLoginId, MODULE);
            return ServiceUtil.returnError("Invalid userLoginId=" + userLoginId);
        }
    }

    // ----------------------------
    // Inputs
    // ----------------------------
    final String requestedOrgPartyId = (String) context.get("organizationPartyId");
    final String requestedPayrollPeriodId = (String) context.get("payrollPeriodId");
    final String requestedPayrollRunId = (String) context.get("payrollRunId");
    final String currencyUomId = (String) context.get("currencyUomId");
    final String accountingPostOptionIdIn = (String) context.get("accountingPostOptionId");

    final String dryRunStr = (String) context.get("dryRun");
    final String testModeStr = (String) context.get("testMode");
    final String executeNowStr = (String) context.get("executeNow");

    final boolean isDryRun = "Y".equalsIgnoreCase(dryRunStr) || "true".equalsIgnoreCase(dryRunStr);
    final boolean isTestMode = "Y".equalsIgnoreCase(testModeStr) || "true".equalsIgnoreCase(testModeStr);
    final boolean doExecuteNow = "Y".equalsIgnoreCase(executeNowStr) || "true".equalsIgnoreCase(executeNowStr);

    final String partyIdFilter = (String) context.get("partyId"); // optional employee filter
    final String bankTransferConfigId = (String) context.get("bankTransferConfigId"); // optional

    // ----------------------------
    // Guardrails
    // ----------------------------
    if (userLogin == null) {
        return ServiceUtil.returnError("userLogin is required (provide userLogin in webtools OR userLoginId for REST/job).");
    }
    if (UtilValidate.isEmpty(currencyUomId)) {
        return ServiceUtil.returnError("currencyUomId is required.");
    }

    // ----------------------------
    // Determine org(s)
    // ----------------------------
    final java.util.List<String> orgPartyIds = new java.util.ArrayList<>();
    try {
        if (UtilValidate.isNotEmpty(requestedOrgPartyId)) {
            orgPartyIds.add(requestedOrgPartyId);
        } else {
            java.util.List<GenericValue> orgs = EntityQuery.use(delegator)
                    .from("PayrollOrganization")
                    .where("isActive", "Y")
                    .cache(false)
                    .queryList();

            for (GenericValue org : orgs) {
                String orgPartyId = org.getString("organizationPartyId");
                if (UtilValidate.isNotEmpty(orgPartyId)) {
                    orgPartyIds.add(orgPartyId);
                }
            }
        }
    } catch (Exception e) {
        Debug.logError(e, "runMonthlyPayrollV2 failed loading PayrollOrganization list", MODULE);
        return ServiceUtil.returnError("Failed to load payroll organizations: " + safeMsg(e));
    }

    if (orgPartyIds.isEmpty()) {
        return ServiceUtil.returnError("No active payroll organizations found (PayrollOrganization.isActive='Y').");
    }

    Debug.logInfo("runMonthlyPayrollV2 START orgCount=" + orgPartyIds.size()
            + " requestedOrg=" + requestedOrgPartyId
            + " requestedPeriod=" + requestedPayrollPeriodId
            + " requestedRunId=" + requestedPayrollRunId
            + " currencyUomId=" + currencyUomId
            + " dryRun=" + isDryRun
            + " testMode=" + isTestMode
            + " executeNow=" + doExecuteNow
            + " userLoginId=" + userLogin.getString("userLoginId"), MODULE);

    final java.util.Calendar cal = java.util.Calendar.getInstance();
    final int month = cal.get(java.util.Calendar.MONTH) + 1;
    final int year = cal.get(java.util.Calendar.YEAR);

    int okCount = 0;
    int errCount = 0;

    // flat error list for REST errorDescription
    final java.util.List<String> flatErrors = new java.util.ArrayList<>();

    final PayrollRunResponseBuilder.ResponseBuilder rb =
            PayrollRunResponseBuilder.newBuilder()
                    .withRequestContext(requestedOrgPartyId, requestedPayrollPeriodId, requestedPayrollRunId, currencyUomId);

    // ----------------------------
    // Per-org loop
    // ----------------------------
    for (String organizationPartyId : orgPartyIds) {
        final PayrollRunResponseBuilder.OrgRunBuilder orgRb = rb.org(organizationPartyId);

        // Track the "current stage" for unexpected exceptions
        String currentStage = PayrollStageIds.RESOLVE;

        try {
            Debug.logInfo("runMonthlyPayrollV2 ORG begin org=" + organizationPartyId, MODULE);

            // Optional pre-step (safe)
            java.util.Map<String, Object> baseCtx = org.apache.ofbiz.base.util.UtilMisc.toMap(
                    "organizationPartyId", organizationPartyId,
                    "runMonth", month,
                    "runYear", year,
                    "sourceIp", "SCHEDULER",
                    "userLogin", userLogin
            );
            runIfExists(dispatcher, "buildAttendancePeriodSummary", baseCtx);

            // ----------------------------
            // STAGE 1: RESOLVE
            // ----------------------------
            currentStage = PayrollStageIds.RESOLVE;
            orgRb.stage(PayrollStageIds.RESOLVE).start();

            PayrollRunResolver.ResolvedRun rr = PayrollRunResolver.resolve(
                    delegator,
                    dispatcher,
                    userLogin,
                    organizationPartyId,
                    requestedPayrollPeriodId,
                    requestedPayrollRunId,
                    currencyUomId,
                    accountingPostOptionIdIn,
                    null,
                    (java.util.Map<String, ?>) context
            );

            if (rr == null || !rr.isOk()) {
                String msg = (rr == null) ? "Resolver returned null" : rr.getErrorMessage();
                addStageError(rb, orgRb, flatErrors, organizationPartyId, PayrollStageIds.RESOLVE, "RESOLVE_FAILED", "Resolve failed: " + msg);
                errCount++;
                continue;
            }

            final String payrollPeriodId = rr.getPayrollPeriodIdResolved();
            String payrollRunId = rr.getPayrollRunIdResolved(); // MUTABLE: we may create it

            orgRb.resolved(payrollRunId, payrollPeriodId);

            if (UtilValidate.isEmpty(payrollPeriodId)) {
                addStageError(rb, orgRb, flatErrors, organizationPartyId, PayrollStageIds.RESOLVE, "RESOLVE_FAILED",
                        "Resolved payrollPeriodId is empty.");
                errCount++;
                continue;
            }

            // If execute mode and resolver did not give a runId, create/ensure PayrollRun now.
            if (!(isDryRun || isTestMode) && UtilValidate.isEmpty(payrollRunId)) {
                try {
                    payrollRunId = ensurePayrollRunExistsForExecuteV2(
                            delegator,
                            organizationPartyId,
                            payrollPeriodId,
                            currencyUomId,
                            (UtilValidate.isNotEmpty(accountingPostOptionIdIn) ? accountingPostOptionIdIn : DEFAULT_POST_OPTION),
                            userLogin
                    );
                    orgRb.resolved(payrollRunId, payrollPeriodId);
                } catch (Exception ex) {
                    addStageError(rb, orgRb, flatErrors, organizationPartyId, PayrollStageIds.RESOLVE, "RUN_CREATE_FAILED",
                            "Failed to create PayrollRun for execute mode: " + safeMsg(ex));
                    errCount++;
                    continue;
                }
            }

            orgRb.stage(PayrollStageIds.RESOLVE).ok("Resolved period/run", 1, 0);

            // ----------------------------
            // STAGE 2: VALIDATE
            // ----------------------------
            currentStage = PayrollStageIds.VALIDATE;
            orgRb.stage(PayrollStageIds.VALIDATE).start();

            PayrollValidationQueries.ValidationResult vr =
                    PayrollValidationQueries.validateForMonthlyRun(
                            delegator,
                            organizationPartyId,
                            payrollRunId, // should exist in execute mode
                            payrollPeriodId,
                            currencyUomId,
                            accountingPostOptionIdIn,
                            partyIdFilter
                    );

            if (vr == null) {
                addStageError(rb, orgRb, flatErrors, organizationPartyId, PayrollStageIds.VALIDATE, "VALIDATION",
                        "ValidationResult is null.");
                errCount++;
                continue;
            }

            orgRb.eligibleCount(safeInt(vr.getEligibleCount()));

            if (!vr.isOk()) {
                String summary = UtilValidate.isNotEmpty(vr.getSummaryText()) ? vr.getSummaryText() : "Validation failed.";
                orgRb.stage(PayrollStageIds.VALIDATE).error(summary);
                flatErrors.add("org=" + organizationPartyId + " VALIDATE: " + summary);

                if (vr.getMessages() != null) {
                    for (String m : vr.getMessages()) {
                        rb.addError("VALIDATION", "org=" + organizationPartyId + " : " + m);
                        flatErrors.add("org=" + organizationPartyId + " VALIDATE: " + m);
                    }
                }

                errCount++;
                continue;
            }

            orgRb.stage(PayrollStageIds.VALIDATE).ok(vr.getSummaryText(), safeInt(vr.getOkCount()), safeInt(vr.getErrorCount()));

            // Stop after validation for dry/test
            if (isDryRun || isTestMode) {
                orgRb.stage(PayrollStageIds.CALCULATE).warn("DryRun/TestMode enabled: calculation/posting skipped.");
                okCount++;
                continue;
            }

            if (UtilValidate.isEmpty(payrollRunId)) {
                addStageError(rb, orgRb, flatErrors, organizationPartyId, PayrollStageIds.VALIDATE, "VALIDATION",
                        "Resolved payrollRunId is empty in execute mode (unexpected).");
                errCount++;
                continue;
            }

            // ----------------------------
            // STAGE 3: CALCULATE
            // ----------------------------
            currentStage = PayrollStageIds.CALCULATE;
            orgRb.stage(PayrollStageIds.CALCULATE).start();

            GenericValue run = reloadPayrollRun(delegator, payrollRunId);
            if (run == null) {
                addStageError(rb, orgRb, flatErrors, organizationPartyId, PayrollStageIds.CALCULATE, "RUN_NOT_FOUND",
                        "PayrollRun not found: payrollRunId=" + payrollRunId);
                errCount++;
                continue;
            }

            String runStatusId = run.getString("statusId");
            if (ST_NEW.equals(runStatusId)) {
                java.util.Map<String, Object> processed = dispatcher.runSync(
                        "processPayrollRun",
                        org.apache.ofbiz.base.util.UtilMisc.toMap(
                                "payrollRunId", payrollRunId,
                                "forceRecalc", Boolean.FALSE,
                                "sourceIp", "SCHEDULER",
                                "userLogin", userLogin
                        )
                );
                if (ServiceUtil.isError(processed)) {
                    addStageError(rb, orgRb, flatErrors, organizationPartyId, PayrollStageIds.CALCULATE, "PROCESS_FAILED",
                            "processPayrollRun failed: " + ServiceUtil.getErrorMessage(processed));
                    errCount++;
                    continue;
                }
            } else {
                orgRb.stage(PayrollStageIds.CALCULATE).warn("Skipped calculate: run is not NEW (status=" + runStatusId + ")");
            }

            int calculatedCount = PayrollValidationQueries.countResultsForRun(delegator, payrollRunId);
            orgRb.calculatedCount(calculatedCount);
            orgRb.stage(PayrollStageIds.CALCULATE).ok("Results created/available", calculatedCount, 0);

            // Reload after calc
            run = reloadPayrollRun(delegator, payrollRunId);
            runStatusId = (run != null) ? run.getString("statusId") : null;

            // ----------------------------
            // STAGE 4: APPROVE (optional)
            // ----------------------------
            if (AUTO_APPROVE && run != null && ST_NEW.equals(runStatusId)) {
                currentStage = STAGE_APPROVE;
                 orgRb.stage(STAGE_APPROVE).start();
                java.util.Map<String, Object> approved = dispatcher.runSync(
                        "approvePayrollRun",
                        org.apache.ofbiz.base.util.UtilMisc.toMap(
                                "payrollRunId", payrollRunId,
                                "sourceIp", "SCHEDULER",
                                "userLogin", userLogin
                        )
                );
                if (ServiceUtil.isError(approved)) {
                  //  addStageError(rb, orgRb, flatErrors, organizationPartyId, PayrollStageIds.APPROVE, "APPROVE_FAILED",
                       //     "approvePayrollRun failed: " + ServiceUtil.getErrorMessage(approved));
							addStageError(rb, orgRb, flatErrors, organizationPartyId, STAGE_APPROVE, "APPROVE_FAILED",
                          "approvePayrollRun failed: " + ServiceUtil.getErrorMessage(approved));

                    errCount++;
                    continue;
                }
               // orgRb.stage(PayrollStageIds.APPROVE).ok("Approved", 1, 0);
                 orgRb.stage(STAGE_APPROVE).ok("Approved", 1, 0);
                run = reloadPayrollRun(delegator, payrollRunId);
                runStatusId = (run != null) ? run.getString("statusId") : null;
            }

            // ----------------------------
            // STAGE 5: POST (optional)
            // ----------------------------
            int postedCount = 0;

            String accountingPostOptionId = accountingPostOptionIdIn;
            if (UtilValidate.isEmpty(accountingPostOptionId) && run != null) accountingPostOptionId = run.getString("accountingPostOptionId");
            if (UtilValidate.isEmpty(accountingPostOptionId)) accountingPostOptionId = DEFAULT_POST_OPTION;

            boolean wantsGl = "PAY_POST_GL".equals(accountingPostOptionId) || "PAY_POST_BOTH".equals(accountingPostOptionId);
            boolean wantsInv = "PAY_POST_INVOICE".equals(accountingPostOptionId) || "PAY_POST_BOTH".equals(accountingPostOptionId);

            if (AUTO_POST) {
                currentStage = PayrollStageIds.POST_GL;

                boolean alreadyPostedFlags =
                        run != null && ("Y".equalsIgnoreCase(run.getString("isGlPosted")) || "Y".equalsIgnoreCase(run.getString("isInvoicePosted")));

                if (run != null && (ST_POSTED.equals(runStatusId) || alreadyPostedFlags)) {
                    if (wantsGl) orgRb.stage(PayrollStageIds.POST_GL).warn("Skipped posting: already posted (status/flags).");
                    if (wantsInv) orgRb.stage(PayrollStageIds.POST_INV).warn("Skipped posting: already posted (status/flags).");
                } else if (run != null && !ST_APPROVED.equals(runStatusId)) {
                    if (wantsGl) orgRb.stage(PayrollStageIds.POST_GL).warn("Skipped posting: run not approved (status=" + runStatusId + ").");
                    if (wantsInv) orgRb.stage(PayrollStageIds.POST_INV).warn("Skipped posting: run not approved (status=" + runStatusId + ").");
                } else {
                    java.util.Map<String, Object> postCtx = org.apache.ofbiz.base.util.UtilMisc.toMap(
                            "payrollRunId", payrollRunId,
                            "organizationPartyId", organizationPartyId,
                            "accountingPostOptionId", accountingPostOptionId,
                            "vendorPartyId", context.get("vendorPartyId"),
                            "invoiceTypeId", context.get("invoiceTypeId"),
                            "forceRepost", Boolean.FALSE,
                            "sourceIp", "SCHEDULER",
                            "userLogin", userLogin
                    );

                    java.util.Map<String, Object> postRes = runIfExistsReturn(dispatcher, "postPayrollRunAccounting", postCtx);
                    if (postRes == null) {
                        postRes = dispatcher.runSync("postPayrollRun", postCtx);
                    }

                    if (ServiceUtil.isError(postRes)) {
                        String msg = "Posting failed: " + ServiceUtil.getErrorMessage(postRes);
                        if (wantsGl) addStageError(rb, orgRb, flatErrors, organizationPartyId, PayrollStageIds.POST_GL, "POST_FAILED", msg);
                        if (wantsInv) addStageError(rb, orgRb, flatErrors, organizationPartyId, PayrollStageIds.POST_INV, "POST_FAILED", msg);
                        errCount++;
                        continue;
                    }

                    postedCount = safeInt(PayrollValidationQueries.countPostingLinesForRun(delegator, payrollRunId));
                    orgRb.postedCount(postedCount);

                    if (wantsGl) orgRb.stage(PayrollStageIds.POST_GL).ok("GL postings created", postedCount, 0);
                    if (wantsInv) orgRb.stage(PayrollStageIds.POST_INV).ok("Invoice postings created", postedCount, 0);

                    // ----------------------------
                    // STAGE 6: BANK (optional)
                    // ----------------------------
                    if (UtilValidate.isNotEmpty(bankTransferConfigId)) {
                        currentStage = PayrollStageIds.BANK;
                        orgRb.stage(PayrollStageIds.BANK).start();
                        try {
                            runIfExists(dispatcher, "generateBankTransferBatchForRun",
                                    org.apache.ofbiz.base.util.UtilMisc.toMap(
                                            "payrollRunId", payrollRunId,
                                            "bankTransferConfigId", bankTransferConfigId,
                                            "sourceIp", "SCHEDULER",
                                            "userLogin", userLogin
                                    ));
                            orgRb.stage(PayrollStageIds.BANK).ok("Bank batch generated", 1, 0);
                        } catch (Exception be) {
                            orgRb.stage(PayrollStageIds.BANK).warn("Bank batch skipped/failed: " + safeMsg(be));
                        }
                    }
                }
            } else {
                orgRb.stage(PayrollStageIds.POST_GL).warn("AUTO_POST disabled: posting skipped.");
                orgRb.stage(PayrollStageIds.POST_INV).warn("AUTO_POST disabled: posting skipped.");
            }

            okCount++;

        } catch (Exception e) {
            Debug.logError(e, "runMonthlyPayrollV2 ORG failed org=" + organizationPartyId, MODULE);
            addStageError(rb, orgRb, flatErrors, organizationPartyId, currentStage, "UNEXPECTED_EXCEPTION",
                    "Unexpected error: " + safeMsg(e));
            errCount++;
        }
    }

    // ----------------------------
    // Reschedule job (if not executeNow)
    // ----------------------------
    final java.sql.Timestamp nextMonthly = nextMonthlyTime(MONTHLY_RUN_DAY, MONTHLY_RUN_HOUR);
    boolean scheduleOk = true;
    String scheduleWarn = null;

    if (!doExecuteNow) {
        try {
            ensureSingleScheduled(delegator, JOB_MONTHLY_PAYROLL_V2, "runMonthlyPayrollV2", nextMonthly, userLogin);
        } catch (GenericEntityException gee) {
            scheduleOk = false;
            scheduleWarn = "Scheduling next monthly run failed: " + safeMsg(gee);
            Debug.logError(gee, "runMonthlyPayrollV2 scheduling failed jobId=" + JOB_MONTHLY_PAYROLL_V2 + " nextMonthly=" + nextMonthly, MODULE);

            rb.addError("SCHEDULE_FAILED", scheduleWarn);
            flatErrors.add("SCHEDULE: " + scheduleWarn);
        }
    }

    // ----------------------------
    // Build enhanced payload (stages + errors)
    // ----------------------------
    final java.util.Map<String, Object> enhanced = rb.build(); // expected {data=..., message=...}
    final Object payloadObj = (enhanced != null) ? enhanced.get("data") : null;

    @SuppressWarnings("unchecked")
    final java.util.Map<String, Object> payload =
            (payloadObj instanceof java.util.Map) ? (java.util.Map<String, Object>) payloadObj : new java.util.HashMap<String, Object>();

    payload.put("errorsFlat", flatErrors);

    // ----------------------------
    // Build REST-friendly data
    // ----------------------------
    final boolean ok = (errCount == 0);

    final java.util.Map<String, Object> legacyData = new java.util.HashMap<String, Object>();
    legacyData.put("okCount", okCount);
    legacyData.put("errorCount", errCount);
    legacyData.put("nextRunTime", nextMonthly);
    legacyData.put("ok", ok);
    legacyData.put("scheduleOk", scheduleOk);
    if (scheduleWarn != null) legacyData.put("scheduleWarning", scheduleWarn);
    legacyData.put("payload", payload);
    legacyData.put("payloadMessage", (enhanced != null) ? enhanced.get("message") : null);
    legacyData.put("_buildMarker", "RUNMONTHLY_V2_PAYLOAD_OK");

    // ----------------------------
    // Final return (ALWAYS attach data)
    // ----------------------------
    final java.util.Map<String, Object> out =
            ServiceUtil.returnSuccess("###RUNMONTHLY_V2_ENHANCED### ok=" + okCount + " err=" + errCount);
    out.put("data", legacyData);

    if (!ok) {
        StringBuilder sb = new StringBuilder("Monthly payroll failed. ");
        if (!flatErrors.isEmpty()) {
            sb.append("Top errors: ");
            int max = Math.min(flatErrors.size(), 5);
            for (int i = 0; i < max; i++) {
                if (i > 0) sb.append(" | ");
                sb.append(flatErrors.get(i));
            }
            if (flatErrors.size() > max) sb.append(" | ... (").append(flatErrors.size()).append(" total)");
            sb.append(". ");
        }
        sb.append("See data.payload.stages and data.payload.errors.");

        java.util.Map<String, Object> err = ServiceUtil.returnError(sb.toString());
        err.put("successMessage", out.get("successMessage"));
        err.put("data", legacyData);
        return err;
    }

    return out;
}

/**
 * Create PayrollRun if missing for execute mode.
 * IMPORTANT: statusId must match existing StatusItem in PAY_RUN_STAT (your DB shows PR_DRAFT etc.)
 */
private static String ensurePayrollRunExistsForExecuteV2(Delegator delegator,
                                                        String organizationPartyId,
                                                        String payrollPeriodId,
                                                        String currencyUomId,
                                                        String accountingPostOptionId,
                                                        GenericValue userLogin) throws GenericEntityException {

    // 1) Return existing run for same org+period (latest)
    GenericValue existing = EntityQuery.use(delegator)
            .from("PayrollRun")
            .where("organizationPartyId", organizationPartyId,
                   "payrollPeriodId", payrollPeriodId)
            .orderBy("createdStamp DESC")
            .cache(false)
            .queryFirst();

   if (existing != null) {
    String st = existing.getString("statusId");
    if (RUN_STATUS_DRAFT.equals(st)) {
        existing.put("statusId", RUN_STATUS_PROCESSED);
        existing.store();
    }
    return existing.getString("payrollRunId");
}


    // 2) Create new
    final String payrollRunId = delegator.getNextSeqId("PayrollRun");
    final GenericValue run = delegator.makeValue("PayrollRun");
     run.put("statusId", RUN_STATUS_PROCESSED);

    run.put("payrollRunId", payrollRunId);
    run.put("organizationPartyId", organizationPartyId);
    run.put("payrollPeriodId", payrollPeriodId);

    // minimal fields (leave others null unless required by your entity model)
    if (UtilValidate.isNotEmpty(currencyUomId)) run.put("currencyUomId", currencyUomId);
    if (UtilValidate.isNotEmpty(accountingPostOptionId)) run.put("accountingPostOptionId", accountingPostOptionId);

    // Use an EXISTING status from PAY_RUN_STAT to satisfy FK RUN_STAT
    // Your DB shows PR_DRAFT / PR_PROC / ...
    run.put("statusId", "PR_DRAFT");

    if (userLogin != null && UtilValidate.isNotEmpty(userLogin.getString("userLoginId"))) {
        run.put("createdByUserLoginId", userLogin.getString("userLoginId"));
    }

    delegator.create(run);
    return payrollRunId;
}

private static void addStageError(PayrollRunResponseBuilder.ResponseBuilder rb,
                                  PayrollRunResponseBuilder.OrgRunBuilder orgRb,
                                  java.util.List<String> flatErrors,
                                  String orgId,
                                  String stageId,
                                  String code,
                                  String msg) {
    try {
        orgRb.stage(stageId).error(msg);
    } catch (Exception ignore) {
        // don't destabilize response building
    }
    rb.addError(code, "org=" + orgId + " : " + msg);
    flatErrors.add("org=" + orgId + " " + stageId + ": " + msg);
}

/**
 * Ensures a PayrollRun exists for execute mode.
 * NOTE: You MUST set RUN_STATUS_NEW to a valid StatusItem for PayrollRun.statusId in your database.
 */
private static String ensurePayrollRunExistsForExecute(Delegator delegator,
                                                       String organizationPartyId,
                                                       String payrollPeriodId,
                                                       String currencyUomId,
                                                       String accountingPostOptionId,
                                                       GenericValue userLogin) throws GenericEntityException {

    // 1) Reuse if already exists
    GenericValue existing = EntityQuery.use(delegator)
            .from("PayrollRun")
            .where("organizationPartyId", organizationPartyId,
                   "payrollPeriodId", payrollPeriodId)
            .orderBy("-createdStamp")
            .cache(false)
            .queryFirst();

    if (existing != null) {
        return existing.getString("payrollRunId");
    }

    // 2) Create new run
    final String payrollRunId = delegator.getNextSeqId("PayrollRun");
    final GenericValue run = delegator.makeValue("PayrollRun");

    run.put("payrollRunId", payrollRunId);
    run.put("organizationPartyId", organizationPartyId);
    run.put("payrollPeriodId", payrollPeriodId);

    if (UtilValidate.isNotEmpty(currencyUomId)) run.put("currencyUomId", currencyUomId);
    if (UtilValidate.isNotEmpty(accountingPostOptionId)) run.put("accountingPostOptionId", accountingPostOptionId);

    // IMPORTANT: must be valid FK to StatusItem
    run.put("statusId", RUN_STATUS_NEW);

    if (userLogin != null && UtilValidate.isNotEmpty(userLogin.getString("userLoginId"))) {
        run.put("createdByUserLoginId", userLogin.getString("userLoginId"));
    }

    delegator.create(run);
    return payrollRunId;
}

private static String ensurePayrollRunExists(Delegator delegator,
                                             String organizationPartyId,
                                             String payrollPeriodId,
                                             String currencyUomId,
                                             String accountingPostOptionId,
                                             GenericValue userLogin) throws GenericEntityException {

    // Try reuse if already created
    GenericValue existing = EntityQuery.use(delegator)
            .from("PayrollRun")
            .where("organizationPartyId", organizationPartyId,
                   "payrollPeriodId", payrollPeriodId)
            .orderBy("-createdStamp")
            .cache(false)
            .queryFirst();

    if (existing != null) {
        return existing.getString("payrollRunId");
    }

    // Create new run
    String payrollRunId = delegator.getNextSeqId("PayrollRun");
    GenericValue run = delegator.makeValue("PayrollRun");

    run.put("payrollRunId", payrollRunId);
    run.put("organizationPartyId", organizationPartyId);
    run.put("payrollPeriodId", payrollPeriodId);

    if (UtilValidate.isNotEmpty(currencyUomId)) run.put("currencyUomId", currencyUomId);
    if (UtilValidate.isNotEmpty(accountingPostOptionId)) run.put("accountingPostOptionId", accountingPostOptionId);

    // IMPORTANT: set a valid NEW status for PayrollRun in YOUR system.
    // If you don’t know it yet, don’t hardcode "NEW".
    // Use a constant you already use for runs (e.g. ST_NEW).
    run.put("statusId", ST_NEW);

    if (userLogin != null) {
        run.put("createdByUserLoginId", userLogin.getString("userLoginId"));
    }

    delegator.create(run);
    return payrollRunId;
}


private static String safeMsg(Throwable t) {
    if (t == null) return "null";
    String m = t.getMessage();
    return UtilValidate.isNotEmpty(m) ? m : t.toString();
}


private static long countActiveAssignments(Delegator delegator, String organizationPartyId) throws GenericEntityException {
    // Your table name from SQL: employee_payroll_assignment
    // Adjust field names if different.
    return EntityQuery.use(delegator)
            .from("EmployeePayrollAssignment")
            .where("organizationPartyId", organizationPartyId,
                   "statusId", "ACTIVE")
            .queryCount();
}


private static int safeInt(long v) {
    if (v > Integer.MAX_VALUE) return Integer.MAX_VALUE;
    if (v < Integer.MIN_VALUE) return Integer.MIN_VALUE;
    return (int) v;
}


// Scheduler-required overload
public static PayrollValidationQueries.ValidationResult validateForMonthlyRun(Delegator delegator,
                                                                             String organizationPartyId,
                                                                             String payrollRunId,
                                                                             String payrollPeriodId,
                                                                             String currencyUomId,
                                                                             String accountingPostOptionId,
                                                                             String bankTransferConfigId) {
    return PayrollValidationQueries.validateForMonthlyRun(delegator, organizationPartyId, payrollRunId, payrollPeriodId,
            currencyUomId, accountingPostOptionId, bankTransferConfigId);
}

    // ----------------------------
    // Queue workers V2 (self-reschedule)
    // ----------------------------
    public static Map<String, Object> processPayrollEmailQueueWorkerV2(DispatchContext dctx, Map<String, ?> context) {
        return runWorkerAndReschedule(dctx, context,
                "processPayrollEmailQueue",
                JOB_EMAIL_WORKER_V2,
                "processPayrollEmailQueueWorkerV2",
                EMAIL_INTERVAL_MS);
    }

    public static Map<String, Object> processPayrollSmsQueueWorkerV2(DispatchContext dctx, Map<String, ?> context) {
        return runWorkerAndReschedule(dctx, context,
                "processPayrollSmsQueue",
                JOB_SMS_WORKER_V2,
                "processPayrollSmsQueueWorkerV2",
                SMS_INTERVAL_MS);
    }

    public static Map<String, Object> processPayrollExportQueueWorkerV2(DispatchContext dctx, Map<String, ?> context) {
        return runWorkerAndReschedule(dctx, context,
                "processPayrollExportRequestQueue",
                JOB_EXPORT_WORKER_V2,
                "processPayrollExportQueueWorkerV2",
                EXPORT_INTERVAL_MS);
    }

    public static Map<String, Object> processPayrollComplianceDailyWorkerV2(DispatchContext dctx, Map<String, ?> context) {
        LocalDispatcher dispatcher = dctx.getDispatcher();
        Delegator delegator = dctx.getDelegator();
        GenericValue userLogin = (GenericValue) context.get("userLogin");

        try {
            runIfExists(dispatcher, "generatePayrollComplianceReport", UtilMisc.<String, Object>toMap(
                    "periodYear", context.get("periodYear"),
                    "periodMonth", context.get("periodMonth"),
                    "reportTypeId", context.get("reportTypeId"),
                    "sourceIp", "SCHEDULER",
                    "userLogin", userLogin
            ));
        } catch (Exception e) {
            Debug.logError(e, "V2 compliance worker failed", MODULE);
        }

        try {
            Timestamp nextRun = nextDailyTime(COMPLIANCE_HOUR);
            ensureSingleScheduled(delegator, JOB_COMPLIANCE_WORKER_V2, "processPayrollComplianceDailyWorkerV2", nextRun, userLogin);
        } catch (Exception e) {
            Debug.logError(e, "V2 compliance reschedule failed", MODULE);
            return ServiceUtil.returnError("V2 compliance reschedule failed: " + e.getMessage());
        }

        return ServiceUtil.returnSuccess();
    }

    // =========================================================
    // PRODUCTION FIX HELPERS (idempotent run creation)
    // =========================================================

    /**
     * Reuse existing PayrollRun for (org + period) if present in NEW/APPROVED/POSTED.
     * Otherwise create a new run via createPayrollRun service.
     */
    private static GenericValue getOrCreatePayrollRun(Delegator delegator,
                                                     LocalDispatcher dispatcher,
                                                     GenericValue userLogin,
                                                     String organizationPartyId,
                                                     String payrollPeriodId,
                                                     String currencyUomId,
                                                     Map<String, ?> originalContext) throws Exception {

        // Prefer newest run for this org+period (any status)
        GenericValue existing = EntityQuery.use(delegator)
                .from("PayrollRun")
                .where("organizationPartyId", organizationPartyId,
                        "payrollPeriodId", payrollPeriodId)
                .orderBy("-lastUpdatedStamp")
                .cache(false)
                .queryFirst();

        if (existing != null) {
            String st = existing.getString("statusId");
            // Reuse only if it is a normal lifecycle status
            if (ST_NEW.equals(st) || ST_APPROVED.equals(st) || ST_POSTED.equals(st)) {
                return existing;
            }
            // If it's some other unexpected status, still reuse (safer than creating duplicates)
            return existing;
        }

        // Create new run
        Map<String, Object> createCtx = UtilMisc.<String, Object>toMap(
                "organizationPartyId", organizationPartyId,
                "payrollPeriodId", payrollPeriodId,
                "currencyUomId", currencyUomId,
                "valuationCurrencyUomId", originalContext.get("valuationCurrencyUomId"),
                "exchangeRate", originalContext.get("exchangeRate"),
                "runName", buildAutoRunName(payrollPeriodId, originalContext),
                "sourceIp", "SCHEDULER",
                "userLogin", userLogin
        );

        Map<String, Object> created = dispatcher.runSync("createPayrollRun", createCtx);
        if (ServiceUtil.isError(created)) {
            throw new Exception("createPayrollRun failed: " + ServiceUtil.getErrorMessage(created));
        }

        String payrollRunId = (String) created.get("payrollRunId");
        if (UtilValidate.isEmpty(payrollRunId)) {
            throw new Exception("createPayrollRun returned empty payrollRunId");
        }

        return reloadPayrollRun(delegator, payrollRunId);
    }

    private static String buildAutoRunName(String payrollPeriodId, Map<String, ?> originalContext) {
        Object y = originalContext.get("periodYear");
        Object m = originalContext.get("periodMonth");
        if (y != null && m != null) {
            return "AUTO-" + String.valueOf(y) + "-" + String.valueOf(m);
        }
        return "AUTO-" + payrollPeriodId;
    }

    private static GenericValue reloadPayrollRun(Delegator delegator, String payrollRunId) throws GenericEntityException {
        GenericValue run = EntityQuery.use(delegator)
                .from("PayrollRun")
                .where("payrollRunId", payrollRunId)
                .cache(false)
                .queryOne();
        if (run == null) throw new GenericEntityException("PayrollRun not found after create: " + payrollRunId);
        return run;
    }

    // =========================================================
    // Helpers (workers + optional service execution)
    // =========================================================
    private static Map<String, Object> runWorkerAndReschedule(DispatchContext dctx,
                                                             Map<String, ?> context,
                                                             String targetServiceName,
                                                             String jobName,
                                                             String workerServiceName,
                                                             long intervalMs) {
        LocalDispatcher dispatcher = dctx.getDispatcher();
        Delegator delegator = dctx.getDelegator();
        GenericValue userLogin = (GenericValue) context.get("userLogin");

        try {
            runIfExists(dispatcher, targetServiceName, UtilMisc.<String, Object>toMap("userLogin", userLogin));
        } catch (Exception e) {
            Debug.logError(e, "V2 worker target failed: " + targetServiceName, MODULE);
        }

        try {
            Timestamp nextRun = new Timestamp(System.currentTimeMillis() + intervalMs);
            ensureSingleScheduled(delegator, jobName, workerServiceName, nextRun, userLogin);
        } catch (Exception e) {
            Debug.logError(e, "V2 worker reschedule failed: " + jobName, MODULE);
            return ServiceUtil.returnError("V2 reschedule failed: " + e.getMessage());
        }

        return ServiceUtil.returnSuccess();
    }

    private static void runIfExists(LocalDispatcher dispatcher, String serviceName, Map<String, Object> ctx) throws Exception {
        if (!serviceExists(dispatcher, serviceName)) return;
        Map<String, Object> res = dispatcher.runSync(serviceName, ctx);
        if (ServiceUtil.isError(res)) {
            throw new Exception(serviceName + " error: " + ServiceUtil.getErrorMessage(res));
        }
    }

    private static Map<String, Object> runIfExistsReturn(LocalDispatcher dispatcher, String serviceName, Map<String, Object> ctx) throws Exception {
        if (!serviceExists(dispatcher, serviceName)) return null;
        Map<String, Object> res = dispatcher.runSync(serviceName, ctx);
        if (ServiceUtil.isError(res)) {
            throw new Exception(serviceName + " error: " + ServiceUtil.getErrorMessage(res));
        }
        return res;
    }

    private static boolean serviceExists(LocalDispatcher dispatcher, String serviceName) {
        try {
            DispatchContext dctx = dispatcher.getDispatchContext();
            ModelService ms = dctx.getModelService(serviceName);
            return ms != null;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Prevent duplicate pending jobs: (jobName + serviceName + status=PENDING).
     */
    private static void ensureSingleScheduled(Delegator delegator,
                                             String jobName,
                                             String serviceName,
                                             Timestamp nextRun,
                                             GenericValue userLogin) throws GenericEntityException {

        GenericValue existing = EntityQuery.use(delegator).from("JobSandbox")
                .where("jobName", jobName,
                        "serviceName", serviceName,
                        "statusId", "SERVICE_PENDING")
                .cache(false)
                .queryFirst();

        if (existing != null) return;

        GenericValue job = delegator.makeValue("JobSandbox");
        job.set("jobId", delegator.getNextSeqId("JobSandbox"));
        job.set("jobName", jobName);
        job.set("serviceName", serviceName);
        job.set("poolId", "pool");
        job.set("runAsUser", userLogin == null ? "system" : userLogin.getString("userLoginId"));
        job.set("runTime", nextRun.getTime());
        job.set("statusId", "SERVICE_PENDING");
        job.set("maxRetry", Long.valueOf(3));
        job.set("currentRetryCount", Long.valueOf(0));

        delegator.create(job);
    }

    private static Timestamp nextDailyTime(int hour) {
        Calendar c = Calendar.getInstance();
        c.setTime(UtilDateTime.nowTimestamp());

        c.set(Calendar.HOUR_OF_DAY, hour);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);

        if (c.getTimeInMillis() <= System.currentTimeMillis()) {
            c.add(Calendar.DAY_OF_MONTH, 1);
        }
        return new Timestamp(c.getTimeInMillis());
    }

    private static Timestamp nextMonthlyTime(int dayOfMonth, int hour) {
        Calendar c = Calendar.getInstance();
        c.setTime(UtilDateTime.nowTimestamp());

        c.set(Calendar.DAY_OF_MONTH, dayOfMonth);
        c.set(Calendar.HOUR_OF_DAY, hour);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);

        if (c.getTimeInMillis() <= System.currentTimeMillis()) {
            c.add(Calendar.MONTH, 1);
            c.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            c.set(Calendar.HOUR_OF_DAY, hour);
        }
        return new Timestamp(c.getTimeInMillis());
    }
}
