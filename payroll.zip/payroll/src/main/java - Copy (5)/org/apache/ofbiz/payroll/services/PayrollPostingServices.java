package org.apache.ofbiz.payroll.services;

import org.apache.ofbiz.base.util.Debug;
import org.apache.ofbiz.base.util.UtilDateTime;
import org.apache.ofbiz.base.util.UtilMisc;
import org.apache.ofbiz.base.util.UtilValidate;

import org.apache.ofbiz.entity.Delegator;
import org.apache.ofbiz.entity.GenericEntityException;
import org.apache.ofbiz.entity.GenericValue;

import org.apache.ofbiz.entity.condition.EntityCondition;
import org.apache.ofbiz.entity.condition.EntityOperator;
import org.apache.ofbiz.entity.transaction.TransactionUtil;
import org.apache.ofbiz.entity.util.EntityQuery;

import org.apache.ofbiz.service.DispatchContext;
import org.apache.ofbiz.service.LocalDispatcher;
import org.apache.ofbiz.service.ServiceUtil;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Timestamp;
import java.util.*;

/**
 * PayrollPostingServices (FINAL)
 *
 * CRITICAL FIX:
 * - Internal mapping uses DR/CR (as stored in PayrollGlMapping).
 * - OFBiz AcctgTransEntry uses debitCreditFlag D/C -> we convert DR->D and CR->C when writing.
 *
 * NOTE:
 * - AcctgTransEntry PK in your OFBiz model is (acctgTransId, acctgTransEntrySeqId).
 * - DO NOT set acctgTransEntryId (it does not exist in your model, per your runtime error).
 */
public class PayrollPostingServices {
    public static final String MODULE = PayrollPostingServices.class.getName();

    // PayrollRun statuses (adjust to your status ids)
    public static final String RUN_STATUS_APPROVED = "PAYRUN_APPROVED";
    public static final String RUN_STATUS_POSTED   = "PAYRUN_POSTED";

    // PayrollPosting.postingTypeId
    public static final String POST_TYPE_GL      = "POST_GL";
    public static final String POST_TYPE_INVOICE = "POST_INV";

    // PayrollPosting.postingStatusId
    public static final String POST_STS_NEW      = "POST_NEW";
    public static final String POST_STS_POSTED   = "POST_POSTED";
    public static final String POST_STS_ERROR    = "POST_ERROR";
    public static final String POST_STS_REVERSED = "POST_REVERSED"; // FIXED constant

    // PayrollRun.accountingPostOptionId (business selection)
    public static final String OPT_NONE    = "PAY_POST_NONE";
    public static final String OPT_GL      = "PAY_POST_GL";
    public static final String OPT_INVOICE = "PAY_POST_INVOICE";
    public static final String OPT_BOTH    = "PAY_POST_BOTH";

    // Accounting defaults (tune per your setup)
    private static final String DEFAULT_ACCTG_TRANS_TYPE = "MANUAL_ACCTG_TRANS";
    private static final String DEFAULT_INVOICE_TYPE     = "PURCHASE_INVOICE"; // AP invoice
    private static final String DEFAULT_CURRENCY_UOM      = "USD";

    // ----------------------------
    // Public router (workflow use)
    // ----------------------------
    public static Map<String, Object> postPayrollRunAccounting(DispatchContext dctx, Map<String, ?> context) {
        return postPayrollRun(dctx, context);
    }

  public static Map<String, Object> postPayrollRun(DispatchContext dctx, Map<String, ?> context) {
    Delegator delegator = dctx.getDelegator();

    String payrollRunId = (String) context.get("payrollRunId");
    if (UtilValidate.isEmpty(payrollRunId)) {
        return ServiceUtil.returnError("payrollRunId is required");
    }

    // IMPORTANT: vendorPartyId should be required ONLY when invoice posting is selected
    String vendorPartyId = (String) context.get("vendorPartyId");

    try {
        GenericValue run = mustGetRun(delegator, payrollRunId);

        // Resolve posting option (context overrides run; else default NONE)
        String option = (String) context.get("accountingPostOptionId");
        if (UtilValidate.isEmpty(option)) {
            option = run.getString("accountingPostOptionId");
        }
        if (UtilValidate.isEmpty(option)) {
            option = OPT_NONE;
        }

        Map<String, Object> out = ServiceUtil.returnSuccess();
        out.put("accountingPostOptionId", option);

        // No posting
        if (OPT_NONE.equals(option)) {
            return out;
        }

        // GL only: NO vendor required
        if (OPT_GL.equals(option)) {
            Map<String, Object> gl = postPayrollRunToGl(dctx, context);
            if (ServiceUtil.isError(gl)) return gl;
            out.putAll(gl);
            return out;
        }

        // INVOICE only: vendor required
        if (OPT_INVOICE.equals(option)) {
            if (UtilValidate.isEmpty(vendorPartyId)) {
                return ServiceUtil.returnError("vendorPartyId is required for invoice posting");
            }
            Map<String, Object> inv = postPayrollRunToInvoice(dctx, context);
            if (ServiceUtil.isError(inv)) return inv;
            out.putAll(inv);
            return out;
        }

        // BOTH: vendor required because invoice part is included
        if (OPT_BOTH.equals(option)) {
            if (UtilValidate.isEmpty(vendorPartyId)) {
                return ServiceUtil.returnError("vendorPartyId is required for invoice posting (OPT_BOTH)");
            }

            Map<String, Object> gl = postPayrollRunToGl(dctx, context);
            if (ServiceUtil.isError(gl)) return gl;

            Map<String, Object> inv = postPayrollRunToInvoice(dctx, context);
            if (ServiceUtil.isError(inv)) return inv;

            out.putAll(gl);
            out.putAll(inv);
            return out;
        }

        return ServiceUtil.returnError("Unsupported accountingPostOptionId=" + option);

    } catch (Exception e) {
        Debug.logError(e, "postPayrollRun failed", MODULE);
        return ServiceUtil.returnError("postPayrollRun failed: " + e.getMessage());
    }
}


    // =========================================================
    // Public: postPayrollRunToGl
    // =========================================================
    public static Map<String, Object> postPayrollRunToGl(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        LocalDispatcher dispatcher = dctx.getDispatcher();
        GenericValue userLogin = (GenericValue) context.get("userLogin");

        String payrollRunId = (String) context.get("payrollRunId");
        String organizationPartyId = firstOrg(context);
        String glFiscalTypeId = (String) context.get("glFiscalTypeId");
        String glJournalName = (String) context.get("glJournalName");
        Boolean forceRepost = (Boolean) context.get("forceRepost");

        if (UtilValidate.isEmpty(payrollRunId)) return ServiceUtil.returnError("payrollRunId is required");

        boolean beganTx = false;
        try {
            beganTx = TransactionUtil.begin();

            GenericValue run = mustGetRun(delegator, payrollRunId);
            if (UtilValidate.isEmpty(organizationPartyId)) organizationPartyId = run.getString("organizationPartyId");
            requireOrg(organizationPartyId);
            assertRunPostable(run);

            GenericValue posting = getOrCreatePosting(delegator, organizationPartyId, payrollRunId, POST_TYPE_GL);

            if (isPosted(posting) && !Boolean.TRUE.equals(forceRepost)) {
                TransactionUtil.commit(beganTx);
                Map<String, Object> ok = ServiceUtil.returnSuccess("Already posted to GL");
                ok.put("payrollPostingId", posting.getString("payrollPostingId"));
                ok.put("glJournalId", posting.getString("glJournalId"));
                return ok;
            }

            if (Boolean.TRUE.equals(forceRepost) && isPosted(posting)) {
                posting.set("postingStatusId", POST_STS_REVERSED);
                posting.store();
                audit(dispatcher, userLogin, organizationPartyId, "POST_GL_REPOST", "PayrollPosting",
                        posting.getString("payrollPostingId"), null, "forceRepost=true", null);

                posting = createPosting(delegator, organizationPartyId, payrollRunId, POST_TYPE_GL,
                        nextVersion(posting), POST_STS_NEW);
            }

            List<PayrollAmountLine> agg = aggregatePayrollLines(delegator, organizationPartyId, payrollRunId);
            if (agg.isEmpty()) {
                setPostingError(posting, "No payroll lines found to post (run=" + payrollRunId + ")");
                audit(dispatcher, userLogin, organizationPartyId, "POST_GL_ERR", "PayrollRun", payrollRunId,
                        null, "No lines", null);
                TransactionUtil.commit(beganTx);
                return ServiceUtil.returnError("No payroll lines found for run " + payrollRunId);
            }

            // Build lines using DR/CR from mapping
            List<GlPostingLine> glLines = buildGlLinesFromMapping(delegator, organizationPartyId, agg);

            // Validate balance using DR/CR
            assertBalanced(glLines);

            String acctgTransId = createAcctgTrans(delegator, organizationPartyId, payrollRunId, glFiscalTypeId, glJournalName, userLogin);

            // Write entries converting DR/CR -> D/C (FIXED)
            createAcctgTransEntries(delegator, acctgTransId, organizationPartyId, glLines, userLogin);

            writePostingLinesGl(delegator, posting, glLines);

            posting.set("postingStatusId", POST_STS_POSTED);
            posting.set("postedDate", UtilDateTime.nowTimestamp());
            posting.set("postedByUserLoginId", userLoginId(userLogin));
            posting.set("glJournalId", acctgTransId);
            posting.set("errorMessage", null);
            posting.store();

            mirrorRunAfterGl(delegator, run, acctgTransId, userLogin);
            maybeMarkRunPosted(delegator, run, userLogin);

            audit(dispatcher, userLogin, organizationPartyId, "POST_GL_OK", "PayrollRun", payrollRunId,
                    null, "acctgTransId=" + acctgTransId, null);

            TransactionUtil.commit(beganTx);

            Map<String, Object> out = ServiceUtil.returnSuccess();
            out.put("payrollPostingId", posting.getString("payrollPostingId"));
            out.put("glJournalId", acctgTransId);
            return out;

        } catch (Exception e) {
            rollbackQuiet(beganTx, e);
            Debug.logError(e, "postPayrollRunToGl failed", MODULE);
            return ServiceUtil.returnError("postPayrollRunToGl failed: " + e.getMessage());
        }
    }

    // =========================================================
    // Public: postPayrollRunToInvoice
    // =========================================================
    public static Map<String, Object> postPayrollRunToInvoice(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        LocalDispatcher dispatcher = dctx.getDispatcher();
        GenericValue userLogin = (GenericValue) context.get("userLogin");

        String payrollRunId = (String) context.get("payrollRunId");
        String organizationPartyId = firstOrg(context);
        String vendorPartyId = (String) context.get("vendorPartyId");
        String invoiceTypeId = (String) context.get("invoiceTypeId");
        Boolean forceRepost = (Boolean) context.get("forceRepost");

        if (UtilValidate.isEmpty(payrollRunId)) return ServiceUtil.returnError("payrollRunId is required");

        boolean beganTx = false;
        try {
            beganTx = TransactionUtil.begin();

            GenericValue run = mustGetRun(delegator, payrollRunId);
            if (UtilValidate.isEmpty(organizationPartyId)) organizationPartyId = run.getString("organizationPartyId");
            requireOrg(organizationPartyId);
            assertRunPostable(run);

            if (UtilValidate.isEmpty(invoiceTypeId)) invoiceTypeId = DEFAULT_INVOICE_TYPE;
            if (UtilValidate.isEmpty(vendorPartyId)) vendorPartyId = resolveOrgVendor(delegator, organizationPartyId);
            if (UtilValidate.isEmpty(vendorPartyId)) {
                return ServiceUtil.returnError("vendorPartyId is required (or configure vendor on PayrollOrganization)");
            }

            GenericValue posting = getOrCreatePosting(delegator, organizationPartyId, payrollRunId, POST_TYPE_INVOICE);

            if (isPosted(posting) && !Boolean.TRUE.equals(forceRepost)) {
                TransactionUtil.commit(beganTx);
                Map<String, Object> ok = ServiceUtil.returnSuccess("Already posted to Invoice");
                ok.put("payrollPostingId", posting.getString("payrollPostingId"));
                ok.put("invoiceId", posting.getString("invoiceId"));
                return ok;
            }

            if (Boolean.TRUE.equals(forceRepost) && isPosted(posting)) {
                posting.set("postingStatusId", POST_STS_REVERSED);
                posting.store();
                audit(dispatcher, userLogin, organizationPartyId, "POST_INV_REPOST", "PayrollPosting",
                        posting.getString("payrollPostingId"), null, "forceRepost=true", null);

                posting = createPosting(delegator, organizationPartyId, payrollRunId, POST_TYPE_INVOICE,
                        nextVersion(posting), POST_STS_NEW);
            }

            List<PayrollAmountLine> agg = aggregatePayrollLines(delegator, organizationPartyId, payrollRunId);
            if (agg.isEmpty()) {
                setPostingError(posting, "No payroll lines found to post (run=" + payrollRunId + ")");
                audit(dispatcher, userLogin, organizationPartyId, "POST_INV_ERR", "PayrollRun", payrollRunId,
                        null, "No lines", null);
                TransactionUtil.commit(beganTx);
                return ServiceUtil.returnError("No payroll lines found for run " + payrollRunId);
            }

            List<InvoicePostingLine> invLines = buildInvoiceLinesFromMapping(delegator, organizationPartyId, agg);
            if (invLines.isEmpty()) {
                setPostingError(posting, "All invoice lines resolved to zero; nothing to post.");
                TransactionUtil.commit(beganTx);
                return ServiceUtil.returnError("No invoice lines to post (all zero)");
            }

            String invoiceId = createInvoice(delegator, organizationPartyId, vendorPartyId, invoiceTypeId, run, userLogin);
            createInvoiceItems(delegator, invoiceId, invLines, run, userLogin);

            writePostingLinesInvoice(delegator, posting, invLines);

            posting.set("postingStatusId", POST_STS_POSTED);
            posting.set("postedDate", UtilDateTime.nowTimestamp());
            posting.set("postedByUserLoginId", userLoginId(userLogin));
            posting.set("invoiceId", invoiceId);
            posting.set("errorMessage", null);
            posting.store();

            mirrorRunAfterInvoice(delegator, run, invoiceId, userLogin);
            maybeMarkRunPosted(delegator, run, userLogin);

            audit(dispatcher, userLogin, organizationPartyId, "POST_INV_OK", "PayrollRun", payrollRunId,
                    null, "invoiceId=" + invoiceId, null);

            TransactionUtil.commit(beganTx);

            Map<String, Object> out = ServiceUtil.returnSuccess();
            out.put("payrollPostingId", posting.getString("payrollPostingId"));
            out.put("invoiceId", invoiceId);
            return out;

        } catch (Exception e) {
            rollbackQuiet(beganTx, e);
            Debug.logError(e, "postPayrollRunToInvoice failed", MODULE);
            return ServiceUtil.returnError("postPayrollRunToInvoice failed: " + e.getMessage());
        }
    }

    // =========================================================
    // Helpers: Org + Run checks
    // =========================================================
    private static String firstOrg(Map<String, ?> context) {
        String organizationPartyId = (String) context.get("organizationPartyId");
        if (UtilValidate.isEmpty(organizationPartyId)) organizationPartyId = (String) context.get("orgPartyId");
        return organizationPartyId;
    }

    private static void requireOrg(String organizationPartyId) {
        if (UtilValidate.isEmpty(organizationPartyId)) throw new IllegalArgumentException("organizationPartyId is required");
    }

    private static GenericValue mustGetRun(Delegator delegator, String payrollRunId) throws GenericEntityException {
        GenericValue run = EntityQuery.use(delegator).from("PayrollRun").where("payrollRunId", payrollRunId).queryOne();
        if (run == null) throw new IllegalArgumentException("PayrollRun not found: " + payrollRunId);
        return run;
    }

  

    private static void maybeMarkRunPosted(Delegator delegator, GenericValue run, GenericValue userLogin) throws GenericEntityException {
        if (RUN_STATUS_POSTED.equals(run.getString("statusId"))) return;

        run.set("statusId", RUN_STATUS_POSTED);
        if (hasField(delegator, "PayrollRun", "postedDate")) run.set("postedDate", UtilDateTime.nowTimestamp());
        if (hasField(delegator, "PayrollRun", "postedByUserLoginId") && userLogin != null) {
            run.set("postedByUserLoginId", userLogin.getString("userLoginId"));
        }
        run.store();
    }

    private static void mirrorRunAfterGl(Delegator delegator, GenericValue run, String acctgTransId, GenericValue userLogin) throws GenericEntityException {
        if (hasField(delegator, "PayrollRun", "glJournalId")) run.set("glJournalId", acctgTransId);
        if (hasField(delegator, "PayrollRun", "isGlPosted")) run.set("isGlPosted", "Y");
        if (hasField(delegator, "PayrollRun", "glPostedDate")) run.set("glPostedDate", UtilDateTime.nowTimestamp());
        run.store();
    }

    private static void mirrorRunAfterInvoice(Delegator delegator, GenericValue run, String invoiceId, GenericValue userLogin) throws GenericEntityException {
        if (hasField(delegator, "PayrollRun", "invoiceId")) run.set("invoiceId", invoiceId);
        if (hasField(delegator, "PayrollRun", "isInvoicePosted")) run.set("isInvoicePosted", "Y");
        if (hasField(delegator, "PayrollRun", "invoicePostedDate")) run.set("invoicePostedDate", UtilDateTime.nowTimestamp());
        run.store();
    }

    private static String userLoginId(GenericValue userLogin) {
        return userLogin == null ? null : userLogin.getString("userLoginId");
    }

    private static boolean hasField(Delegator delegator, String entityName, String fieldName) {
        try {
            return delegator.getModelEntity(entityName).isField(fieldName);
        } catch (Exception e) {
            return false;
        }
    }

    // =========================================================
    // Idempotency: PayrollPosting
    // =========================================================
    private static GenericValue getOrCreatePosting(Delegator delegator, String organizationPartyId, String payrollRunId, String postingTypeId)
            throws GenericEntityException {

        EntityCondition cond = EntityCondition.makeCondition(UtilMisc.toList(
                EntityCondition.makeCondition("organizationPartyId", EntityOperator.EQUALS, organizationPartyId),
                EntityCondition.makeCondition("payrollRunId", EntityOperator.EQUALS, payrollRunId),
                EntityCondition.makeCondition("postingTypeId", EntityOperator.EQUALS, postingTypeId)
        ), EntityOperator.AND);

        GenericValue posting = EntityQuery.use(delegator).from("PayrollPosting").where(cond).orderBy("-postingVersion").queryFirst();
        if (posting == null) {
            posting = createPosting(delegator, organizationPartyId, payrollRunId, postingTypeId, 1L, POST_STS_NEW);
        }
        return posting;
    }

    private static GenericValue createPosting(Delegator delegator, String organizationPartyId, String payrollRunId,
                                             String postingTypeId, Long version, String statusId) throws GenericEntityException {
        GenericValue p = delegator.makeValue("PayrollPosting");
        p.set("payrollPostingId", delegator.getNextSeqId("PayrollPosting"));
        p.set("organizationPartyId", organizationPartyId);
        p.set("payrollRunId", payrollRunId);
        p.set("postingTypeId", postingTypeId);
        p.set("postingStatusId", statusId);
        p.set("postingVersion", version == null ? 1L : version);
        delegator.create(p);
        return p;
    }

    private static Long nextVersion(GenericValue posting) {
        try {
            Long v = posting.getLong("postingVersion");
            if (v == null) v = 1L;
            return v + 1;
        } catch (Exception e) {
            return 2L;
        }
    }

    private static boolean isPosted(GenericValue posting) {
        return posting != null && POST_STS_POSTED.equals(posting.getString("postingStatusId"));
    }

    private static void setPostingError(GenericValue posting, String msg) throws GenericEntityException {
        posting.set("postingStatusId", POST_STS_ERROR);
        posting.set("errorMessage", truncate(msg, 2000));
        posting.store();
    }

    // =========================================================
    // Aggregate payroll lines
    // =========================================================
    private static List<PayrollAmountLine> aggregatePayrollLines(Delegator delegator, String organizationPartyId, String payrollRunId)
            throws GenericEntityException {

        List<GenericValue> results = EntityQuery.use(delegator).from("EmployeePayrollResult")
                .where("organizationPartyId", organizationPartyId, "payrollRunId", payrollRunId)
                .queryList();

        Map<String, BigDecimal> sumByLineType = new LinkedHashMap<>();
        String currencyUomId = null;

        for (GenericValue r : results) {
            if (currencyUomId == null && hasField(delegator, "EmployeePayrollResult", "currencyUomId")) {
                currencyUomId = r.getString("currencyUomId");
            }
            String payrollResultId = r.getString("payrollResultId");

            List<GenericValue> lines = EntityQuery.use(delegator).from("EmployeePayrollResultLine")
                    .where("payrollResultId", payrollResultId)
                    .queryList();

            for (GenericValue l : lines) {
                String lineTypeId = l.getString("lineTypeId");
                BigDecimal amt = nvl(l.getBigDecimal("amount"));
                sumByLineType.put(lineTypeId, nvl(sumByLineType.get(lineTypeId)).add(amt));

                if (currencyUomId == null && hasField(delegator, "EmployeePayrollResultLine", "currencyUomId")) {
                    currencyUomId = l.getString("currencyUomId");
                }
            }
        }

        if (UtilValidate.isEmpty(currencyUomId)) currencyUomId = DEFAULT_CURRENCY_UOM;

        List<PayrollAmountLine> out = new ArrayList<>();
        for (Map.Entry<String, BigDecimal> e : sumByLineType.entrySet()) {
            if (e.getValue() == null) continue;
            if (e.getValue().compareTo(BigDecimal.ZERO) == 0) continue;
            out.add(new PayrollAmountLine(e.getKey(), e.getValue().setScale(2, RoundingMode.HALF_UP), currencyUomId));
        }
        return out;
    }

    // =========================================================
    // Mapping (GL/Invoice) with global fallback
    // =========================================================
    private static List<GlPostingLine> buildGlLinesFromMapping(
            Delegator delegator,
            String organizationPartyId,
            List<PayrollAmountLine> aggLines
    ) throws GenericEntityException {

        List<GlPostingLine> glLines = new ArrayList<>();
        Timestamp now = UtilDateTime.nowTimestamp();

        for (PayrollAmountLine pl : aggLines) {
            List<GenericValue> maps = findGlMappingsForLineType(delegator, organizationPartyId, pl.lineTypeId, now);
            if (maps == null || maps.isEmpty()) {
                throw new IllegalArgumentException("Missing PayrollGlMapping for lineTypeId=" + pl.lineTypeId +
                        " (org=" + organizationPartyId + " or global)");
            }

            BigDecimal amt = pl.amount.abs().setScale(2, RoundingMode.HALF_UP);
            if (amt.signum() == 0) continue;

            boolean hasDr = false;
            boolean hasCr = false;

            for (GenericValue map : maps) {
                String glAccountId = map.getString("glAccountId");
                String drCrFlag = map.getString("drCrFlag"); // DR/CR

                if (UtilValidate.isEmpty(glAccountId) || UtilValidate.isEmpty(drCrFlag)) {
                    throw new IllegalArgumentException("Invalid PayrollGlMapping for lineTypeId=" + pl.lineTypeId);
                }

                String dc = drCrFlag.trim().toUpperCase(Locale.ROOT);
                if (!"DR".equals(dc) && !"CR".equals(dc)) {
                    throw new IllegalArgumentException("Invalid DR_CR_FLAG=" + drCrFlag);
                }

                if ("DR".equals(dc)) hasDr = true;
                if ("CR".equals(dc)) hasCr = true;

                glLines.add(new GlPostingLine(glAccountId, dc, amt, pl.currencyUomId, pl.lineTypeId)); // DR/CR
            }

            if (!hasDr || !hasCr) {
                throw new IllegalArgumentException("Incomplete GL mapping for lineTypeId=" + pl.lineTypeId +
                        " (need both DR and CR). Found DR=" + hasDr + " CR=" + hasCr);
            }
        }

        return glLines;
    }

    private static List<GenericValue> findGlMappingsForLineType(
            Delegator delegator,
            String organizationPartyId,
            String lineTypeId,
            Timestamp now
    ) throws GenericEntityException {

        List<GenericValue> orgMaps = EntityQuery.use(delegator)
                .from("PayrollGlMapping")
                .where("organizationPartyId", organizationPartyId,
                        "lineTypeId", lineTypeId,
                        "isActive", "Y")
                .filterByDate(now, "fromDate", "thruDate")
                .orderBy("drCrFlag")
                .cache(false)
                .queryList();

        if (orgMaps != null && !orgMaps.isEmpty()) return orgMaps;

        return EntityQuery.use(delegator)
                .from("PayrollGlMapping")
                .where("organizationPartyId", null,
                        "lineTypeId", lineTypeId,
                        "isActive", "Y")
                .filterByDate(now, "fromDate", "thruDate")
                .orderBy("drCrFlag")
                .cache(false)
                .queryList();
    }

    private static List<InvoicePostingLine> buildInvoiceLinesFromMapping(Delegator delegator, String organizationPartyId, List<PayrollAmountLine> aggLines)
            throws GenericEntityException {

        List<InvoicePostingLine> inv = new ArrayList<>();

        for (PayrollAmountLine pl : aggLines) {
            GenericValue map = findInvoiceMapping(delegator, organizationPartyId, pl.lineTypeId);
            if (map == null) {
                throw new IllegalArgumentException("Missing PayrollInvoiceMapping for lineTypeId=" + pl.lineTypeId +
                        " (org=" + organizationPartyId + " or global)");
            }

            String invoiceItemTypeId = map.getString("invoiceItemTypeId");
            if (UtilValidate.isEmpty(invoiceItemTypeId)) {
                throw new IllegalArgumentException("Invalid PayrollInvoiceMapping for lineTypeId=" + pl.lineTypeId);
            }

            BigDecimal amt = pl.amount.abs().setScale(2, RoundingMode.HALF_UP);
            if (amt.compareTo(BigDecimal.ZERO) == 0) continue;

            inv.add(new InvoicePostingLine(invoiceItemTypeId, amt, pl.currencyUomId, pl.lineTypeId));
        }
        return inv;
    }

    private static GenericValue findInvoiceMapping(Delegator delegator, String organizationPartyId, String lineTypeId) throws GenericEntityException {
        EntityCondition base = EntityCondition.makeCondition(UtilMisc.toList(
                EntityCondition.makeCondition("lineTypeId", EntityOperator.EQUALS, lineTypeId),
                EntityCondition.makeCondition("isActive", EntityOperator.EQUALS, "Y")
        ), EntityOperator.AND);

        EntityCondition orgCond = EntityCondition.makeCondition("organizationPartyId", EntityOperator.EQUALS, organizationPartyId);
        EntityCondition globalCond = EntityCondition.makeCondition("organizationPartyId", EntityOperator.EQUALS, null);

        EntityCondition where = EntityCondition.makeCondition(UtilMisc.toList(
                base,
                EntityCondition.makeCondition(UtilMisc.toList(orgCond, globalCond), EntityOperator.OR)
        ), EntityOperator.AND);

        List<GenericValue> list = EntityQuery.use(delegator).from("PayrollInvoiceMapping")
                .where(where)
                .orderBy("-organizationPartyId", "-fromDate")
                .queryList();

        return list == null || list.isEmpty() ? null : list.get(0);
    }

    // =========================================================
    // GL posting helpers (DR/CR)
    // =========================================================
    private static void assertBalanced(List<GlPostingLine> glLines) {
        BigDecimal dr = BigDecimal.ZERO;
        BigDecimal cr = BigDecimal.ZERO;

        for (GlPostingLine l : glLines) {
            String dc = l.drCrFlag == null ? "" : l.drCrFlag.trim().toUpperCase(Locale.ROOT);
            if ("DR".equals(dc)) dr = dr.add(l.amount);
            else if ("CR".equals(dc)) cr = cr.add(l.amount);
            else throw new IllegalArgumentException("Invalid drCrFlag: " + l.drCrFlag + " (expected DR/CR)");
        }

        if (dr.setScale(2, RoundingMode.HALF_UP).compareTo(cr.setScale(2, RoundingMode.HALF_UP)) != 0) {
            throw new IllegalArgumentException("GL journal not balanced. DR=" + dr + " CR=" + cr + ". Fix mappings.");
        }
    }

    private static String toDebitCreditFlag(String drCr) {
        String s = drCr == null ? "" : drCr.trim().toUpperCase(Locale.ROOT);
        if ("DR".equals(s)) return "D";
        if ("CR".equals(s)) return "C";
        if ("D".equals(s) || "C".equals(s)) return s;
        throw new IllegalArgumentException("Invalid drCrFlag=" + drCr + " (expected DR/CR)");
    }

    private static String createAcctgTrans(Delegator delegator,
                                          String organizationPartyId,
                                          String payrollRunId,
                                          String glFiscalTypeId,
                                          String glJournalName,
                                          GenericValue userLogin) throws GenericEntityException {

        String acctgTransId = delegator.getNextSeqId("AcctgTrans");
        GenericValue at = delegator.makeValue("AcctgTrans");
        at.set("acctgTransId", acctgTransId);
        at.set("acctgTransTypeId", DEFAULT_ACCTG_TRANS_TYPE);

        Timestamp now = UtilDateTime.nowTimestamp();
        if (hasField(delegator, "AcctgTrans", "transactionDate")) at.set("transactionDate", now);
        if (hasField(delegator, "AcctgTrans", "entryDate")) at.set("entryDate", now);

        if (hasField(delegator, "AcctgTrans", "description")) {
            at.set("description", "Payroll Run Posting: " + payrollRunId);
        }

        if (UtilValidate.isNotEmpty(glFiscalTypeId) && hasField(delegator, "AcctgTrans", "glFiscalTypeId")) {
            at.set("glFiscalTypeId", glFiscalTypeId);
        }
        if (UtilValidate.isNotEmpty(glJournalName) && hasField(delegator, "AcctgTrans", "glJournalName")) {
            at.set("glJournalName", glJournalName);
        }

        if (hasField(delegator, "AcctgTrans", "partyId")) {
            at.set("partyId", organizationPartyId);
        }

        if (userLogin != null && hasField(delegator, "AcctgTrans", "createdByUserLogin")) {
            at.set("createdByUserLogin", userLogin.getString("userLoginId"));
        }

        delegator.create(at);
        return acctgTransId;
    }

    /**
     * FIXED:
     * - DO NOT set acctgTransEntryId (not a field in your model)
     * - Use (acctgTransId, acctgTransEntrySeqId) as PK
     * - Convert DR/CR -> D/C for debitCreditFlag
     */
    private static void createAcctgTransEntries(
            Delegator delegator,
            String acctgTransId,
            String organizationPartyId,
            List<GlPostingLine> lines,
            GenericValue userLogin
    ) throws GenericEntityException {

        long seq = 1;
        for (GlPostingLine l : lines) {
            GenericValue e = delegator.makeValue("AcctgTransEntry");

            e.set("acctgTransId", acctgTransId);
            e.set("acctgTransEntrySeqId", String.format("%05d", seq++));

            e.set("glAccountId", l.glAccountId);

            if (UtilValidate.isNotEmpty(organizationPartyId) && hasField(delegator, "AcctgTransEntry", "organizationPartyId")) {
                e.set("organizationPartyId", organizationPartyId);
            }

            String dc = toDebitCreditFlag(l.drCrFlag); // D or C
            e.set("debitCreditFlag", dc);

            // In your field list, "amount" exists (use it only)
            e.set("amount", l.amount);

            if (hasField(delegator, "AcctgTransEntry", "currencyUomId")) {
                e.set("currencyUomId", l.currencyUomId);
            }

            if (hasField(delegator, "AcctgTransEntry", "description")) {
                e.set("description", "Payroll " + l.lineTypeId);
            }

            // IMPORTANT: do NOT set createdByUserLogin unless your AcctgTransEntry model has it.
            // Your field dump did not show it, so we skip it to avoid next runtime error.

            delegator.create(e);
        }
    }

    private static void writePostingLinesGl(Delegator delegator, GenericValue posting, List<GlPostingLine> glLines) throws GenericEntityException {
        for (GlPostingLine l : glLines) {
            GenericValue pl = delegator.makeValue("PayrollPostingLine");
            pl.set("payrollPostingLineId", delegator.getNextSeqId("PayrollPostingLine"));
            pl.set("payrollPostingId", posting.getString("payrollPostingId"));
            pl.set("lineTypeId", l.lineTypeId);
            pl.set("amount", l.amount);
            if (hasField(delegator, "PayrollPostingLine", "currencyUomId")) pl.set("currencyUomId", l.currencyUomId);
            pl.set("glAccountId", l.glAccountId);
            pl.set("drCrFlag", l.drCrFlag); // DR/CR for traceability
            delegator.create(pl);
        }
    }

    // =========================================================
    // Invoice posting helpers
    // =========================================================
    private static String createInvoice(Delegator delegator,
                                        String organizationPartyId,
                                        String vendorPartyId,
                                        String invoiceTypeId,
                                        GenericValue run,
                                        GenericValue userLogin) throws GenericEntityException {

        String invoiceId = delegator.getNextSeqId("Invoice");
        GenericValue inv = delegator.makeValue("Invoice");
        inv.set("invoiceId", invoiceId);

        inv.set("invoiceTypeId", invoiceTypeId);
        if (hasField(delegator, "Invoice", "invoiceDate")) inv.set("invoiceDate", UtilDateTime.nowTimestamp());

        if (hasField(delegator, "Invoice", "partyIdFrom")) inv.set("partyIdFrom", vendorPartyId);
        if (hasField(delegator, "Invoice", "partyId")) inv.set("partyId", organizationPartyId);

        if (hasField(delegator, "Invoice", "description")) {
            inv.set("description", "Payroll Run " + run.getString("payrollRunId"));
        }

        String currencyUomId = hasField(delegator, "PayrollRun", "currencyUomId") ? run.getString("currencyUomId") : null;
        if (UtilValidate.isEmpty(currencyUomId)) currencyUomId = DEFAULT_CURRENCY_UOM;
        if (hasField(delegator, "Invoice", "currencyUomId")) inv.set("currencyUomId", currencyUomId);

        if (userLogin != null && hasField(delegator, "Invoice", "createdByUserLogin")) {
            inv.set("createdByUserLogin", userLogin.getString("userLoginId"));
        }

        delegator.create(inv);
        return invoiceId;
    }

    private static void createInvoiceItems(Delegator delegator,
                                          String invoiceId,
                                          List<InvoicePostingLine> lines,
                                          GenericValue run,
                                          GenericValue userLogin) throws GenericEntityException {

        String currencyUomId = hasField(delegator, "PayrollRun", "currencyUomId") ? run.getString("currencyUomId") : null;
        if (UtilValidate.isEmpty(currencyUomId)) currencyUomId = DEFAULT_CURRENCY_UOM;

        long seq = 1;
        for (InvoicePostingLine l : lines) {
            String itemSeqId = String.format("%05d", seq++);

            GenericValue ii = delegator.makeValue("InvoiceItem");
            ii.set("invoiceId", invoiceId);
            ii.set("invoiceItemSeqId", itemSeqId);
            ii.set("invoiceItemTypeId", l.invoiceItemTypeId);

            if (hasField(delegator, "InvoiceItem", "quantity")) ii.set("quantity", BigDecimal.ONE);
            if (hasField(delegator, "InvoiceItem", "amount")) ii.set("amount", l.amount);
            if (hasField(delegator, "InvoiceItem", "currencyUomId")) ii.set("currencyUomId", currencyUomId);

            if (hasField(delegator, "InvoiceItem", "description")) {
                ii.set("description", "Payroll " + l.lineTypeId);
            }

            if (userLogin != null && hasField(delegator, "InvoiceItem", "createdByUserLogin")) {
                ii.set("createdByUserLogin", userLogin.getString("userLoginId"));
            }

            delegator.create(ii);
        }
    }

    private static void writePostingLinesInvoice(Delegator delegator, GenericValue posting, List<InvoicePostingLine> invLines) throws GenericEntityException {
        for (InvoicePostingLine l : invLines) {
            GenericValue pl = delegator.makeValue("PayrollPostingLine");
            pl.set("payrollPostingLineId", delegator.getNextSeqId("PayrollPostingLine"));
            pl.set("payrollPostingId", posting.getString("payrollPostingId"));
            pl.set("lineTypeId", l.lineTypeId);
            pl.set("amount", l.amount);
            if (hasField(delegator, "PayrollPostingLine", "currencyUomId")) pl.set("currencyUomId", l.currencyUomId);
            pl.set("invoiceItemTypeId", l.invoiceItemTypeId);
            delegator.create(pl);
        }
    }

    private static String resolveOrgVendor(Delegator delegator, String organizationPartyId) {
        try {
            GenericValue org = EntityQuery.use(delegator).from("PayrollOrganization")
                    .where("organizationPartyId", organizationPartyId)
                    .queryFirst();
            if (org == null) return null;
            if (org.getModelEntity().isField("payrollVendorPartyId")) return org.getString("payrollVendorPartyId");
            if (org.getModelEntity().isField("vendorPartyId")) return org.getString("vendorPartyId");
            return null;
        } catch (Exception e) {
            return null;
        }
    }

    // =========================================================
    // Audit (non-blocking)
    // =========================================================
    private static void audit(LocalDispatcher dispatcher, GenericValue userLogin, String organizationPartyId,
                              String eventTypeId, String entityName, String recordId,
                              String oldValue, String newValue, String sourceIp) {
        try {
            Map<String, Object> ctx = UtilMisc.toMap(
                    "organizationPartyId", organizationPartyId,
                    "eventTypeId", eventTypeId,
                    "entityName", entityName,
                    "recordId", recordId,
                    "oldValue", oldValue,
                    "newValue", newValue,
                    "sourceIp", sourceIp,
                    "userLogin", userLogin
            );
            dispatcher.runSync("recordPayrollAuditEvent", ctx);
        } catch (Exception ignored) {
        }
    }

    // =========================================================
    // Utility
    // =========================================================
    private static void rollbackQuiet(boolean beganTx, Exception e) {
        try {
            if (beganTx) TransactionUtil.rollback(beganTx, e.getMessage(), e);
        } catch (Exception ignored) {}
    }

    private static BigDecimal nvl(BigDecimal v) {
        return v == null ? BigDecimal.ZERO : v;
    }

    private static void assertRunPostable(GenericValue run) {
        String st = run.getString("statusId");
        if (!RUN_STATUS_APPROVED.equals(st) && !RUN_STATUS_POSTED.equals(st)) {
            throw new IllegalArgumentException("PayrollRun must be APPROVED before posting. Current status=" + st);
        }
    }

    // =========================================================
    // MISSING METHODS (added to make the file COMPLETE/COMPILABLE)
    // =========================================================

   // private static void setPostingError(GenericValue posting, String msg) throws GenericEntityException {
  ///      posting.set("postingStatusId", POST_STS_ERROR);
  //      if (hasField(posting.getDelegator(), "PayrollPosting", "errorMessage")) {
 //           posting.set("errorMessage", truncate(msg, 2000));
  //      }
  //      posting.store();
  //  }

    private static String truncate(String s, int max) {
        if (s == null) return null;
        if (max <= 0) return "";
        return (s.length() <= max) ? s : s.substring(0, max);
    }

    // Data structures
    private static final class PayrollAmountLine {
        final String lineTypeId;
        final BigDecimal amount;
        final String currencyUomId;
        PayrollAmountLine(String lineTypeId, BigDecimal amount, String currencyUomId) {
            this.lineTypeId = lineTypeId;
            this.amount = amount;
            this.currencyUomId = currencyUomId;
        }
    }

    private static final class GlPostingLine {
        final String glAccountId;
        final String drCrFlag; // DR/CR
        final BigDecimal amount;
        final String currencyUomId;
        final String lineTypeId;
        GlPostingLine(String glAccountId, String drCrFlag, BigDecimal amount, String currencyUomId, String lineTypeId) {
            this.glAccountId = glAccountId;
            this.drCrFlag = drCrFlag;
            this.amount = amount;
            this.currencyUomId = currencyUomId;
            this.lineTypeId = lineTypeId;
        }
    }

    private static final class InvoicePostingLine {
        final String invoiceItemTypeId;
        final BigDecimal amount;
        final String currencyUomId;
        final String lineTypeId;
        InvoicePostingLine(String invoiceItemTypeId, BigDecimal amount, String currencyUomId, String lineTypeId) {
            this.invoiceItemTypeId = invoiceItemTypeId;
            this.amount = amount;
            this.currencyUomId = currencyUomId;
            this.lineTypeId = lineTypeId;
        }
    }
}
