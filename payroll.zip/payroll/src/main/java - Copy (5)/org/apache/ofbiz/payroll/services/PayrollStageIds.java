// File: plugins/payroll/src/main/java/org/apache/ofbiz/payroll/services/PayrollStageIds.java
package org.apache.ofbiz.payroll.services;

/**
 * Stage + status constants used by PayrollSchedulerServicesV2 and response builder.
 * Keep IDs stable (API contract).
 */
public final class PayrollStageIds {

    private PayrollStageIds() {}

    // =========================================================
    // Stage IDs (pipeline)
    // =========================================================
    public static final String STAGE_RESOLVE    = "RESOLVE";      // optional pre-stage (resolve run/period)
    public static final String STAGE_VALIDATE   = "VALIDATE";
    public static final String STAGE_CALCULATE  = "CALCULATE";
    public static final String STAGE_PROCESS    = "PROCESS";      // optional: if you separate calculate vs persist
    public static final String STAGE_POST_GL    = "POST_GL";
    public static final String STAGE_POST_INV   = "POST_INV";
    public static final String STAGE_BANK       = "BANK";
    public static final String STAGE_EXPORT     = "EXPORT";
    public static final String STAGE_CLOSE      = "CLOSE";        // optional: close run/period

    // =========================================================
    // Aliases expected by PayrollSchedulerServicesV2
    // (your compile errors reference PayrollStageIds.VALIDATE, etc.)
    // =========================================================
    public static final String RESOLVE   = STAGE_RESOLVE;
    public static final String VALIDATE  = STAGE_VALIDATE;
    public static final String CALCULATE = STAGE_CALCULATE;
    public static final String PROCESS   = STAGE_PROCESS;
    public static final String POST_GL   = STAGE_POST_GL;
    public static final String POST_INV  = STAGE_POST_INV;
    public static final String BANK      = STAGE_BANK;
    public static final String EXPORT    = STAGE_EXPORT;
    public static final String CLOSE     = STAGE_CLOSE;

    // =========================================================
    // Stage status IDs
    // =========================================================
    public static final String STG_OK   = "STG_OK";
    public static final String STG_WARN = "STG_WARN";
    public static final String STG_ERR  = "STG_ERR";
    public static final String STG_SKIP = "STG_SKIP"; // explicitly skipped by mode

    // =========================================================
    // Message severity IDs (align with PayrollRunResponseBuilder)
    // =========================================================
    public static final String MSG_INFO = "INFO";
    public static final String MSG_WARN = "WARN";
    public static final String MSG_ERR  = "ERROR";

    // =========================================================
    // Posting mode labels (REST)
    // =========================================================
    public static final String MODE_NONE = "NONE";
    public static final String MODE_GL   = "GL";
    public static final String MODE_INV  = "INVOICE";
    public static final String MODE_BANK = "BANK";

    // =========================================================
    // Common input flags
    // =========================================================
    public static final String YES = "Y";
    public static final String NO  = "N";

    // =========================================================
    // PayrollPeriod statusIds (used by resolver/validation)
    // =========================================================
    /** Your POC open period status. */
    public static final String PER_STATUS_OPEN   = "WT_PER_OPEN";

    /** Observed in your data: P_ACT for active period. Keep for convenience. */
    public static final String PER_STATUS_ACTIVE = "P_ACT";

    /** Provide a default closed value (adjust if your project uses a different ID). */
    public static final String PER_STATUS_CLOSED = "WT_PER_CLOSED";
}
