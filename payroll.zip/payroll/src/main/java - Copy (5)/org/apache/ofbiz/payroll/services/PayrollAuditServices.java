package org.apache.ofbiz.payroll.services;

import org.apache.ofbiz.base.util.Debug;
import org.apache.ofbiz.base.util.UtilDateTime;
import org.apache.ofbiz.base.util.UtilValidate;

import org.apache.ofbiz.entity.Delegator;
import org.apache.ofbiz.entity.GenericValue;

import org.apache.ofbiz.service.DispatchContext;
import org.apache.ofbiz.service.ServiceUtil;

import java.util.Map;

public class PayrollAuditServices {
    public static final String MODULE = PayrollAuditServices.class.getName();

    /**
     * Service entrypoint used by services.xml:
     * recordPayrollAuditEvent(DispatchContext, Map)
     *
     * This MUST exist with this exact signature, otherwise OFBiz throws NoSuchMethodException.
     * Non-fatal: audit should never rollback payroll processing.
     */
    public static Map<String, Object> recordPayrollAuditEvent(DispatchContext dctx, Map<String, ? extends Object> context) {
        try {
            Delegator delegator = dctx.getDelegator();

            // ---- Accept multiple possible field names (for compatibility) ----
            String organizationPartyId =
                    firstNonEmpty((String) context.get("organizationPartyId"),
                                  (String) context.get("orgPartyId"),
                                  (String) context.get("orgId"));

            String eventTypeId =
                    firstNonEmpty((String) context.get("eventTypeId"),
                                  (String) context.get("auditEventTypeId"),
                                  (String) context.get("actionTypeId"));

            String entityName =
                    firstNonEmpty((String) context.get("entityName"),
                                  (String) context.get("targetEntityName"));

            String recordId =
                    firstNonEmpty((String) context.get("recordId"),
                                  (String) context.get("targetRecordId"),
                                  (String) context.get("primaryKey"),
                                  (String) context.get("pk"));

            String oldValue =
                    firstNonEmpty((String) context.get("oldValue"),
                                  (String) context.get("oldValuesJson"),
                                  (String) context.get("oldValues"));

            String newValue =
                    firstNonEmpty((String) context.get("newValue"),
                                  (String) context.get("newValuesJson"),
                                  (String) context.get("newValues"));

            String sourceIp =
                    firstNonEmpty((String) context.get("sourceIp"),
                                  (String) context.get("ipAddress"),
                                  (String) context.get("clientIp"));

            GenericValue userLogin = (GenericValue) context.get("userLogin");

            // If caller didn't provide some fields, keep audit tolerant
            if (UtilValidate.isEmpty(eventTypeId)) eventTypeId = "INFO";
            if (UtilValidate.isEmpty(entityName)) entityName = "Payroll";
            if (UtilValidate.isEmpty(recordId)) recordId = "N/A";

            // Reuse your helper so logic stays centralized
            logEvent(delegator,
                    organizationPartyId,
                    eventTypeId,
                    entityName,
                    recordId,
                    oldValue,
                    newValue,
                    userLogin,
                    sourceIp);

            return ServiceUtil.returnSuccess();
        } catch (Exception e) {
            // IMPORTANT: never fail payroll because audit failed
            Debug.logWarning(e, "recordPayrollAuditEvent failed (non-fatal)", MODULE);
            return ServiceUtil.returnSuccess();
        }
    }

    /**
     * Writes PayrollAuditEvent (preferred) if exists, else PayrollAuditLog if exists.
     * Non-fatal by design.
     */
    public static void logEvent(
            Delegator delegator,
            String organizationPartyId,
            String eventTypeId,
            String entityName,
            String recordId,
            String oldValue,
            String newValue,
            GenericValue userLogin,
            String sourceIp
    ) {
        try {
            // If org is not provided, keep it null - don't explode
            String userLoginId = (userLogin == null) ? null : userLogin.getString("userLoginId");

            if (delegator.getModelEntity("PayrollAuditEvent") != null) {
                GenericValue ev = delegator.makeValue("PayrollAuditEvent");
                // Your field name is payrollAuditEventId (keep as-is)
                ev.set("payrollAuditEventId", delegator.getNextSeqId("PayrollAuditEvent"));
                ev.set("organizationPartyId", organizationPartyId);
                ev.set("eventTypeId", eventTypeId);
                ev.set("entityName", entityName);
                ev.set("recordId", recordId);
                ev.set("oldValue", oldValue);
                ev.set("newValue", newValue);
                ev.set("eventDate", UtilDateTime.nowTimestamp());
                ev.set("userLoginId", userLoginId);
                ev.set("sourceIp", sourceIp);
                ev.create();
                return;
            }

            if (delegator.getModelEntity("PayrollAuditLog") != null) {
                GenericValue aud = delegator.makeValue("PayrollAuditLog");
                aud.set("payrollAuditLogId", delegator.getNextSeqId("PayrollAuditLog"));
                aud.set("organizationPartyId", organizationPartyId);
                aud.set("entityName", entityName);
                aud.set("recordId", recordId);
                aud.set("actionTypeId", eventTypeId);
                aud.set("oldValuesJson", oldValue);
                aud.set("newValuesJson", newValue);
                aud.set("changedByUserLoginId", userLoginId);
                aud.set("changedDate", UtilDateTime.nowTimestamp());
                aud.set("ipAddress", sourceIp);
                aud.create();
            } else {
                // No entity exists — just log and continue
                Debug.logInfo("Audit (no entity): org=" + organizationPartyId
                        + " type=" + eventTypeId
                        + " entity=" + entityName
                        + " recordId=" + recordId
                        + " user=" + userLoginId
                        + " ip=" + sourceIp, MODULE);
            }
        } catch (Exception e) {
            Debug.logWarning(e, "Payroll audit insert failed (non-fatal)", MODULE);
        }
    }

    private static String firstNonEmpty(String... vals) {
        if (vals == null) return null;
        for (String v : vals) {
            if (UtilValidate.isNotEmpty(v)) return v;
        }
        return null;
    }
}
