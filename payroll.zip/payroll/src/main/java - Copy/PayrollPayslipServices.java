package org.apache.ofbiz.payroll;

import java.io.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import org.apache.ofbiz.base.util.*;
import org.apache.ofbiz.entity.*;
import org.apache.ofbiz.entity.util.EntityQuery;
import org.apache.ofbiz.service.DispatchContext;
import org.apache.ofbiz.service.ServiceUtil;

import com.lowagie.text.*;
import com.lowagie.text.pdf.*;

public final class PayrollPayslipServices {
    public static final String MODULE = PayrollPayslipServices.class.getName();

    private PayrollPayslipServices() {}

    public static Map<String, Object> generatePayslipBarcode(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        String payrollResultId = (String) context.get("payrollResultId");
        String barcodeTypeId = (String) context.get("barcodeTypeId");
        if (UtilValidate.isEmpty(payrollResultId)) return ServiceUtil.returnError("payrollResultId is required");
        if (UtilValidate.isEmpty(barcodeTypeId)) barcodeTypeId = "CODE128";

        try {
            GenericValue res = EntityQuery.use(delegator).from("EmployeePayrollResult")
                    .where("payrollResultId", payrollResultId).queryOne();
            if (res == null) return ServiceUtil.returnError("EmployeePayrollResult not found: " + payrollResultId);

            String payrollRunId = res.getString("payrollRunId");
            String barcodeValue = payrollRunId + "|" + payrollResultId;

            GenericValue existing = EntityQuery.use(delegator).from("PayslipBarcode")
                    .where("payrollResultId", payrollResultId).queryFirst();

            Timestamp now = UtilDateTime.nowTimestamp();
            String payslipBarcodeId;
            if (existing == null) {
                payslipBarcodeId = delegator.getNextSeqId("PayslipBarcode");
                GenericValue b = delegator.makeValue("PayslipBarcode");
                b.set("payslipBarcodeId", payslipBarcodeId);
                b.set("payrollResultId", payrollResultId);
                b.set("barcodeValue", barcodeValue);
                b.set("barcodeTypeId", barcodeTypeId);
                b.set("generatedDate", now);
                b.set("scanCount", Long.valueOf(0));
                delegator.create(b);
            } else {
                payslipBarcodeId = existing.getString("payslipBarcodeId");
                existing.set("barcodeValue", barcodeValue);
                existing.set("barcodeTypeId", barcodeTypeId);
                existing.set("generatedDate", now);
                delegator.store(existing);
            }

            Map<String, Object> out = ServiceUtil.returnSuccess();
            out.put("payslipBarcodeId", payslipBarcodeId);
            out.put("barcodeValue", barcodeValue);
            return out;

        } catch (Exception e) {
            Debug.logError(e, "generatePayslipBarcode failed", MODULE);
            return ServiceUtil.returnError("generatePayslipBarcode failed: " + e.getMessage());
        }
    }

    public static Map<String, Object> generatePayslipPdfOpenPdf(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();

        String payrollResultId = (String) context.get("payrollResultId");
        String fileName = (String) context.get("fileName");

        if (UtilValidate.isEmpty(payrollResultId)) return ServiceUtil.returnError("payrollResultId is required");
        if (UtilValidate.isEmpty(fileName)) fileName = "Payslip_" + payrollResultId + ".pdf";

        try {
            GenericValue res = EntityQuery.use(delegator).from("EmployeePayrollResult")
                    .where("payrollResultId", payrollResultId).queryOne();
            if (res == null) return ServiceUtil.returnError("EmployeePayrollResult not found: " + payrollResultId);

            // Ensure barcode exists
            generatePayslipBarcode(dctx, UtilMisc.toMap("payrollResultId", payrollResultId, "userLogin", context.get("userLogin")));

            List<GenericValue> lines = EntityQuery.use(delegator).from("EmployeePayrollResultLine")
                    .where("payrollResultId", payrollResultId)
                    .orderBy("sequenceNum")
                    .queryList();

            byte[] pdfBytes = buildOpenPdf(res, lines);

            String exportFileId = storeExportFile(delegator, fileName, "application/pdf", pdfBytes);

            Map<String, Object> out = ServiceUtil.returnSuccess();
            out.put("exportFileId", exportFileId);
            return out;

        } catch (Exception e) {
            Debug.logError(e, "generatePayslipPdfOpenPdf failed", MODULE);
            return ServiceUtil.returnError("generatePayslipPdfOpenPdf failed: " + e.getMessage());
        }
    }

    private static byte[] buildOpenPdf(GenericValue res, List<GenericValue> lines) throws Exception {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        Document doc = new Document(PageSize.A4, 36, 36, 36, 36);
        PdfWriter writer = PdfWriter.getInstance(doc, baos);
        doc.open();

        Font h1 = new Font(Font.HELVETICA, 16, Font.BOLD);
        Font normal = new Font(Font.HELVETICA, 10, Font.NORMAL);
        Font bold = new Font(Font.HELVETICA, 10, Font.BOLD);

        doc.add(new Paragraph("Payslip", h1));
        doc.add(new Paragraph("Payroll Run: " + res.getString("payrollRunId"), normal));
        doc.add(new Paragraph("Employee PartyId: " + res.getString("partyId"), normal));
        doc.add(new Paragraph("Currency: " + res.getString("currencyUomId"), normal));
        doc.add(Chunk.NEWLINE);

        PdfPTable t = new PdfPTable(new float[]{70, 30});
        t.setWidthPercentage(100);

        addCell(t, "Line", bold);
        addCell(t, "Amount", bold);

        for (GenericValue l : lines) {
            addCell(t, l.getString("description"), normal);
            addCell(t, String.valueOf(l.getBigDecimal("amount")), normal);
        }
        doc.add(t);

        doc.add(Chunk.NEWLINE);

        // Barcode128 (OpenPDF has it)
        String barcodeText = res.getString("payrollRunId") + "|" + res.getString("payrollResultId");
        Barcode128 barcode = new Barcode128();
        barcode.setCode(barcodeText);
        barcode.setCodeType(Barcode128.CODE128);
        Image barcodeImg = barcode.createImageWithBarcode(writer.getDirectContent(), null, null);
        barcodeImg.scalePercent(120);
        doc.add(new Paragraph("Barcode:", bold));
        doc.add(barcodeImg);

        doc.close();
        writer.close();
        return baos.toByteArray();
    }

    private static void addCell(PdfPTable t, String txt, Font f) {
        PdfPCell c = new PdfPCell(new Phrase(txt == null ? "" : txt, f));
        c.setPadding(6);
        t.addCell(c);
    }

    public static Map<String, Object> generatePayslipPdfFop(DispatchContext dctx, Map<String, ?> context) {
        // FOP option: you provide XSL-FO template file path.
        // This method is intentionally strict: it needs FOP jars on classpath.
        Delegator delegator = dctx.getDelegator();

        String payrollResultId = (String) context.get("payrollResultId");
        String foTemplatePath = (String) context.get("foTemplatePath");
        String fileName = (String) context.get("fileName");
        if (UtilValidate.isEmpty(payrollResultId)) return ServiceUtil.returnError("payrollResultId is required");
        if (UtilValidate.isEmpty(foTemplatePath)) return ServiceUtil.returnError("foTemplatePath is required");
        if (UtilValidate.isEmpty(fileName)) fileName = "Payslip_" + payrollResultId + "_FOP.pdf";

        try {
            GenericValue res = EntityQuery.use(delegator).from("EmployeePayrollResult")
                    .where("payrollResultId", payrollResultId).queryOne();
            if (res == null) return ServiceUtil.returnError("EmployeePayrollResult not found: " + payrollResultId);

            // You can build FO from template + data; simplest: replace tokens.
            String fo = UtilFile.readFileToString(foTemplatePath, true);
            fo = fo.replace("${payrollResultId}", payrollResultId)
                   .replace("${payrollRunId}", res.getString("payrollRunId"))
                   .replace("${partyId}", res.getString("partyId"))
                   .replace("${netSalary}", String.valueOf(res.getBigDecimal("netSalary")));

            byte[] pdfBytes = FopUtil.foToPdfBytes(fo); // helper below
            String exportFileId = storeExportFile(delegator, fileName, "application/pdf", pdfBytes);

            Map<String, Object> out = ServiceUtil.returnSuccess();
            out.put("exportFileId", exportFileId);
            return out;

        } catch (Exception e) {
            Debug.logError(e, "generatePayslipPdfFop failed", MODULE);
            return ServiceUtil.returnError("generatePayslipPdfFop failed: " + e.getMessage());
        }
    }

    private static String storeExportFile(Delegator delegator, String fileName, String mimeType, byte[] bytes) throws Exception {
        // World-class: store path under runtime folder; here: write to ofbiz runtime/tmp
        String exportFileId = delegator.getNextSeqId("PayrollExportFile");

        String dir = System.getProperty("ofbiz.home") + "/runtime/tmp/payroll";
        File fdir = new File(dir);
        if (!fdir.exists()) fdir.mkdirs();

        String filePath = dir + "/" + exportFileId + "_" + fileName;
        try (FileOutputStream fos = new FileOutputStream(filePath)) {
            fos.write(bytes);
        }

        GenericValue file = delegator.makeValue("PayrollExportFile");
        file.set("exportFileId", exportFileId);
        file.set("exportRequestId", null); // optional link if you use PayrollExportRequest
        file.set("fileName", fileName);
        file.set("filePath", filePath);
        file.set("mimeTypeId", mimeType); // If your MimeType uses IDs; otherwise store string in a custom field
        file.set("fileSize", Long.valueOf(bytes.length));
        file.set("generatedDate", UtilDateTime.nowTimestamp());
        file.set("downloadCount", Long.valueOf(0));
        delegator.create(file);

        return exportFileId;
    }
}
