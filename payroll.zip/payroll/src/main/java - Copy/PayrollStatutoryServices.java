package org.apache.ofbiz.payroll;

import org.apache.ofbiz.entity.*;
import org.apache.ofbiz.entity.util.EntityQuery;
import org.apache.ofbiz.service.*;
import org.apache.ofbiz.base.util.*;

import java.math.BigDecimal;
import java.util.*;

public class PayrollStatutoryServices {

    /* ===================================================== */
    /* Income Tax (Progressive)                               */
    /* ===================================================== */

    public static BigDecimal calculateIncomeTax(
            Delegator delegator,
            String organizationPartyId,
            BigDecimal taxableIncome) throws GenericEntityException {

        List<GenericValue> brackets = EntityQuery.use(delegator)
                .from("IncomeTaxBracket")
                .where("organizationPartyId", organizationPartyId)
                .orderBy("fromAmount")
                .queryList();

        BigDecimal tax = BigDecimal.ZERO;

        for (GenericValue b : brackets) {
            BigDecimal from = b.getBigDecimal("fromAmount");
            BigDecimal to = b.getBigDecimal("toAmount");
            BigDecimal rate = b.getBigDecimal("taxRate");

            if (taxableIncome.compareTo(from) <= 0) continue;

            BigDecimal taxablePart =
                taxableIncome.min(to).subtract(from);

            tax = tax.add(
                taxablePart.multiply(rate).divide(new BigDecimal("100"))
            );

            if (taxableIncome.compareTo(to) <= 0) break;
        }
        return tax;
    }

    /* ===================================================== */
    /* GOSI / Insurance                                      */
    /* ===================================================== */

    public static Map<String, BigDecimal> calculateStatutory(
            Delegator delegator,
            String organizationPartyId,
            BigDecimal baseAmount) throws GenericEntityException {

        List<GenericValue> rules = EntityQuery.use(delegator)
                .from("StatutoryRule")
                .where("organizationPartyId", organizationPartyId)
                .queryList();

        BigDecimal emp = BigDecimal.ZERO;
        BigDecimal empr = BigDecimal.ZERO;
if (!"PAYROLL_APPROVED".equals(run.getString("statusId"))) {
    return ServiceUtil.returnError("Statutory calc only after approval");
}

        for (GenericValue r : rules) {
            BigDecimal min = r.getBigDecimal("minBaseAmount");
            BigDecimal max = r.getBigDecimal("maxBaseAmount");

            BigDecimal capped =
                baseAmount.max(min).min(max);

            emp = emp.add(
                capped.multiply(r.getBigDecimal("employeeRate"))
                      .divide(new BigDecimal("100"))
            );

            empr = empr.add(
                capped.multiply(r.getBigDecimal("employerRate"))
                      .divide(new BigDecimal("100"))
            );
        }

        Map<String, BigDecimal> result = new HashMap<>();
        result.put("EMPLOYEE", emp);
        result.put("EMPLOYER", empr);
        return result;
    }
}
