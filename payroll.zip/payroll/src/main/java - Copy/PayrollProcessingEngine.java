package org.apache.ofbiz.payroll.services.engine;

import org.apache.ofbiz.base.util.*;
import org.apache.ofbiz.entity.*;
import org.apache.ofbiz.entity.condition.*;
import org.apache.ofbiz.entity.util.EntityQuery;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.*;

public final class PayrollProcessingEngine {

    private PayrollProcessingEngine() {}

    // controlled line types
    public static final String LT_BASIC = "BASIC";
    public static final String LT_OVERTIME = "OVERTIME";
    public static final String LT_ALLOWANCE = "ALLOWANCE";
    public static final String LT_BONUS = "BONUS";
    public static final String LT_TAX = "TAX";
    public static final String LT_SOCSEC = "SOC_SEC";
    public static final String LT_LOAN = "LOAN";
    public static final String LT_DEDUCTION = "DEDUCTION";
    public static final String LT_ADJUSTMENT = "ADJUSTMENT";

    public static void process(Delegator delegator, GenericValue payrollRun, String processedByUserLoginId) throws Exception {
        String payrollRunId = payrollRun.getString("payrollRunId");
        String orgPartyId = payrollRun.getString("orgPartyId");
        String currencyUomId = payrollRun.getString("currencyUomId");
        Timestamp now = UtilDateTime.nowTimestamp();

        // find payroll period boundaries
        GenericValue period = EntityQuery.use(delegator).from("PayrollPeriod")
                .where("payrollPeriodId", payrollRun.getString("payrollPeriodId"))
                .queryOne();
        if (period == null) throw new IllegalStateException("PayrollPeriod not found for run.");

        // 1) Get active assignments for org during period (effectiveDate <= period.end AND (thruDate is null OR thruDate >= period.start))
        List<GenericValue> assignments = EntityQuery.use(delegator).from("EmployeePayrollAssignment")
                .where("orgPartyId", orgPartyId)
                .queryList();

        if (assignments.isEmpty()) {
            payrollRun.set("totalEmployees", 0L);
            payrollRun.set("totalGrossPay", BigDecimal.ZERO);
            payrollRun.set("totalDeductions", BigDecimal.ZERO);
            payrollRun.set("totalNetPay", BigDecimal.ZERO);
            payrollRun.store();
            return;
        }

        long totalEmployees = 0;
        BigDecimal totalGross = BigDecimal.ZERO;
        BigDecimal totalDed = BigDecimal.ZERO;
        BigDecimal totalNet = BigDecimal.ZERO;

        for (GenericValue asg : assignments) {
            // filter by effective/thru vs period range
            Timestamp eff = asg.getTimestamp("effectiveDate");
            Timestamp thru = asg.getTimestamp("thruDate");
            Timestamp periodStart = UtilDateTime.toTimestamp(period.getDate("startDate"));
            Timestamp periodEnd = UtilDateTime.toTimestamp(period.getDate("endDate"));

            if (eff != null && eff.after(periodEnd)) continue;
            if (thru != null && thru.before(periodStart)) continue;

            String partyId = asg.getString("partyId");
            totalEmployees++;

            // 2) Compute components
            BigDecimal basic = nz(asg.getBigDecimal("baseSalary"));

            BigDecimal overtime = computeOvertime(delegator, orgPartyId, partyId, payrollRun, periodStart, periodEnd);
            BigDecimal allowances = computeAllowances(delegator, orgPartyId, partyId, periodStart, periodEnd);
            BigDecimal bonuses = BigDecimal.ZERO; // extend later with Bonus entities if you add them
            BigDecimal tax = computeTax(delegator, orgPartyId, partyId, basic.add(overtime).add(allowances).add(bonuses), currencyUomId);
            BigDecimal social = computeSocialSecurity(delegator, orgPartyId, partyId, basic.add(overtime).add(allowances), currencyUomId);
            BigDecimal loan = computeLoanDeductions(delegator, orgPartyId, partyId, periodStart, periodEnd);
            BigDecimal otherDed = computeDeductions(delegator, orgPartyId, partyId, periodStart, periodEnd);

            BigDecimal gross = basic.add(overtime).add(allowances).add(bonuses);
            BigDecimal deductions = tax.add(social).add(loan).add(otherDed);
            BigDecimal net = gross.subtract(deductions);

            // 3) Write EmployeePayrollResult
            String payrollResultId = delegator.getNextSeqId("EmployeePayrollResult");
            GenericValue res = delegator.makeValue("EmployeePayrollResult",
                    "payrollResultId", payrollResultId,
                    "payrollRunId", payrollRunId,
                    "orgPartyId", orgPartyId,
                    "partyId", partyId,
                    "basicSalary", basic,
                    "overtimeAmount", overtime,
                    "allowancesTotal", allowances,
                    "bonuses", bonuses,
                    "grossSalary", gross,
                    "incomeTax", tax,
                    "socialSecurity", social,
                    "loanDeductions", loan,
                    "otherDeductions", otherDed,
                    "totalDeductions", deductions,
                    "netSalary", net,
                    "currencyUomId", currencyUomId,
                    "versionNumber", 1L
            );
            delegator.create(res);

            // 4) Write lines (controlled line types)
            createLine(delegator, payrollResultId, LT_BASIC, "Basic Salary", basic, currencyUomId, 10);
            if (overtime.signum() != 0) createLine(delegator, payrollResultId, LT_OVERTIME, "Overtime", overtime, currencyUomId, 20);
            if (allowances.signum() != 0) createLine(delegator, payrollResultId, LT_ALLOWANCE, "Allowances", allowances, currencyUomId, 30);
            if (bonuses.signum() != 0) createLine(delegator, payrollResultId, LT_BONUS, "Bonuses", bonuses, currencyUomId, 40);

            if (tax.signum() != 0) createLine(delegator, payrollResultId, LT_TAX, "Income Tax", tax.negate(), currencyUomId, 60);
            if (social.signum() != 0) createLine(delegator, payrollResultId, LT_SOCSEC, "Social Security", social.negate(), currencyUomId, 70);
            if (loan.signum() != 0) createLine(delegator, payrollResultId, LT_LOAN, "Loan Deduction", loan.negate(), currencyUomId, 80);
            if (otherDed.signum() != 0) createLine(delegator, payrollResultId, LT_DEDUCTION, "Other Deductions", otherDed.negate(), currencyUomId, 90);

            // 5) Update YTD summary (simple: year from period start)
            int year = UtilDateTime.toCalendar(periodStart).get(Calendar.YEAR);
            upsertYtd(delegator, orgPartyId, partyId, year, currencyUomId, gross, deductions, net);

            totalGross = totalGross.add(gross);
            totalDed = totalDed.add(deductions);
            totalNet = totalNet.add(net);
        }

        payrollRun.set("totalEmployees", totalEmployees);
        payrollRun.set("totalGrossPay", totalGross);
        payrollRun.set("totalDeductions", totalDed);
        payrollRun.set("totalNetPay", totalNet);
        payrollRun.store();
    }

    private static void createLine(Delegator delegator, String payrollResultId, String lineTypeId,
                                   String desc, BigDecimal amount, String currencyUomId, int seq) throws Exception {
        String id = delegator.getNextSeqId("EmployeePayrollResultLine");
        GenericValue ln = delegator.makeValue("EmployeePayrollResultLine",
                "resultLineId", id,
                "payrollResultId", payrollResultId,
                "lineTypeId", lineTypeId,
                "description", desc,
                "amount", nz(amount),
                "currencyUomId", currencyUomId,
                "sequenceNum", (long) seq
        );
        delegator.create(ln);
    }

    // --- Computation stubs (you can enhance) ---

    private static BigDecimal computeAllowances(Delegator d, String orgPartyId, String partyId, Timestamp start, Timestamp end) throws Exception {
        // EmployeeAllowance effectiveDate/thruDate filter
        List<GenericValue> list = EntityQuery.use(d).from("EmployeeAllowance")
                .where("orgPartyId", orgPartyId, "partyId", partyId)
                .queryList();
        BigDecimal sum = BigDecimal.ZERO;
        for (GenericValue a : list) sum = sum.add(nz(a.getBigDecimal("amount")));
        return sum;
    }

    private static BigDecimal computeDeductions(Delegator d, String orgPartyId, String partyId, Timestamp start, Timestamp end) throws Exception {
        List<GenericValue> list = EntityQuery.use(d).from("EmployeeDeduction")
                .where("orgPartyId", orgPartyId, "partyId", partyId)
                .queryList();
        BigDecimal sum = BigDecimal.ZERO;
        for (GenericValue a : list) sum = sum.add(nz(a.getBigDecimal("amount")));
        return sum;
    }

    private static BigDecimal computeLoanDeductions(Delegator d, String orgPartyId, String partyId, Timestamp start, Timestamp end) throws Exception {
        // simplest: active loans monthlyInstallment
        List<GenericValue> loans = EntityQuery.use(d).from("EmployeeLoan")
                .where("orgPartyId", orgPartyId, "partyId", partyId)
                .queryList();
        BigDecimal sum = BigDecimal.ZERO;
        for (GenericValue l : loans) sum = sum.add(nz(l.getBigDecimal("monthlyInstallment")));
        return sum;
    }

    private static BigDecimal computeTax(Delegator d, String orgPartyId, String partyId, BigDecimal taxable, String currencyUomId) throws Exception {
        // simple bracket: use PayrollTaxConfig (country/year can be enhanced)
        // For now: take first active config and apply taxRate if present.
        List<GenericValue> cfg = EntityQuery.use(d).from("PayrollTaxConfig")
                .where("orgPartyId", orgPartyId)
                .queryList();
        if (cfg.isEmpty()) return BigDecimal.ZERO;
        BigDecimal rate = cfg.get(0).getBigDecimal("taxRate");
        if (rate == null) return BigDecimal.ZERO;
        return taxable.multiply(rate);
    }

    private static BigDecimal computeSocialSecurity(Delegator d, String orgPartyId, String partyId, BigDecimal base, String currencyUomId) throws Exception {
        List<GenericValue> cfg = EntityQuery.use(d).from("SocialSecurityConfig")
                .where("orgPartyId", orgPartyId)
                .queryList();
        if (cfg.isEmpty()) return BigDecimal.ZERO;
        BigDecimal rate = cfg.get(0).getBigDecimal("employeeRate");
        if (rate == null) return BigDecimal.ZERO;
        return base.multiply(rate);
    }

    private static BigDecimal computeOvertime(Delegator d, String orgPartyId, String partyId, GenericValue run, Timestamp start, Timestamp end) {
        // you can integrate Attendance/Timesheet later
        return BigDecimal.ZERO;
    }

    private static void upsertYtd(Delegator d, String orgPartyId, String partyId, int year, String currencyUomId,
                                  BigDecimal gross, BigDecimal deductions, BigDecimal net) throws Exception {
        // World-class: ensure one row per (org, party, year, currency)
        GenericValue ytd = EntityQuery.use(d).from("EmployeeYTDSummary")
                .where("orgPartyId", orgPartyId, "partyId", partyId, "calendarYear", (long) year, "currencyUomId", currencyUomId)
                .queryFirst();

        if (ytd == null) {
            String id = d.getNextSeqId("EmployeeYTDSummary");
            ytd = d.makeValue("EmployeeYTDSummary",
                    "employeeYtdSummaryId", id,
                    "orgPartyId", orgPartyId,
                    "partyId", partyId,
                    "calendarYear", (long) year,
                    "currencyUomId", currencyUomId,
                    "ytdGross", gross,
                    "ytdNet", net,
                    "ytdTax", BigDecimal.ZERO,
                    "ytdSocialSecurity", BigDecimal.ZERO,
                    "lastCalculatedDate", UtilDateTime.nowTimestamp()
            );
            d.create(ytd);
        } else {
            ytd.set("ytdGross", nz(ytd.getBigDecimal("ytdGross")).add(gross));
            ytd.set("ytdNet", nz(ytd.getBigDecimal("ytdNet")).add(net));
            ytd.set("lastCalculatedDate", UtilDateTime.nowTimestamp());
            ytd.store();
        }
    }

    private static BigDecimal nz(BigDecimal v) { return v == null ? BigDecimal.ZERO : v; }
}
