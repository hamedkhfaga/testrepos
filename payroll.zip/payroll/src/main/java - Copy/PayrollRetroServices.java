package org.apache.ofbiz.payroll;

import org.apache.ofbiz.base.util.*;
import org.apache.ofbiz.entity.*;
import org.apache.ofbiz.entity.transaction.TransactionUtil;
import org.apache.ofbiz.entity.util.EntityQuery;
import org.apache.ofbiz.service.*;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.*;

public class PayrollRetroServices {
    public static final String MODULE = PayrollRetroServices.class.getName();

    // Batch statuses
    private static final String RETRO_NEW = "RETRO_NEW";
    private static final String RETRO_CALC = "RETRO_CALC";
    private static final String RETRO_APPROVED = "RETRO_APPROVED";
    private static final String RETRO_POSTED = "RETRO_POSTED";

    public static Map<String, Object> createPayrollRetroBatch(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        GenericValue userLogin = (GenericValue) context.get("userLogin");

        try {
            String orgId = (String) context.get("organizationPartyId");
            Integer month = (Integer) context.get("periodMonth");
            Integer year = (Integer) context.get("periodYear");
            Timestamp effectiveDate = (Timestamp) context.get("effectiveDate");

            if (UtilValidate.isEmpty(orgId) || month == null || year == null || effectiveDate == null) {
                return ServiceUtil.returnError("organizationPartyId, periodMonth, periodYear, effectiveDate are required");
            }

            String id = delegator.getNextSeqId("PayrollRetroBatch");
            GenericValue bat = delegator.makeValue("PayrollRetroBatch");
            bat.set("payrollRetroBatchId", id);
            bat.set("organizationPartyId", orgId);
            bat.set("periodMonth", month);
            bat.set("periodYear", year);
            bat.set("effectiveDate", effectiveDate);
            bat.set("applyInPayrollRunId", context.get("applyInPayrollRunId"));
            bat.set("postMode", context.get("postMode"));
            bat.set("reason", context.get("reason"));
            bat.set("statusId", RETRO_NEW);
            bat.set("createdDate", UtilDateTime.nowTimestamp());
            bat.set("createdByUserLoginId", userLogin != null ? userLogin.getString("userLoginId") : null);

            delegator.create(bat);

            Map<String, Object> out = ServiceUtil.returnSuccess();
            out.put("payrollRetroBatchId", id);
            return out;

        } catch (Exception e) {
            Debug.logError(e, "createPayrollRetroBatch failed", MODULE);
            return ServiceUtil.returnError("createPayrollRetroBatch failed: " + e.getMessage());
        }
    }

    /**
     * Add employees list to retro batch.
     * Inputs: payrollRetroBatchId, partyIdList (List<String>)
     */
    public static Map<String, Object> addEmployeesToRetroBatch(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        try {
            String batchId = (String) context.get("payrollRetroBatchId");
            @SuppressWarnings("unchecked")
            List<String> partyIdList = (List<String>) context.get("partyIdList");

            if (UtilValidate.isEmpty(batchId) || partyIdList == null || partyIdList.isEmpty()) {
                return ServiceUtil.returnError("payrollRetroBatchId and partyIdList are required");
            }

            for (String partyId : partyIdList) {
                String id = delegator.getNextSeqId("PayrollRetroEmployee");
                GenericValue re = delegator.makeValue("PayrollRetroEmployee");
                re.set("payrollRetroEmployeeId", id);
                re.set("payrollRetroBatchId", batchId);
                re.set("partyId", partyId);
                re.set("statusId", "RETRO_EMP_NEW");
                delegator.create(re);
            }

            return ServiceUtil.returnSuccess();
        } catch (Exception e) {
            Debug.logError(e, "addEmployeesToRetroBatch failed", MODULE);
            return ServiceUtil.returnError("addEmployeesToRetroBatch failed: " + e.getMessage());
        }
    }

    /**
     * Calculate retro deltas for employees in batch.
     *
     * Strategy:
     * - Old amounts come from ORIGINAL PayrollRunItem lines for that period (your existing payroll tables)
     * - New amounts are recomputed based on "current" assignment/statutory rules, but scoped by effectiveDate
     * - Store deltas as PayrollRetroDelta (only non-zero deltas)
     */
    public static Map<String, Object> calculatePayrollRetroBatch(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();

        String batchId = (String) context.get("payrollRetroBatchId");
        if (UtilValidate.isEmpty(batchId)) return ServiceUtil.returnError("payrollRetroBatchId is required");

        boolean began = false;
        int deltaLines = 0;

        try {
            began = TransactionUtil.begin();

            GenericValue bat = delegator.findOne("PayrollRetroBatch",
                    UtilMisc.toMap("payrollRetroBatchId", batchId), false);
            if (bat == null) return ServiceUtil.returnError("Retro batch not found");
            if (!RETRO_NEW.equals(bat.getString("statusId"))) {
                return ServiceUtil.returnError("Retro batch must be RETRO_NEW to calculate");
            }

            String orgId = bat.getString("organizationPartyId");
            int month = bat.getLong("periodMonth").intValue();
            int year = bat.getLong("periodYear").intValue();

            List<GenericValue> emps = EntityQuery.use(delegator)
                    .from("PayrollRetroEmployee")
                    .where("payrollRetroBatchId", batchId)
                    .queryList();

            // Clear existing deltas (re-calc)
            delegator.removeByAnd("PayrollRetroDelta", UtilMisc.toMap("payrollRetroBatchId", batchId));

            for (GenericValue emp : emps) {
                String partyId = emp.getString("partyId");

                // 1) OLD: get original payroll results for the same period
                // You must align these entity names to your implementation.
                // Assumption: PayrollRunItem has runMonth/runYear and partyId.
                GenericValue oldItem = EntityQuery.use(delegator)
                        .from("PayrollRunItem")
                        .where("organizationPartyId", orgId,
                               "partyId", partyId,
                               "runMonth", month,
                               "runYear", year)
                        .queryFirst();

                if (oldItem == null) {
                    // no original payroll => skip employee
                    continue;
                }

                BigDecimal oldGross = nvl(oldItem.getBigDecimal("grossAmount"));
                BigDecimal oldTax = nvl(oldItem.getBigDecimal("taxAmount"));
                BigDecimal oldGosiEmp = nvl(oldItem.getBigDecimal("gosiEmployeeAmount"));
                BigDecimal oldNet = nvl(oldItem.getBigDecimal("netAmount"));

                // 2) NEW: recompute using your current engine inputs.
                // You should replace these 4 lines with calls into your existing payroll calculation methods.
                // Here we keep a clean deterministic hook:
                Map<String, BigDecimal> newCalc = PayrollRetroUtil.recalculateForRetro(dctx, orgId, partyId, month, year);

                BigDecimal newGross = nvl(newCalc.get("gross"));
                BigDecimal newTax = nvl(newCalc.get("tax"));
                BigDecimal newGosiEmp = nvl(newCalc.get("gosiEmp"));
                BigDecimal newNet = nvl(newCalc.get("net"));

                // 3) Store delta lines (only non-zero)
                deltaLines += storeDelta(delegator, batchId, partyId, oldItem.getString("payrollRunItemId"),
                        "EARN", null, oldGross, newGross);

                deltaLines += storeDelta(delegator, batchId, partyId, oldItem.getString("payrollRunItemId"),
                        "TAX", null, oldTax, newTax);

                deltaLines += storeDelta(delegator, batchId, partyId, oldItem.getString("payrollRunItemId"),
                        "GOSI_EMP", null, oldGosiEmp, newGosiEmp);

                deltaLines += storeDelta(delegator, batchId, partyId, oldItem.getString("payrollRunItemId"),
                        "NET", null, oldNet, newNet);
            }

            bat.set("statusId", RETRO_CALC);
            bat.store();

            TransactionUtil.commit(began);

            Map<String, Object> out = ServiceUtil.returnSuccess();
            out.put("deltaLineCount", deltaLines);
            return out;

        } catch (Exception e) {
            try { if (began) TransactionUtil.rollback(began, e.getMessage(), e); } catch (Exception ignored) {}
            Debug.logError(e, "calculatePayrollRetroBatch failed", MODULE);
            return ServiceUtil.returnError("calculatePayrollRetroBatch failed: " + e.getMessage());
        }
    }

    public static Map<String, Object> approvePayrollRetroBatch(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        GenericValue userLogin = (GenericValue) context.get("userLogin");

        try {
            String batchId = (String) context.get("payrollRetroBatchId");
            if (UtilValidate.isEmpty(batchId)) return ServiceUtil.returnError("payrollRetroBatchId is required");

            GenericValue bat = delegator.findOne("PayrollRetroBatch",
                    UtilMisc.toMap("payrollRetroBatchId", batchId), false);
            if (bat == null) return ServiceUtil.returnError("Retro batch not found");
            if (!RETRO_CALC.equals(bat.getString("statusId"))) {
                return ServiceUtil.returnError("Retro batch must be RETRO_CALC to approve");
            }

            bat.set("statusId", RETRO_APPROVED);
            bat.set("approvedDate", UtilDateTime.nowTimestamp());
            bat.set("approvedByUserLoginId", userLogin != null ? userLogin.getString("userLoginId") : null);
            bat.store();

            return ServiceUtil.returnSuccess();
        } catch (Exception e) {
            Debug.logError(e, "approvePayrollRetroBatch failed", MODULE);
            return ServiceUtil.returnError("approvePayrollRetroBatch failed: " + e.getMessage());
        }
    }

    /**
     * Post retro deltas (GL/Invoice) as DIFFERENCE ONLY.
     * - Requires RETRO_APPROVED
     * - Creates PayrollRetroPosting record
     */
    public static Map<String, Object> postPayrollRetroBatch(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        LocalDispatcher dispatcher = dctx.getDispatcher();
        GenericValue userLogin = (GenericValue) context.get("userLogin");

        String batchId = (String) context.get("payrollRetroBatchId");
        if (UtilValidate.isEmpty(batchId)) return ServiceUtil.returnError("payrollRetroBatchId is required");

        boolean began = false;
        try {
            began = TransactionUtil.begin();

            GenericValue bat = delegator.findOne("PayrollRetroBatch",
                    UtilMisc.toMap("payrollRetroBatchId", batchId), false);
            if (bat == null) return ServiceUtil.returnError("Retro batch not found");
            if (!RETRO_APPROVED.equals(bat.getString("statusId"))) {
                return ServiceUtil.returnError("Retro batch must be RETRO_APPROVED to post");
            }

            String postMode = bat.getString("postMode");
            if (UtilValidate.isEmpty(postMode)) postMode = "GL";

            List<GenericValue> deltas = EntityQuery.use(delegator)
                    .from("PayrollRetroDelta")
                    .where("payrollRetroBatchId", batchId)
                    .queryList();

            // Post only deltaAmount != 0
            for (GenericValue d : deltas) {
                BigDecimal delta = nvl(d.getBigDecimal("deltaAmount"));
                if (delta.compareTo(BigDecimal.ZERO) == 0) continue;

                if ("GL".equals(postMode)) {
                    // Wire into your accounting posting service (you already started posting patterns)
                    Map<String, Object> glCtx = UtilMisc.toMap(
                            "organizationPartyId", bat.getString("organizationPartyId"),
                            "transactionDate", UtilDateTime.nowTimestamp(),
                            "amount", delta,
                            "description", "Retro payroll delta " + d.getString("lineTypeId") + " batch " + batchId,
                            "userLogin", userLogin
                    );
                    // Replace with your real posting service name (recommended wrapper)
                    dispatcher.runSync("createPayrollRetroAcctgTrans", glCtx);

                } else if ("INVOICE".equals(postMode)) {
                    Map<String, Object> invCtx = UtilMisc.toMap(
                            "organizationPartyId", bat.getString("organizationPartyId"),
                            "partyId", d.getString("partyId"),
                            "amount", delta,
                            "description", "Retro payroll delta batch " + batchId,
                            "userLogin", userLogin
                    );
                    dispatcher.runSync("createPayrollRetroInvoice", invCtx);
                }

                d.set("statusId", "RETRO_LINE_POSTED");
                d.store();
            }

            // Posting record
            String postingId = delegator.getNextSeqId("PayrollRetroPosting");
            GenericValue p = delegator.makeValue("PayrollRetroPosting");
            p.set("payrollRetroPostingId", postingId);
            p.set("payrollRetroBatchId", batchId);
            p.set("postMode", postMode);
            p.set("postedDate", UtilDateTime.nowTimestamp());
            p.set("postedByUserLoginId", userLogin != null ? userLogin.getString("userLoginId") : null);
            p.set("statusId", "RETRO_POST_OK");
            delegator.create(p);

            bat.set("statusId", RETRO_POSTED);
            bat.store();

            TransactionUtil.commit(began);
            return ServiceUtil.returnSuccess();

        } catch (Exception e) {
            try { if (began) TransactionUtil.rollback(began, e.getMessage(), e); } catch (Exception ignored) {}
            Debug.logError(e, "postPayrollRetroBatch failed", MODULE);
            return ServiceUtil.returnError("postPayrollRetroBatch failed: " + e.getMessage());
        }
    }

    /* --------------------------- helpers --------------------------- */

    private static BigDecimal nvl(BigDecimal v) { return v == null ? BigDecimal.ZERO : v; }

    private static int storeDelta(Delegator delegator, String batchId, String partyId, String originalRunItemId,
                                  String lineTypeId, String payComponentTypeId,
                                  BigDecimal oldAmt, BigDecimal newAmt) throws GenericEntityException {
        BigDecimal delta = nvl(newAmt).subtract(nvl(oldAmt));
        if (delta.compareTo(BigDecimal.ZERO) == 0) return 0;

        String id = delegator.getNextSeqId("PayrollRetroDelta");
        GenericValue d = delegator.makeValue("PayrollRetroDelta");
        d.set("payrollRetroDeltaId", id);
        d.set("payrollRetroBatchId", batchId);
        d.set("partyId", partyId);
        d.set("originalPayrollRunItemId", originalRunItemId);
        d.set("lineTypeId", lineTypeId);
        d.set("payComponentTypeId", payComponentTypeId);
        d.set("oldAmount", oldAmt);
        d.set("newAmount", newAmt);
        d.set("deltaAmount", delta);
        d.set("statusId", "RETRO_LINE_NEW");
        delegator.create(d);
        return 1;
    }
}
