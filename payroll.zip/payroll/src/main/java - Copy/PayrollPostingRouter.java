package org.apache.ofbiz.payroll;

import org.apache.ofbiz.base.util.Debug;
import org.apache.ofbiz.base.util.UtilValidate;
import org.apache.ofbiz.service.DispatchContext;
import org.apache.ofbiz.service.ServiceUtil;

import java.util.HashMap;
import java.util.Map;

public class PayrollPostingRouter {
    public static final String MODULE = PayrollPostingRouter.class.getName();

    // Align these option IDs with your PayrollRun.accountingPostOptionId values
    private static final String OPT_GL = "POST_TO_GL";
    private static final String OPT_INVOICE = "POST_TO_INVOICE";
    private static final String OPT_BOTH = "POST_TO_BOTH";

    public static Map<String, Object> postPayrollRunAccounting(DispatchContext dctx, Map<String, ?> context) {
        try {
            String payrollRunId = (String) context.get("payrollRunId");
            if (UtilValidate.isEmpty(payrollRunId)) {
                return ServiceUtil.returnError("payrollRunId is required");
            }

            String vendorPartyId = (String) context.get("vendorPartyId");
            String invoiceTypeId = (String) context.get("invoiceTypeId");
            Boolean forceRepost = (Boolean) context.get("forceRepost");
            String sourceIp = (String) context.get("sourceIp");

            String organizationPartyId = (String) context.get("organizationPartyId");
            String orgPartyId = (String) context.get("orgPartyId");

            // If controller already sets option in PayrollRun, it can be passed here too.
            String option = (String) context.get("accountingPostOptionId");

            if (UtilValidate.isEmpty(option)) {
                // If not passed, default to GL (safe)
                option = OPT_GL;
            }

            Map<String, Object> base = new HashMap<>();
            base.put("payrollRunId", payrollRunId);
            base.put("organizationPartyId", organizationPartyId);
            base.put("orgPartyId", orgPartyId);
            base.put("forceRepost", forceRepost);
            base.put("sourceIp", sourceIp);
            base.put("userLogin", context.get("userLogin"));

            Map<String, Object> out = ServiceUtil.returnSuccess();

            if (OPT_GL.equals(option)) {
                Map<String, Object> r = dctx.getDispatcher().runSync("postPayrollRunToGl", base);
                if (ServiceUtil.isError(r)) return r;
                out.put("glJournalId", r.get("glJournalId"));
                return out;
            }

            if (OPT_INVOICE.equals(option)) {
                Map<String, Object> inv = new HashMap<>(base);
                inv.put("vendorPartyId", vendorPartyId);
                inv.put("invoiceTypeId", invoiceTypeId);
                Map<String, Object> r = dctx.getDispatcher().runSync("postPayrollRunToInvoice", inv);
                if (ServiceUtil.isError(r)) return r;
                out.put("invoiceId", r.get("invoiceId"));
                return out;
            }

            if (OPT_BOTH.equals(option)) {
                Map<String, Object> r1 = dctx.getDispatcher().runSync("postPayrollRunToGl", base);
                if (ServiceUtil.isError(r1)) return r1;

                Map<String, Object> inv = new HashMap<>(base);
                inv.put("vendorPartyId", vendorPartyId);
                inv.put("invoiceTypeId", invoiceTypeId);
                Map<String, Object> r2 = dctx.getDispatcher().runSync("postPayrollRunToInvoice", inv);
                if (ServiceUtil.isError(r2)) return r2;

                out.put("glJournalId", r1.get("glJournalId"));
                out.put("invoiceId", r2.get("invoiceId"));
                return out;
            }

            return ServiceUtil.returnError("Unsupported accountingPostOptionId=" + option
                    + " expected one of: " + OPT_GL + ", " + OPT_INVOICE + ", " + OPT_BOTH);

        } catch (Exception e) {
            Debug.logError(e, "postPayrollRunAccounting failed", MODULE);
            return ServiceUtil.returnError("postPayrollRunAccounting failed: " + e.getMessage());
        }
    }
}
