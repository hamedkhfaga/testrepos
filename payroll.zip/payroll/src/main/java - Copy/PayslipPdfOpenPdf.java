package org.apache.ofbiz.payroll.export;

import com.lowagie.text.*;
import com.lowagie.text.pdf.*;
import org.apache.ofbiz.payroll.export.PayrollExportServices.ExportPayload;
import org.apache.ofbiz.payroll.export.PayrollExportServices.GeneratedFile;

import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;

public final class PayslipPdfOpenPdf {

    private PayslipPdfOpenPdf() {}

    public static GeneratedFile generate(ExportPayload p, String code128Value, String qrText) throws Exception {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();

        Document document = new Document(PageSize.A4, 36, 36, 36, 36);
        PdfWriter writer = PdfWriter.getInstance(document, baos);

        document.open();

        Font titleFont = new Font(Font.HELVETICA, 14, Font.BOLD);
        Font labelFont = new Font(Font.HELVETICA, 10, Font.BOLD);
        Font normalFont = new Font(Font.HELVETICA, 10, Font.NORMAL);

        // Header row: title left, barcode right
        PdfPTable header = new PdfPTable(2);
        header.setWidthPercentage(100f);
        header.setWidths(new float[]{2.5f, 1.0f});

        PdfPCell left = new PdfPCell();
        left.setBorder(Rectangle.NO_BORDER);
        left.addElement(new Paragraph("Payslip", titleFont));
        left.addElement(new Paragraph("Employee: " + p.employeeName, normalFont));
        left.addElement(new Paragraph("Employee ID: " + p.partyId, normalFont));
        left.addElement(new Paragraph("Payroll Result: " + p.payrollResultId, normalFont));
        left.addElement(new Paragraph("Run: " + p.payrollRunId, normalFont));
        left.addElement(new Paragraph("Currency: " + p.currencyUomId, normalFont));
        header.addCell(left);

        PdfPCell right = new PdfPCell();
        right.setBorder(Rectangle.NO_BORDER);
        right.setHorizontalAlignment(Element.ALIGN_RIGHT);

        Image bc = OpenPdfBarcodeRenderer.buildCode128Image(writer, code128Value);
        bc.scaleToFit(220f, 50f);
        Image qr = OpenPdfBarcodeRenderer.buildQrImage(qrText, 180);

        right.addElement(bc);
        right.addElement(qr);
        header.addCell(right);

        document.add(header);
        document.add(Chunk.NEWLINE);

        // Totals
        PdfPTable totals = new PdfPTable(2);
        totals.setWidthPercentage(60f);
        totals.setHorizontalAlignment(Element.ALIGN_LEFT);

        addKV(totals, "Gross Salary", money(p.grossSalary), labelFont, normalFont);
        addKV(totals, "Total Deductions", money(p.totalDeductions), labelFont, normalFont);
        addKV(totals, "Net Salary", money(p.netSalary), labelFont, normalFont);

        document.add(totals);
        document.add(Chunk.NEWLINE);

        // Lines breakdown
        PdfPTable lines = new PdfPTable(4);
        lines.setWidthPercentage(100f);
        lines.setWidths(new float[]{1.2f, 3.0f, 1.4f, 1.2f});

        addHeader(lines, "Type", labelFont);
        addHeader(lines, "Description", labelFont);
        addHeader(lines, "Amount", labelFont);
        addHeader(lines, "Curr", labelFont);

        for (var l : p.resultLines) {
            addCell(lines, safe(l.getString("lineTypeId")), normalFont);
            addCell(lines, safe(l.getString("description")), normalFont);
            addCell(lines, money((BigDecimal) l.get("amount")), normalFont);
            addCell(lines, safe(l.getString("currencyUomId") != null ? l.getString("currencyUomId") : p.currencyUomId), normalFont);
        }

        document.add(lines);

        document.close();

        byte[] bytes = baos.toByteArray();
        String fileName = "payslip_" + p.payrollResultId + ".pdf";
        return GeneratedFile.of(fileName, "application/pdf", bytes);
    }

    private static void addKV(PdfPTable t, String k, String v, Font kf, Font vf) {
        PdfPCell c1 = new PdfPCell(new Phrase(k, kf));
        PdfPCell c2 = new PdfPCell(new Phrase(v, vf));
        c1.setPadding(6f); c2.setPadding(6f);
        t.addCell(c1); t.addCell(c2);
    }

    private static void addHeader(PdfPTable t, String text, Font f) {
        PdfPCell c = new PdfPCell(new Phrase(text, f));
        c.setPadding(6f);
        t.addCell(c);
    }

    private static void addCell(PdfPTable t, String text, Font f) {
        PdfPCell c = new PdfPCell(new Phrase(text, f));
        c.setPadding(5f);
        t.addCell(c);
    }

    private static String money(BigDecimal v) {
        if (v == null) v = BigDecimal.ZERO;
        return v.toPlainString();
    }

    private static String safe(String s) { return s == null ? "" : s; }
}
