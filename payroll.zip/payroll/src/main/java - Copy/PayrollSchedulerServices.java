package org.apache.ofbiz.payroll.services;

import org.apache.ofbiz.base.util.Debug;
import org.apache.ofbiz.base.util.UtilDateTime;
import org.apache.ofbiz.base.util.UtilMisc;
import org.apache.ofbiz.base.util.UtilValidate;

import org.apache.ofbiz.entity.Delegator;
import org.apache.ofbiz.entity.GenericEntityException;
import org.apache.ofbiz.entity.GenericValue;
import org.apache.ofbiz.entity.util.EntityQuery;

import org.apache.ofbiz.service.DispatchContext;
import org.apache.ofbiz.service.LocalDispatcher;
import org.apache.ofbiz.service.ServiceUtil;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

/**
 * PayrollSchedulerServices (FINAL consolidated)
 *
 * Covers:
 * 1) Monthly payroll automation (per organization)
 *    - Attendance summary build
 *    - Create run
 *    - Auto-approve
 *    - Process payroll
 *    - Auto-post (GL/Invoice/Both) via PayrollPostingServices.postPayrollRun
 *
 * 2) Queue workers: email/sms/export (self-rescheduling)
 * 3) Daily compliance worker (self-rescheduling)
 *
 * Upgrade-safe:
 * - plugin-only, no OFBiz core changes
 * - uses JobSandbox self-rescheduling pattern
 * - optional dependencies via runIfExists()
 */
public class PayrollSchedulerServices {
    public static final String MODULE = PayrollSchedulerServices.class.getName();

    // ----------------------------
    // Job Names
    // ----------------------------
    public static final String JOB_MONTHLY_PAYROLL     = "PAYROLL_MONTHLY_RUNNER";
    public static final String JOB_EMAIL_WORKER        = "PAYROLL_EMAIL_WORKER";
    public static final String JOB_SMS_WORKER          = "PAYROLL_SMS_WORKER";
    public static final String JOB_EXPORT_WORKER       = "PAYROLL_EXPORT_WORKER";
    public static final String JOB_COMPLIANCE_WORKER   = "PAYROLL_COMPLIANCE_WORKER";

    // ----------------------------
    // Intervals / times
    // ----------------------------
    private static final long EMAIL_INTERVAL_MS  = 5L * 60L * 1000L;   // 5 minutes
    private static final long SMS_INTERVAL_MS    = 5L * 60L * 1000L;   // 5 minutes
    private static final long EXPORT_INTERVAL_MS = 10L * 60L * 1000L;  // 10 minutes

    private static final int COMPLIANCE_HOUR = 2; // 02:00 daily

    // Monthly payroll: schedule next run at day=1 01:00
    private static final int MONTHLY_RUN_DAY  = 1;
    private static final int MONTHLY_RUN_HOUR = 1;

    // Posting options (should match your PayrollPostingServices constants / your status setup)
    public static final String OPT_NONE    = "PAY_POST_NONE";
    public static final String OPT_GL      = "PAY_POST_GL";
    public static final String OPT_INVOICE = "PAY_POST_INVOICE";
    public static final String OPT_BOTH    = "PAY_POST_BOTH";

    // ---------------------------------------------------------
    // 1) Monthly payroll (per org) + attendance + approve + post
    // ---------------------------------------------------------
    /**
     * Runs monthly payroll for all INTERNAL_ORGANIZATION parties.
     *
     * Inputs (optional unless noted):
     * - runMonth (numeric) optional
     * - runYear  (numeric) optional
     * - accountingPostOptionId (PAY_POST_NONE/GL/INVOICE/BOTH) optional
     * - vendorPartyId (optional, required only when posting to invoice)
     * - invoiceTypeId (optional)
     * - glFiscalTypeId (optional)
     * - glJournalName (optional)
     * - forceRepost (Boolean optional)
     *
     * Notes:
     * - organizationPartyId derived from PartyRole list; but you may pass singleOrgPartyId to run only one org.
     */
    public static Map<String, Object> runMonthlyPayroll(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        LocalDispatcher dispatcher = dctx.getDispatcher();
        GenericValue userLogin = (GenericValue) context.get("userLogin");

        try {
            // Determine month/year
            Integer runMonth = (Integer) context.get("runMonth");
            Integer runYear  = (Integer) context.get("runYear");

            if (runMonth == null || runYear == null) {
                Calendar cal = Calendar.getInstance();
                if (runMonth == null) runMonth = cal.get(Calendar.MONTH) + 1; // 1..12
                if (runYear == null) runYear = cal.get(Calendar.YEAR);
            }

            // Optional single org run
            String singleOrg = firstOrg(context);

            List<GenericValue> orgRoles;
            if (UtilValidate.isNotEmpty(singleOrg)) {
                // Validate org exists with role
                orgRoles = EntityQuery.use(delegator)
                        .from("PartyRole")
                        .where("roleTypeId", "INTERNAL_ORGANIZATION",
                               "partyId", singleOrg)
                        .queryList();
            } else {
                orgRoles = EntityQuery.use(delegator)
                        .from("PartyRole")
                        .where("roleTypeId", "INTERNAL_ORGANIZATION")
                        .queryList();
            }

            int okCount = 0;
            int errCount = 0;

            // Posting option can be provided to override PayrollRun.accountingPostOptionId
            String postOption = (String) context.get("accountingPostOptionId");
            Boolean forceRepost = (Boolean) context.get("forceRepost");

            for (GenericValue orgRole : orgRoles) {
                String organizationPartyId = orgRole.getString("partyId");

                try {
                    Map<String, Object> runCtx = UtilMisc.toMap(
                            "organizationPartyId", organizationPartyId,
                            "runMonth", runMonth,
                            "runYear", runYear,
                            "userLogin", userLogin
                    );

                    // Attendance summary first (optional dependency)
                    runIfExists(dispatcher, "buildAttendancePeriodSummary", runCtx);

                    // Create payroll run
                    Map<String, Object> created = dispatcher.runSync("createPayrollRun", runCtx);
                    if (ServiceUtil.isError(created)) {
                        errCount++;
                        Debug.logError("createPayrollRun failed org=" + organizationPartyId
                                + " err=" + ServiceUtil.getErrorMessage(created), MODULE);
                        auditIfExists(dispatcher, userLogin, organizationPartyId,
                                "RUN_CREATE_ERR", "PayrollRun", null,
                                null, ServiceUtil.getErrorMessage(created), null);
                        continue;
                    }

                    String payrollRunId = (String) created.get("payrollRunId");
                    if (UtilValidate.isEmpty(payrollRunId)) {
                        // fallback: try to locate latest run for this org+month+year if your service didn't return id
                        payrollRunId = findLatestPayrollRunId(delegator, organizationPartyId, runMonth, runYear);
                    }
                    if (UtilValidate.isEmpty(payrollRunId)) {
                        errCount++;
                        Debug.logError("createPayrollRun did not return payrollRunId and could not resolve latest run for org=" + organizationPartyId, MODULE);
                        continue;
                    }

                    // Auto-approve (optional dependency)
                    runIfExists(dispatcher, "approvePayrollRun", UtilMisc.toMap(
                            "payrollRunId", payrollRunId,
                            "organizationPartyId", organizationPartyId,
                            "approvedByUserLoginId", userLogin == null ? null : userLogin.getString("userLoginId"),
                            "userLogin", userLogin
                    ));

                    // Process payroll
                    Map<String, Object> processed = dispatcher.runSync("processPayrollRun", UtilMisc.toMap(
                            "payrollRunId", payrollRunId,
                            "organizationPartyId", organizationPartyId,
                            "userLogin", userLogin
                    ));
                    if (ServiceUtil.isError(processed)) {
                        errCount++;
                        Debug.logError("processPayrollRun failed org=" + organizationPartyId
                                + " run=" + payrollRunId
                                + " err=" + ServiceUtil.getErrorMessage(processed), MODULE);
                        auditIfExists(dispatcher, userLogin, organizationPartyId,
                                "RUN_PROCESS_ERR", "PayrollRun", payrollRunId,
                                null, ServiceUtil.getErrorMessage(processed), null);
                        continue;
                    }

                    // Auto-post (optional: if you don't want posting, pass PAY_POST_NONE)
                    // If postOption is empty, postPayrollRun will read PayrollRun.accountingPostOptionId
                    if (!OPT_NONE.equals(postOption)) {
                        Map<String, Object> postCtx = UtilMisc.toMap(
                                "payrollRunId", payrollRunId,
                                "organizationPartyId", organizationPartyId,
                                "accountingPostOptionId", postOption,
                                "vendorPartyId", context.get("vendorPartyId"),
                                "invoiceTypeId", context.get("invoiceTypeId"),
                                "glFiscalTypeId", context.get("glFiscalTypeId"),
                                "glJournalName", context.get("glJournalName"),
                                "forceRepost", forceRepost,
                                "userLogin", userLogin
                        );

                        // postPayrollRun is in PayrollPostingServices.java
                        runIfExists(dispatcher, "postPayrollRun", postCtx);
                    }

                    auditIfExists(dispatcher, userLogin, organizationPartyId,
                            "RUN_MONTHLY_OK", "PayrollRun", payrollRunId,
                            null, "month=" + runMonth + ",year=" + runYear, null);

                    okCount++;

                } catch (Exception perOrg) {
                    errCount++;
                    Debug.logError(perOrg, "Monthly payroll failed org=" + organizationPartyId, MODULE);
                    auditIfExists(dispatcher, userLogin, organizationPartyId,
                            "RUN_MONTHLY_ERR", "PayrollOrganization", organizationPartyId,
                            null, perOrg.getMessage(), null);
                }
            }

            // Reschedule itself monthly (no duplicates)
            Timestamp nextMonthly = nextMonthlyTime(MONTHLY_RUN_DAY, MONTHLY_RUN_HOUR);
            ensureSingleScheduled(delegator, JOB_MONTHLY_PAYROLL, "runMonthlyPayroll", nextMonthly, userLogin);

            Map<String, Object> out = ServiceUtil.returnSuccess("Monthly payroll executed. ok=" + okCount + " err=" + errCount);
            out.put("okCount", okCount);
            out.put("errorCount", errCount);
            out.put("nextRunTime", nextMonthly);
            out.put("runMonth", runMonth);
            out.put("runYear", runYear);
            return out;

        } catch (Exception e) {
            Debug.logError(e, "runMonthlyPayroll failed", MODULE);
            return ServiceUtil.returnError("runMonthlyPayroll failed: " + e.getMessage());
        }
    }

    // ----------------------------
    // 2) Queue Workers (self-reschedule)
    // ----------------------------
    public static Map<String, Object> processPayrollEmailQueueWorker(DispatchContext dctx, Map<String, ?> context) {
        return runWorkerAndReschedule(dctx, context,
                "processPayrollEmailQueue",
                JOB_EMAIL_WORKER,
                "processPayrollEmailQueueWorker",
                EMAIL_INTERVAL_MS);
    }

    public static Map<String, Object> processPayrollSmsQueueWorker(DispatchContext dctx, Map<String, ?> context) {
        return runWorkerAndReschedule(dctx, context,
                "processPayrollSmsQueue",
                JOB_SMS_WORKER,
                "processPayrollSmsQueueWorker",
                SMS_INTERVAL_MS);
    }

    public static Map<String, Object> processPayrollExportQueueWorker(DispatchContext dctx, Map<String, ?> context) {
        return runWorkerAndReschedule(dctx, context,
                "processPayrollExportRequestQueue",
                JOB_EXPORT_WORKER,
                "processPayrollExportQueueWorker",
                EXPORT_INTERVAL_MS);
    }

    // ----------------------------
    // 3) Daily Compliance Worker
    // ----------------------------
    public static Map<String, Object> processPayrollComplianceDailyWorker(DispatchContext dctx, Map<String, ?> context) {
        LocalDispatcher dispatcher = dctx.getDispatcher();
        Delegator delegator = dctx.getDelegator();
        GenericValue userLogin = (GenericValue) context.get("userLogin");

        try {
            // Generate compliance reports (optional dependency)
            runIfExists(dispatcher, "generatePayrollComplianceReport", UtilMisc.toMap("userLogin", userLogin));
            auditIfExists(dispatcher, userLogin, null,
                    "COMPLIANCE_DAILY_OK", "PayrollComplianceReport", null,
                    null, "generatePayrollComplianceReport", null);
        } catch (Exception e) {
            Debug.logError(e, "Compliance worker failed", MODULE);
            auditIfExists(dispatcher, userLogin, null,
                    "COMPLIANCE_DAILY_ERR", "PayrollComplianceReport", null,
                    null, e.getMessage(), null);
        }

        try {
            Timestamp nextRun = nextDailyTime(COMPLIANCE_HOUR);
            ensureSingleScheduled(delegator, JOB_COMPLIANCE_WORKER, "processPayrollComplianceDailyWorker", nextRun, userLogin);
        } catch (Exception e) {
            Debug.logError(e, "Compliance reschedule failed", MODULE);
            return ServiceUtil.returnError("Compliance reschedule failed: " + e.getMessage());
        }

        return ServiceUtil.returnSuccess();
    }

    // =========================================================
    // Helpers
    // =========================================================

    private static Map<String, Object> runWorkerAndReschedule(DispatchContext dctx,
                                                             Map<String, ?> context,
                                                             String targetServiceName,
                                                             String jobName,
                                                             String workerServiceName,
                                                             long intervalMs) {
        LocalDispatcher dispatcher = dctx.getDispatcher();
        Delegator delegator = dctx.getDelegator();
        GenericValue userLogin = (GenericValue) context.get("userLogin");

        try {
            runIfExists(dispatcher, targetServiceName, UtilMisc.toMap("userLogin", userLogin));
        } catch (Exception e) {
            Debug.logError(e, "Worker target failed: " + targetServiceName, MODULE);
        }

        try {
            Timestamp nextRun = new Timestamp(System.currentTimeMillis() + intervalMs);
            ensureSingleScheduled(delegator, jobName, workerServiceName, nextRun, userLogin);
        } catch (Exception e) {
            Debug.logError(e, "Worker reschedule failed: " + jobName, MODULE);
            return ServiceUtil.returnError("Reschedule failed: " + e.getMessage());
        }

        return ServiceUtil.returnSuccess();
    }

    /**
     * Call a service only if it exists (upgrade-safe + optional dependencies).
     */
    private static void runIfExists(LocalDispatcher dispatcher, String serviceName, Map<String, Object> ctx) throws Exception {
        try {
            dispatcher.getDispatchContext().getModelService(serviceName);
        } catch (Exception notFound) {
            return; // service not installed in this build
        }
        Map<String, Object> res = dispatcher.runSync(serviceName, ctx);
        if (ServiceUtil.isError(res)) {
            throw new Exception(serviceName + " error: " + ServiceUtil.getErrorMessage(res));
        }
    }

    /**
     * Optional audit call (non-blocking).
     * Requires your service: recordPayrollAuditEvent
     */
    private static void auditIfExists(LocalDispatcher dispatcher,
                                      GenericValue userLogin,
                                      String organizationPartyId,
                                      String eventTypeId,
                                      String entityName,
                                      String recordId,
                                      String oldValue,
                                      String newValue,
                                      String sourceIp) {
        try {
            dispatcher.getDispatchContext().getModelService("recordPayrollAuditEvent");
        } catch (Exception notFound) {
            return;
        }
        try {
            Map<String, Object> ctx = UtilMisc.toMap(
                    "organizationPartyId", organizationPartyId,
                    "eventTypeId", eventTypeId,
                    "entityName", entityName,
                    "recordId", recordId,
                    "oldValue", oldValue,
                    "newValue", newValue,
                    "sourceIp", sourceIp,
                    "userLogin", userLogin
            );
            dispatcher.runSync("recordPayrollAuditEvent", ctx);
        } catch (Exception ignored) {
            // never block scheduler
        }
    }

    /**
     * Prevent duplicate pending jobs: (jobName + serviceName + status=PENDING).
     */
    private static void ensureSingleScheduled(Delegator delegator,
                                             String jobName,
                                             String serviceName,
                                             Timestamp nextRun,
                                             GenericValue userLogin) throws GenericEntityException {

        GenericValue existing = EntityQuery.use(delegator).from("JobSandbox")
                .where("jobName", jobName,
                        "serviceName", serviceName,
                        "statusId", "SERVICE_PENDING")
                .queryFirst();

        if (existing != null) return;

        GenericValue job = delegator.makeValue("JobSandbox");
        job.set("jobId", delegator.getNextSeqId("JobSandbox"));
        job.set("jobName", jobName);
        job.set("serviceName", serviceName);
        job.set("poolId", "pool");
        job.set("runAsUser", userLogin == null ? "system" : userLogin.getString("userLoginId"));
        job.set("runTime", nextRun.getTime());
        job.set("statusId", "SERVICE_PENDING");
        job.set("maxRetry", Long.valueOf(3));
        job.set("currentRetryCount", Long.valueOf(0));

        delegator.create(job);
    }

    private static Timestamp nextDailyTime(int hour) {
        Calendar c = Calendar.getInstance();
        c.setTime(UtilDateTime.nowTimestamp());

        c.set(Calendar.HOUR_OF_DAY, hour);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);

        if (c.getTimeInMillis() <= System.currentTimeMillis()) {
            c.add(Calendar.DAY_OF_MONTH, 1);
        }
        return new Timestamp(c.getTimeInMillis());
    }

    private static Timestamp nextMonthlyTime(int dayOfMonth, int hour) {
        Calendar c = Calendar.getInstance();
        c.setTime(UtilDateTime.nowTimestamp());

        c.set(Calendar.DAY_OF_MONTH, dayOfMonth);
        c.set(Calendar.HOUR_OF_DAY, hour);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);

        if (c.getTimeInMillis() <= System.currentTimeMillis()) {
            c.add(Calendar.MONTH, 1);
            c.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            c.set(Calendar.HOUR_OF_DAY, hour);
        }
        return new Timestamp(c.getTimeInMillis());
    }

    /**
     * Compatibility helper: accept organizationPartyId or orgPartyId from context.
     */
    private static String firstOrg(Map<String, ?> context) {
        String organizationPartyId = (String) context.get("organizationPartyId");
        if (UtilValidate.isEmpty(organizationPartyId)) organizationPartyId = (String) context.get("orgPartyId");
        return organizationPartyId;
    }

    /**
     * If createPayrollRun doesn't return payrollRunId, we try to find latest run for org + month/year.
     * This assumes your PayrollRun has periodMonth/periodYear OR runMonth/runYear fields.
     * If not, keep createPayrollRun returning payrollRunId (recommended).
     */
    private static String findLatestPayrollRunId(Delegator delegator, String organizationPartyId, Integer runMonth, Integer runYear) {
        try {
            // Try common names. If your PayrollRun doesn't have these, this will just fail and return null.
            GenericValue run = EntityQuery.use(delegator).from("PayrollRun")
                    .where("organizationPartyId", organizationPartyId,
                           "periodMonth", runMonth,
                           "periodYear", runYear)
                    .orderBy("-runDate")
                    .queryFirst();
            if (run != null) return run.getString("payrollRunId");
        } catch (Exception ignored) {}

        try {
            GenericValue run = EntityQuery.use(delegator).from("PayrollRun")
                    .where("organizationPartyId", organizationPartyId)
                    .orderBy("-runDate")
                    .queryFirst();
            if (run != null) return run.getString("payrollRunId");
        } catch (Exception ignored) {}

        return null;
    }
}
