package org.apache.ofbiz.payroll;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.apache.ofbiz.base.util.UtilDateTime;
import org.apache.ofbiz.base.util.UtilMisc;
import org.apache.ofbiz.base.util.UtilValidate;
import org.apache.ofbiz.entity.Delegator;
import org.apache.ofbiz.entity.GenericValue;
import org.apache.ofbiz.entity.util.EntityQuery;
import org.apache.ofbiz.service.DispatchContext;
import org.apache.ofbiz.service.ServiceUtil;

public class PayrollComplianceServices {

    public static Map<String, Object> generatePayrollComplianceReport(DispatchContext dctx, Map<String, ?> ctx) {
        Delegator d = dctx.getDelegator();
        GenericValue u = (GenericValue) ctx.get("userLogin");

        String orgId = (String) ctx.get("organizationPartyId");
        Integer y = (Integer) ctx.get("periodYear");
        Integer m = (Integer) ctx.get("periodMonth");
        String type = (String) ctx.get("reportTypeId");

        if (UtilValidate.isAnyEmpty(orgId, y, m, type)) {
            return ServiceUtil.returnError("organizationPartyId, periodYear, periodMonth, reportTypeId are required");
        }

        try {
            String repId = d.getNextSeqId("PayrollComplianceReport");
            GenericValue rep = d.makeValue("PayrollComplianceReport");
            rep.set("payrollComplianceReportId", repId);
            rep.set("organizationPartyId", orgId);
            rep.set("reportTypeId", type);
            rep.set("periodYear", y);
            rep.set("periodMonth", m);
            rep.set("generatedDate", UtilDateTime.nowTimestamp());
            rep.set("generatedByUserLoginId", u != null ? u.getString("userLoginId") : null);
            rep.set("statusId", "REP_NEW");
            d.create(rep);

            BigDecimal totalTax = BigDecimal.ZERO;

            List<GenericValue> items = EntityQuery.use(d)
                    .from("PayrollItem")
                    .where("organizationPartyId", orgId,
                           "periodYear", y,
                           "periodMonth", m)
                    .queryList();

            for (GenericValue it : items) {
                BigDecimal tax = it.getBigDecimal("taxAmount");
                if (tax != null) totalTax = totalTax.add(tax);
            }

            GenericValue line = d.makeValue("PayrollComplianceReportLine");
            line.set("payrollComplianceReportLineId", d.getNextSeqId("PayrollComplianceReportLine"));
            line.set("payrollComplianceReportId", repId);
            line.set("metricTypeId", "TAX");
            line.set("amount", totalTax);
            d.create(line);

            return UtilMisc.toMap("responseMessage", "success", "payrollComplianceReportId", repId);

        } catch (Exception e) {
            return ServiceUtil.returnError("Error generating compliance report: " + e.getMessage());
        }
    }
}
