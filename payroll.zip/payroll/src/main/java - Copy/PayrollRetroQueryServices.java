package org.apache.ofbiz.payroll;

import org.apache.ofbiz.base.util.*;
import org.apache.ofbiz.entity.*;
import org.apache.ofbiz.entity.condition.*;
import org.apache.ofbiz.entity.util.EntityQuery;
import org.apache.ofbiz.service.*;

import java.util.*;

public class PayrollRetroQueryServices {
    public static final String MODULE = PayrollRetroQueryServices.class.getName();

  public static Map<String, Object> getPayrollRetroDeltaList(DispatchContext dctx, Map<String, ?> context) {
    Delegator delegator = dctx.getDelegator();
    try {
        String batchId = (String) context.get("payrollRetroBatchId");
        if (UtilValidate.isEmpty(batchId)) {
            return ServiceUtil.returnError("payrollRetroBatchId is required");
        }

        List<GenericValue> list = EntityQuery.use(delegator)
                .from("PayrollRetroDelta")
                .where("payrollRetroBatchId", batchId)
                .orderBy("partyId", "lineTypeId")
                .queryList();

        Map<String, Object> out = ServiceUtil.returnSuccess();
        out.put("list", list);
        return out;

    } catch (Exception e) {
        Debug.logError(e, "getPayrollRetroDeltaList failed", MODULE);
        return ServiceUtil.returnError("getPayrollRetroDeltaList failed: " + e.getMessage());
    }
}



}
