package org.apache.ofbiz.payroll;

import org.apache.ofbiz.service.*;
import org.apache.ofbiz.base.util.*;
import java.util.*;

public class PayrollRestServices {

    /* ===================================================== */
    /* REST → Internal Service Delegation                     */
    /* ===================================================== */

    public static Map<String, Object> createPayrollAssignmentRest(
            DispatchContext dctx, Map<String, ?> context) {

        return dctx.getDispatcher().runSync(
                "createEmployeePayrollAssignment",
                context
        );
    }

    public static Map<String, Object> processPayrollRunRest(
            DispatchContext dctx, Map<String, ?> context) {

        return dctx.getDispatcher().runSync(
                "processPayrollRun",
                context
        );
    }

    public static Map<String, Object> approvePayrollRunRest(
            DispatchContext dctx, Map<String, ?> context) {

        return dctx.getDispatcher().runSync(
                "approvePayrollRun",
                context
        );
    }

    public static Map<String, Object> generatePayslipPdfRest(
            DispatchContext dctx, Map<String, ?> context) {

        return dctx.getDispatcher().runSync(
                "generatePayslipPdf",
                context
        );
    }
}
