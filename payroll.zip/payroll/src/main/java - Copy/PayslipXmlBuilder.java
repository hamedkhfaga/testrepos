package org.apache.ofbiz.payroll.export;

import org.apache.ofbiz.payroll.export.PayrollExportServices.ExportPayload;

public final class PayslipXmlBuilder {

    private PayslipXmlBuilder() {}

    public static String build(ExportPayload p,
                               String code128Value, String code128Url,
                               String qrText, String qrUrl) {
        StringBuilder sb = new StringBuilder(4096);
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
        sb.append("<payslip>");

        sb.append(tag("orgPartyId", p.orgPartyId));
        sb.append(tag("payrollRunId", p.payrollRunId));
        sb.append(tag("payrollResultId", p.payrollResultId));
        sb.append(tag("partyId", p.partyId));
        sb.append(tag("employeeName", p.employeeName));
        sb.append(tag("currencyUomId", p.currencyUomId));

        sb.append("<totals>");
        sb.append(tag("grossSalary", safe(p.grossSalary)));
        sb.append(tag("totalDeductions", safe(p.totalDeductions)));
        sb.append(tag("netSalary", safe(p.netSalary)));
        sb.append("</totals>");

        sb.append("<barcode>");
        sb.append(tag("code128Value", code128Value));
        sb.append(tag("code128Url", code128Url));
        sb.append(tag("qrText", qrText));
        sb.append(tag("qrUrl", qrUrl));
        sb.append("</barcode>");

        sb.append("<lines>");
        if (p.resultLines != null) {
            for (var l : p.resultLines) {
                sb.append("<line>");
                sb.append(tag("lineTypeId", l.getString("lineTypeId")));
                sb.append(tag("description", l.getString("description")));
                sb.append(tag("amount", String.valueOf(l.get("amount"))));
                String curr = l.getString("currencyUomId") != null ? l.getString("currencyUomId") : p.currencyUomId;
                sb.append(tag("currencyUomId", curr));
                sb.append("</line>");
            }
        }
        sb.append("</lines>");

        sb.append("</payslip>");
        return sb.toString();
    }

    private static String tag(String name, String val) {
        return "<" + name + ">" + xmlEsc(val) + "</" + name + ">";
    }

    private static String xmlEsc(String s) {
        if (s == null) return "";
        return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")
                .replace("\"","&quot;").replace("'","&apos;");
    }

    private static String safe(Object o) {
        return o == null ? "0" : String.valueOf(o);
    }
}
