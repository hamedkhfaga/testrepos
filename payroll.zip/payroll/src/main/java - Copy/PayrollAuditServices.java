package org.apache.ofbiz.payroll.services;

import org.apache.ofbiz.base.util.Debug;
import org.apache.ofbiz.base.util.UtilDateTime;

import org.apache.ofbiz.entity.Delegator;
import org.apache.ofbiz.entity.GenericValue;

public class PayrollAuditServices {
    public static final String MODULE = PayrollAuditServices.class.getName();

    /**
     * Writes PayrollAuditEvent (preferred) if exists, else PayrollAuditLog if exists.
     */
    public static void logEvent(
            Delegator delegator,
            String organizationPartyId,
            String eventTypeId,
            String entityName,
            String recordId,
            String oldValue,
            String newValue,
            GenericValue userLogin,
            String sourceIp
    ) {
        try {
            if (delegator.getModelEntity("PayrollAuditEvent") != null) {
                GenericValue ev = delegator.makeValue("PayrollAuditEvent");
                ev.set("payrollAuditEventId", delegator.getNextSeqId("PayrollAuditEvent"));
                ev.set("organizationPartyId", organizationPartyId);
                ev.set("eventTypeId", eventTypeId);
                ev.set("entityName", entityName);
                ev.set("recordId", recordId);
                ev.set("oldValue", oldValue);
                ev.set("newValue", newValue);
                ev.set("eventDate", UtilDateTime.nowTimestamp());
                ev.set("userLoginId", userLogin == null ? null : userLogin.getString("userLoginId"));
                ev.set("sourceIp", sourceIp);
                ev.create();
                return;
            }

            if (delegator.getModelEntity("PayrollAuditLog") != null) {
                GenericValue aud = delegator.makeValue("PayrollAuditLog");
                aud.set("payrollAuditLogId", delegator.getNextSeqId("PayrollAuditLog"));
                aud.set("organizationPartyId", organizationPartyId);
                aud.set("entityName", entityName);
                aud.set("recordId", recordId);
                aud.set("actionTypeId", eventTypeId);
                aud.set("oldValuesJson", oldValue);
                aud.set("newValuesJson", newValue);
                aud.set("changedByUserLoginId", userLogin == null ? null : userLogin.getString("userLoginId"));
                aud.set("changedDate", UtilDateTime.nowTimestamp());
                aud.set("ipAddress", sourceIp);
                aud.create();
            }
        } catch (Exception e) {
            Debug.logWarning(e, "Payroll audit insert failed (non-fatal)", MODULE);
        }
    }
}
