package org.apache.ofbiz.payroll;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.*;
import java.util.stream.Collectors;

import org.apache.ofbiz.base.util.Debug;
import org.apache.ofbiz.base.util.UtilDateTime;
import org.apache.ofbiz.base.util.UtilValidate;

import org.apache.ofbiz.entity.*;
import org.apache.ofbiz.entity.condition.*;
import org.apache.ofbiz.entity.util.EntityQuery;

import org.apache.ofbiz.service.DispatchContext;
import org.apache.ofbiz.service.ServiceUtil;

import org.apache.ofbiz.entity.transaction.TransactionUtil;

public final class PayrollProcessingServices {
    public static final String MODULE = PayrollProcessingServices.class.getName();

    // Choose your real status IDs (StatusItem)
    private static final String RUN_STATUS_DRAFT = "PAYRUN_DRAFT";
    private static final String RUN_STATUS_PROCESSED = "PAYRUN_PROCESSED";
    private static final String RUN_STATUS_APPROVED = "PAYRUN_APPROVED";

    private static final String LINE_BASIC = "BASIC";
    private static final String LINE_ALLOW = "ALLOW";
    private static final String LINE_DEDUCT = "DEDUCT";
    private static final String LINE_LOAN = "LOAN";
    private static final String LINE_NET = "NET";

    private PayrollProcessingServices() {}

    public static Map<String, Object> createPayrollRun(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();

        String orgPartyId = (String) context.get("orgPartyId");
        String payrollPeriodId = (String) context.get("payrollPeriodId");
        String currencyUomId = (String) context.get("currencyUomId");
        String runName = (String) context.get("runName");
        String runTypeId = (String) context.get("runTypeId");
        String accountingPostOptionId = (String) context.get("accountingPostOptionId");

        if (UtilValidate.isEmpty(orgPartyId)) return ServiceUtil.returnError("orgPartyId is required");
        if (UtilValidate.isEmpty(payrollPeriodId)) return ServiceUtil.returnError("payrollPeriodId is required");

        try {
            GenericValue period = EntityQuery.use(delegator).from("PayrollPeriod")
                    .where("payrollPeriodId", payrollPeriodId, "orgPartyId", orgPartyId)
                    .queryOne();
            if (period == null) return ServiceUtil.returnError("PayrollPeriod not found for orgPartyId=" + orgPartyId + " payrollPeriodId=" + payrollPeriodId);

            Timestamp now = UtilDateTime.nowTimestamp();
            String payrollRunId = delegator.getNextSeqId("PayrollRun");

            GenericValue run = delegator.makeValue("PayrollRun");
            run.set("payrollRunId", payrollRunId);
            run.set("orgPartyId", orgPartyId);
            run.set("payrollPeriodId", payrollPeriodId);
            run.set("runDate", now);
            run.set("currencyUomId", currencyUomId != null ? currencyUomId : period.getString("currencyUomId")); // if you store on period
            run.set("runName", UtilValidate.isNotEmpty(runName) ? runName : ("Payroll " + payrollPeriodId));
            run.set("runTypeId", runTypeId);
            run.set("statusId", RUN_STATUS_DRAFT);
            run.set("createdByUserLoginId", ((GenericValue) context.get("userLogin")).getString("userLoginId"));
            run.set("createdDate", now);
            if (UtilValidate.isNotEmpty(accountingPostOptionId)) {
                run.set("accountingPostOptionId", accountingPostOptionId);
            }

            delegator.create(run);

            Map<String, Object> result = ServiceUtil.returnSuccess();
            result.put("payrollRunId", payrollRunId);
            return result;

        } catch (Exception e) {
            Debug.logError(e, "createPayrollRun failed", MODULE);
            return ServiceUtil.returnError("createPayrollRun failed: " + e.getMessage());
        }
    }

    public static Map<String, Object> processPayrollSalaries(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();

        String payrollRunId = (String) context.get("payrollRunId");
        Boolean forceReprocess = (Boolean) context.get("forceReprocess");
        if (forceReprocess == null) forceReprocess = Boolean.FALSE;

        if (UtilValidate.isEmpty(payrollRunId)) return ServiceUtil.returnError("payrollRunId is required");

        boolean beganTx = false;
        try {
            beganTx = TransactionUtil.begin();

            GenericValue run = EntityQuery.use(delegator).from("PayrollRun")
                    .where("payrollRunId", payrollRunId)
                    .queryOne();
            if (run == null) return ServiceUtil.returnError("PayrollRun not found: " + payrollRunId);

            String orgPartyId = run.getString("orgPartyId");
            String payrollPeriodId = run.getString("payrollPeriodId");
            GenericValue period = EntityQuery.use(delegator).from("PayrollPeriod")
                    .where("payrollPeriodId", payrollPeriodId, "orgPartyId", orgPartyId)
                    .queryOne();
            if (period == null) return ServiceUtil.returnError("PayrollPeriod not found for run: " + payrollPeriodId);

            // If already processed, allow reprocess only by force
            if (!forceReprocess && RUN_STATUS_PROCESSED.equals(run.getString("statusId"))) {
                return ServiceUtil.returnSuccess("Already processed; set forceReprocess=Y to rebuild results.");
            }
            if (RUN_STATUS_APPROVED.equals(run.getString("statusId"))) {
                return ServiceUtil.returnError("Cannot process: PayrollRun is approved/locked.");
            }

            Timestamp periodEndTs = UtilDateTime.toTimestamp(period.getDate("endDate"));
            if (periodEndTs == null) periodEndTs = UtilDateTime.nowTimestamp();

            // Optional cleanup on force
            if (forceReprocess) {
                removeExistingResults(delegator, payrollRunId);
            }

            // Load assignments active at period end
            List<GenericValue> assignments = EntityQuery.use(delegator)
                    .from("EmployeePayrollAssignment")
                    .where("orgPartyId", orgPartyId)
                    .queryList()
                    .stream()
                    .filter(a -> isActiveOn(a.getTimestamp("effectiveDate"), a.getTimestamp("thruDate"), periodEndTs))
                    .collect(Collectors.toList());

            BigDecimal totalGross = BigDecimal.ZERO;
            BigDecimal totalDeduct = BigDecimal.ZERO;
            BigDecimal totalNet = BigDecimal.ZERO;

            for (GenericValue a : assignments) {
                String partyId = a.getString("partyId");

                BigDecimal basic = nvl(a.getBigDecimal("baseSalary"));
                BigDecimal allowTotal = sumEmployeeAllowances(delegator, orgPartyId, partyId, periodEndTs);
                BigDecimal deductTotal = sumEmployeeDeductions(delegator, orgPartyId, partyId, periodEndTs);
                BigDecimal loanTotal = sumEmployeeLoanDeductions(delegator, orgPartyId, partyId, periodEndTs);

                BigDecimal gross = basic.add(allowTotal);
                BigDecimal deductions = deductTotal.add(loanTotal);
                BigDecimal net = gross.subtract(deductions);

                String payrollResultId = delegator.getNextSeqId("EmployeePayrollResult");

                GenericValue res = delegator.makeValue("EmployeePayrollResult");
                res.set("payrollResultId", payrollResultId);
                res.set("payrollRunId", payrollRunId);
                res.set("orgPartyId", orgPartyId);
                res.set("partyId", partyId);

                res.set("basicSalary", basic);
                res.set("allowancesTotal", allowTotal);
                res.set("grossSalary", gross);

                res.set("otherDeductions", deductTotal);
                res.set("loanDeductions", loanTotal);
                res.set("totalDeductions", deductions);

                res.set("netSalary", net);

                res.set("currencyUomId", run.getString("currencyUomId"));
                res.set("versionNumber", Long.valueOf(1));
                res.set("statusId", "PAYRES_GEN"); // choose your StatusItem

                delegator.create(res);

                // Lines (world-class: lines are the audit trail)
                createResultLine(delegator, payrollResultId, LINE_BASIC, "Basic Salary", basic, run.getString("currencyUomId"), 10);
                if (allowTotal.signum() != 0) createResultLine(delegator, payrollResultId, LINE_ALLOW, "Allowances", allowTotal, run.getString("currencyUomId"), 20);
                if (deductTotal.signum() != 0) createResultLine(delegator, payrollResultId, LINE_DEDUCT, "Deductions", deductTotal.negate(), run.getString("currencyUomId"), 30);
                if (loanTotal.signum() != 0) createResultLine(delegator, payrollResultId, LINE_LOAN, "Loan Deductions", loanTotal.negate(), run.getString("currencyUomId"), 40);
                createResultLine(delegator, payrollResultId, LINE_NET, "Net Pay", net, run.getString("currencyUomId"), 90);

                totalGross = totalGross.add(gross);
                totalDeduct = totalDeduct.add(deductions);
                totalNet = totalNet.add(net);
            }

            run.set("totalEmployees", Long.valueOf(assignments.size()));
            run.set("totalGrossPay", totalGross);
            run.set("totalDeductions", totalDeduct);
            run.set("totalNetPay", totalNet);
            run.set("statusId", RUN_STATUS_PROCESSED);
            delegator.store(run);

            TransactionUtil.commit(beganTx);
            return ServiceUtil.returnSuccess("Payroll processed: " + assignments.size() + " employees.");

        } catch (Exception e) {
            Debug.logError(e, "processPayrollSalaries failed", MODULE);
            try { TransactionUtil.rollback(beganTx, e.getMessage(), e); } catch (Exception ignored) {}
            return ServiceUtil.returnError("processPayrollSalaries failed: " + e.getMessage());
        }
    }

    public static Map<String, Object> approvePayrollRun(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        String payrollRunId = (String) context.get("payrollRunId");
        GenericValue userLogin = (GenericValue) context.get("userLogin");

        if (UtilValidate.isEmpty(payrollRunId)) return ServiceUtil.returnError("payrollRunId is required");

        boolean beganTx = false;
        try {
            beganTx = TransactionUtil.begin();

            GenericValue run = EntityQuery.use(delegator).from("PayrollRun")
                    .where("payrollRunId", payrollRunId)
                    .queryOne();
            if (run == null) return ServiceUtil.returnError("PayrollRun not found: " + payrollRunId);

            if (!RUN_STATUS_PROCESSED.equals(run.getString("statusId"))) {
                return ServiceUtil.returnError("PayrollRun must be PROCESSED before approval.");
            }

            run.set("statusId", RUN_STATUS_APPROVED);
            run.set("approvedByUserLoginId", userLogin.getString("userLoginId"));
            run.set("approvedDate", UtilDateTime.nowTimestamp());
            delegator.store(run);

            TransactionUtil.commit(beganTx);
            return ServiceUtil.returnSuccess("PayrollRun approved.");

        } catch (Exception e) {
            Debug.logError(e, "approvePayrollRun failed", MODULE);
            try { TransactionUtil.rollback(beganTx, e.getMessage(), e); } catch (Exception ignored) {}
            return ServiceUtil.returnError("approvePayrollRun failed: " + e.getMessage());
        }
    }

    // ---------------- Helpers ----------------

    private static void removeExistingResults(Delegator delegator, String payrollRunId) throws GenericEntityException {
        List<GenericValue> results = EntityQuery.use(delegator).from("EmployeePayrollResult")
                .where("payrollRunId", payrollRunId).queryList();
        for (GenericValue r : results) {
            List<GenericValue> lines = EntityQuery.use(delegator).from("EmployeePayrollResultLine")
                    .where("payrollResultId", r.getString("payrollResultId")).queryList();
            for (GenericValue l : lines) delegator.removeValue(l);
            delegator.removeValue(r);
        }
    }

    private static void createResultLine(Delegator delegator, String payrollResultId, String lineTypeId,
                                         String desc, BigDecimal amount, String currencyUomId, long seq) throws GenericEntityException {
        String lineId = delegator.getNextSeqId("EmployeePayrollResultLine");
        GenericValue line = delegator.makeValue("EmployeePayrollResultLine");
        line.set("resultLineId", lineId);
        line.set("payrollResultId", payrollResultId);
        line.set("lineTypeId", lineTypeId);
        line.set("description", desc);
        line.set("amount", amount);
        line.set("currencyUomId", currencyUomId);
        line.set("sequenceNum", seq);
        delegator.create(line);
    }

    private static boolean isActiveOn(Timestamp from, Timestamp thru, Timestamp on) {
        if (from != null && from.after(on)) return false;
        if (thru != null && !thru.after(on)) return false;
        return true;
    }

    private static BigDecimal nvl(BigDecimal v) { return v == null ? BigDecimal.ZERO : v; }

    private static BigDecimal sumEmployeeAllowances(Delegator delegator, String orgPartyId, String partyId, Timestamp on) throws GenericEntityException {
        List<GenericValue> list = EntityQuery.use(delegator).from("EmployeeAllowance")
                .where("orgPartyId", orgPartyId, "partyId", partyId, "statusId", "ACTIVE")
                .queryList();
        BigDecimal sum = BigDecimal.ZERO;
        for (GenericValue gv : list) {
            if (isActiveOn(gv.getTimestamp("effectiveDate"), gv.getTimestamp("thruDate"), on)) {
                sum = sum.add(nvl(gv.getBigDecimal("amount")));
            }
        }
        return sum;
    }

    private static BigDecimal sumEmployeeDeductions(Delegator delegator, String orgPartyId, String partyId, Timestamp on) throws GenericEntityException {
        List<GenericValue> list = EntityQuery.use(delegator).from("EmployeeDeduction")
                .where("orgPartyId", orgPartyId, "partyId", partyId, "statusId", "ACTIVE")
                .queryList();
        BigDecimal sum = BigDecimal.ZERO;
        for (GenericValue gv : list) {
            if (isActiveOn(gv.getTimestamp("effectiveDate"), gv.getTimestamp("thruDate"), on)) {
                sum = sum.add(nvl(gv.getBigDecimal("amount")));
            }
        }
        return sum;
    }

    private static BigDecimal sumEmployeeLoanDeductions(Delegator delegator, String orgPartyId, String partyId, Timestamp on) throws GenericEntityException {
        // Simple version: if you have LoanInstallment schedule, sum due installments in period.
        // For now: use EmployeeLoan.monthlyInstallment for active loans.
        List<GenericValue> loans = EntityQuery.use(delegator).from("EmployeeLoan")
                .where("orgPartyId", orgPartyId, "partyId", partyId, "statusId", "ACTIVE")
                .queryList();
        BigDecimal sum = BigDecimal.ZERO;
        for (GenericValue l : loans) {
            if (isActiveOn(l.getTimestamp("startDate"), l.getTimestamp("endDate"), on)) {
                sum = sum.add(nvl(l.getBigDecimal("monthlyInstallment")));
            }
        }
        return sum;
    }
}
