package org.apache.ofbiz.payroll.export;

import org.apache.fop.apps.*;
import org.apache.ofbiz.payroll.export.PayrollExportServices.ExportPayload;
import org.apache.ofbiz.payroll.export.PayrollExportServices.GeneratedFile;

import javax.xml.transform.*;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.stream.*;
import java.io.*;
import java.nio.charset.StandardCharsets;

public final class PayslipPdfFop {

    private PayslipPdfFop() {}

    public static GeneratedFile generate(ExportPayload p, String code128Value, String qrText) throws Exception {
        // 1) Generate barcode PNGs for FOP
        byte[] codePng = BarcodeUtil.buildCode128Png(code128Value, 420, 120);
        String codePath = BarcodeUtil.writeTempFile(codePng, "code128_" + p.payrollResultId + ".png", "payroll");

        byte[] qrPng = BarcodeUtil.buildQrPng(qrText, 220);
        String qrPath = BarcodeUtil.writeTempFile(qrPng, "qr_" + p.payrollResultId + ".png", "payroll");

        String codeUrl = FopBarcodeAssets.toFileUrl(codePath);
        String qrUrl = FopBarcodeAssets.toFileUrl(qrPath);

        // 2) Build XML
        String xml = PayslipXmlBuilder.build(p, code128Value, codeUrl, qrText, qrUrl);

        // 3) Transform XML -> FO via XSL (payslip-fo.xsl)
        String ofbizHome = System.getProperty("ofbiz.home");
        String xslPath = ofbizHome + "/plugins/payroll/config/payroll/payslip-fo.xsl";
        String fo = transformXmlToFo(xml, xslPath);

        // 4) FO -> PDF
        ByteArrayOutputStream baos = new ByteArrayOutputStream();

        FopFactory fopFactory = FopFactory.newInstance(new File(ofbizHome).toURI());
        FOUserAgent ua = fopFactory.newFOUserAgent();

        Fop fop = fopFactory.newFop(MimeConstants.MIME_PDF, ua, baos);

        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer identity = tf.newTransformer();
        Source src = new StreamSource(new ByteArrayInputStream(fo.getBytes(StandardCharsets.UTF_8)));
        Result res = new SAXResult(fop.getDefaultHandler());
        identity.transform(src, res);

        byte[] pdf = baos.toByteArray();
        return GeneratedFile.of("payslip_" + p.payrollResultId + ".pdf", "application/pdf", pdf);
    }

    private static String transformXmlToFo(String xml, String xslPath) throws Exception {
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer t = tf.newTransformer(new StreamSource(new File(xslPath)));

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        t.transform(
                new StreamSource(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8))),
                new StreamResult(out)
        );
        return out.toString(StandardCharsets.UTF_8);
    }
}
