package org.apache.ofbiz.payroll.services;

import org.apache.ofbiz.base.util.Debug;
import org.apache.ofbiz.base.util.UtilDateTime;
import org.apache.ofbiz.base.util.UtilValidate;

import org.apache.ofbiz.entity.Delegator;
import org.apache.ofbiz.entity.GenericEntityException;
import org.apache.ofbiz.entity.GenericValue;
import org.apache.ofbiz.entity.model.ModelEntity;
import org.apache.ofbiz.entity.model.ModelField;
import org.apache.ofbiz.entity.util.EntityQuery;
import org.apache.ofbiz.entity.util.EntityFindOptions;

import org.apache.ofbiz.service.DispatchContext;
import org.apache.ofbiz.service.ServiceUtil;

import java.util.*;
import java.util.stream.Collectors;

public class PayrollCrudServices {
    public static final String MODULE = PayrollCrudServices.class.getName();

    /**
     * Allowlist of payroll entities allowed via generic CRUD.
     * This prevents someone calling payrollCreateEntity for "UserLogin" etc.
     */
    private static final Set<String> ALLOWED_ENTITIES = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(
            "PayrollOrganization",
            "PayrollCurrencyRate",
            "PayrollStructure",
            "EmployeePayrollAssignment",
            "InternationalEmployeeInfo",
            "OvertimePolicy",
            "HrPolicySet",
            "HrPolicy",
            "PayrollTaxConfig",
            "SocialSecurityConfig",
            "EmployeeTaxProfile",
            "AllowanceType",
            "EmployeeAllowance",
            "DeductionType",
            "EmployeeDeduction",
            "EmployeeLoan",
            "LoanInstallment",
            "PayrollPeriod",
            "PayrollRun",
            "EmployeePayrollResult",
            "EmployeePayrollResultLine",
            "EmployeeTaxDetail",
            "EmployeeYTDSummary",
            "PayrollExportRequest",
            "PayrollExportFile",
            "PayslipBarcode",
            "PayslipDelivery",
            "PayrollEmailQueue",
            "PayrollSmsQueue",
            "BankTransferConfig",
            "BankTransferBatch",
            "BankTransferBatchLine",
            "PayrollAuditLog",
            "EmployeeDocumentAccess"
    )));

    private static boolean hasOrgField(ModelEntity me) {
        return me != null && me.getField("orgPartyId") != null;
    }

    private static void assertAllowedEntity(String entityName) throws IllegalArgumentException {
        if (UtilValidate.isEmpty(entityName) || !ALLOWED_ENTITIES.contains(entityName)) {
            throw new IllegalArgumentException("Entity not allowed for payroll generic CRUD: " + entityName);
        }
    }

    private static Map<String, Object> sanitizeFields(Delegator delegator, String entityName, Map<String, ?> raw) throws GenericEntityException {
        ModelEntity me = delegator.getModelEntity(entityName);
        if (me == null) {
            throw new GenericEntityException("Unknown entity: " + entityName);
        }
        Map<String, Object> out = new HashMap<>();
        if (raw == null) return out;

        for (Map.Entry<String, ?> e : raw.entrySet()) {
            String fieldName = e.getKey();
            Object value = e.getValue();

            ModelField mf = me.getField(fieldName);
            if (mf == null) continue; // ignore unknown fields silently (safer for generic API)

            // prevent overriding OFBiz audit stamps manually unless you intentionally want that
            if ("createdStamp".equals(fieldName) || "createdTxStamp".equals(fieldName)
                    || "lastUpdatedStamp".equals(fieldName) || "lastUpdatedTxStamp".equals(fieldName)) {
                continue;
            }
            out.put(fieldName, value);
        }
        return out;
    }

    private static void enforceOrgScope(Delegator delegator, String entityName, String orgPartyId, Map<String, Object> fieldsOrPk) throws GenericEntityException {
        ModelEntity me = delegator.getModelEntity(entityName);
        if (me == null) return;

        if (hasOrgField(me)) {
            if (UtilValidate.isEmpty(orgPartyId)) {
                throw new GenericEntityException("orgPartyId is required for entity " + entityName);
            }
            // Force orgPartyId to the passed orgPartyId (cannot be overridden)
            fieldsOrPk.put("orgPartyId", orgPartyId);
        }
    }

    private static GenericValue findOneStrict(Delegator delegator, String entityName, Map<String, Object> pk) throws GenericEntityException {
        GenericValue gv = EntityQuery.use(delegator)
                .from(entityName)
                .where(pk)
                .queryOne();
        if (gv == null) {
            throw new GenericEntityException("Record not found: " + entityName + " pk=" + pk);
        }
        return gv;
    }

    public static Map<String, Object> createEntity(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        Map<String, Object> result = ServiceUtil.returnSuccess();

        try {
            String entityName = (String) context.get("entityName");
            String orgPartyId = (String) context.get("orgPartyId");
            Map<String, ?> fieldsRaw = (Map<String, ?>) context.get("fields");

            assertAllowedEntity(entityName);

            Map<String, Object> fields = sanitizeFields(delegator, entityName, fieldsRaw);
            enforceOrgScope(delegator, entityName, orgPartyId, fields);

            GenericValue value = delegator.makeValue(entityName, fields);

            // Ensure PK exists if not auto-generated by your service layer:
            // In OFBiz, id fields are often generated in services. Here we do it generically:
            ModelEntity me = delegator.getModelEntity(entityName);
            List<String> pkFields = me.getPkFieldNames();
            if (pkFields.size() == 1) {
                String pkField = pkFields.get(0);
                if (UtilValidate.isEmpty(value.get(pkField))) {
                    // generate a sequenced id
                    String seqId = delegator.getNextSeqId(entityName);
                    value.set(pkField, seqId);
                    result.put("resultId", seqId);
                } else {
                    result.put("resultId", String.valueOf(value.get(pkField)));
                }
            }

            value.create();
            return result;

        } catch (Exception e) {
            Debug.logError(e, MODULE);
            return ServiceUtil.returnError("payrollCreateEntity failed: " + e.getMessage());
        }
    }

    public static Map<String, Object> updateEntity(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();

        try {
            String entityName = (String) context.get("entityName");
            String orgPartyId = (String) context.get("orgPartyId");
            Map<String, ?> pkRaw = (Map<String, ?>) context.get("pk");
            Map<String, ?> fieldsRaw = (Map<String, ?>) context.get("fields");

            assertAllowedEntity(entityName);

            Map<String, Object> pk = new HashMap<>();
            if (pkRaw != null) pk.putAll((Map) pkRaw);
            enforceOrgScope(delegator, entityName, orgPartyId, pk);

            GenericValue existing = findOneStrict(delegator, entityName, pk);

            Map<String, Object> fields = sanitizeFields(delegator, entityName, fieldsRaw);
            // never allow changing orgPartyId
            if (fields.containsKey("orgPartyId")) fields.remove("orgPartyId");

            existing.setNonPKFields(fields);
            existing.store();

            return ServiceUtil.returnSuccess();
        } catch (Exception e) {
            Debug.logError(e, MODULE);
            return ServiceUtil.returnError("payrollUpdateEntity failed: " + e.getMessage());
        }
    }

    public static Map<String, Object> deleteEntity(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();

        try {
            String entityName = (String) context.get("entityName");
            String orgPartyId = (String) context.get("orgPartyId");
            Map<String, ?> pkRaw = (Map<String, ?>) context.get("pk");

            assertAllowedEntity(entityName);

            Map<String, Object> pk = new HashMap<>();
            if (pkRaw != null) pk.putAll((Map) pkRaw);
            enforceOrgScope(delegator, entityName, orgPartyId, pk);

            GenericValue existing = findOneStrict(delegator, entityName, pk);
            existing.remove();

            return ServiceUtil.returnSuccess();
        } catch (Exception e) {
            Debug.logError(e, MODULE);
            return ServiceUtil.returnError("payrollDeleteEntity failed: " + e.getMessage());
        }
    }

    public static Map<String, Object> findOne(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        Map<String, Object> out = ServiceUtil.returnSuccess();

        try {
            String entityName = (String) context.get("entityName");
            String orgPartyId = (String) context.get("orgPartyId");
            Map<String, ?> pkRaw = (Map<String, ?>) context.get("pk");

            assertAllowedEntity(entityName);

            Map<String, Object> pk = new HashMap<>();
            if (pkRaw != null) pk.putAll((Map) pkRaw);
            enforceOrgScope(delegator, entityName, orgPartyId, pk);

            GenericValue existing = findOneStrict(delegator, entityName, pk);
            out.put("record", existing.getAllFields());
            return out;

        } catch (Exception e) {
            Debug.logError(e, MODULE);
            return ServiceUtil.returnError("payrollFindOne failed: " + e.getMessage());
        }
    }

    public static Map<String, Object> list(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        Map<String, Object> out = ServiceUtil.returnSuccess();

        try {
            String entityName = (String) context.get("entityName");
            String orgPartyId = (String) context.get("orgPartyId");
            Map<String, ?> filtersRaw = (Map<String, ?>) context.get("filters");
            List<String> orderBy = (List<String>) context.get("orderBy");
            Integer viewIndex = (Integer) context.get("viewIndex");
            Integer viewSize = (Integer) context.get("viewSize");

            assertAllowedEntity(entityName);

            ModelEntity me = delegator.getModelEntity(entityName);
            Map<String, Object> filters = sanitizeFields(delegator, entityName, filtersRaw);
            if (filters == null) filters = new HashMap<>();

            // enforce org scope for list queries too
            if (hasOrgField(me)) {
                if (UtilValidate.isEmpty(orgPartyId)) {
                    return ServiceUtil.returnError("orgPartyId is required for list on " + entityName);
                }
                filters.put("orgPartyId", orgPartyId);
            }

            int idx = (viewIndex != null && viewIndex >= 0) ? viewIndex : 0;
            int size = (viewSize != null && viewSize > 0) ? viewSize : 50;

            EntityFindOptions efo = new EntityFindOptions();
            efo.setMaxRows(size);
            efo.setOffset(idx * size);

            long total = EntityQuery.use(delegator)
                    .from(entityName)
                    .where(filters)
                    .queryCount();

            List<GenericValue> list = EntityQuery.use(delegator)
                    .from(entityName)
                    .where(filters)
                    .orderBy(orderBy)
                    .cursorScrollInsensitive()
                    .distinct(false)
                    .queryList(efo);

            List<Map<String, Object>> records = list.stream()
                    .map(GenericValue::getAllFields)
                    .collect(Collectors.toList());

            out.put("records", records);
            out.put("totalCount", total);
            return out;

        } catch (Exception e) {
            Debug.logError(e, MODULE);
            return ServiceUtil.returnError("payrollList failed: " + e.getMessage());
        }
    }
}
