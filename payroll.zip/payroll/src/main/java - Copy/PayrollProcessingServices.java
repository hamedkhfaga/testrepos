package org.apache.ofbiz.payroll.services;

import org.apache.ofbiz.base.util.Debug;
import org.apache.ofbiz.base.util.UtilDateTime;
import org.apache.ofbiz.base.util.UtilMisc;
import org.apache.ofbiz.base.util.UtilValidate;

import org.apache.ofbiz.entity.*;
import org.apache.ofbiz.entity.condition.*;
import org.apache.ofbiz.entity.util.EntityQuery;

import org.apache.ofbiz.service.DispatchContext;
import org.apache.ofbiz.service.ServiceUtil;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Timestamp;
import java.util.*;
/* 
PayrollProcessingServices.java (process salaries end-to-end)

This is the “engine” that:

loads active assignments in period

calculates basic salary + allowances + deductions + loan installments

calculates tax + social security (using your config tables)

writes EmployeePayrollResult + EmployeePayrollResultLine + EmployeeTaxDetail

updates EmployeeYTDSummary

updates totals in PayrollRun

Create file:
*/
public class PayrollProcessingServices {
    public static final String MODULE = PayrollProcessingServices.class.getName();

    // Line types (create as StatusItem under PAY_LINE_TYPE)
    private static final String LINE_BASIC = "PAY_LINE_BASIC";
    private static final String LINE_ALLOWANCE = "PAY_LINE_ALLOWANCE";
    private static final String LINE_DEDUCTION = "PAY_LINE_DEDUCTION";
    private static final String LINE_LOAN = "PAY_LINE_LOAN";
    private static final String LINE_TAX = "PAY_LINE_TAX";
    private static final String LINE_SS = "PAY_LINE_SS";
    private static final String LINE_NET = "PAY_LINE_NET";

    private static BigDecimal bd(Object v) {
        if (v == null) return BigDecimal.ZERO;
        if (v instanceof BigDecimal) return (BigDecimal) v;
        if (v instanceof Double) return BigDecimal.valueOf((Double) v);
        if (v instanceof Long) return BigDecimal.valueOf((Long) v);
        if (v instanceof Integer) return BigDecimal.valueOf((Integer) v);
        return new BigDecimal(String.valueOf(v));
    }

    private static Timestamp now() {
        return UtilDateTime.nowTimestamp();
    }

    private static GenericValue getRun(Delegator delegator, String orgPartyId, String payrollRunId) throws GenericEntityException {
        GenericValue run = EntityQuery.use(delegator)
                .from("PayrollRun")
                .where("payrollRunId", payrollRunId, "orgPartyId", orgPartyId)
                .queryOne();
        if (run == null) throw new GenericEntityException("PayrollRun not found: " + payrollRunId);
        return run;
    }

    private static GenericValue getPeriod(Delegator delegator, String orgPartyId, String payrollPeriodId) throws GenericEntityException {
        GenericValue p = EntityQuery.use(delegator)
                .from("PayrollPeriod")
                .where("payrollPeriodId", payrollPeriodId, "orgPartyId", orgPartyId)
                .queryOne();
        if (p == null) throw new GenericEntityException("PayrollPeriod not found: " + payrollPeriodId);
        return p;
    }

    private static List<GenericValue> getActiveAssignments(Delegator delegator, String orgPartyId, Timestamp periodStartTs, Timestamp periodEndTs) throws GenericEntityException {
        // active if effectiveDate <= periodEnd AND (thruDate is null OR thruDate >= periodStart)
        EntityCondition cond = EntityCondition.makeCondition(Arrays.asList(
                EntityCondition.makeCondition("orgPartyId", EntityOperator.EQUALS, orgPartyId),
                EntityCondition.makeCondition("effectiveDate", EntityOperator.LESS_THAN_EQUAL_TO, periodEndTs),
                EntityCondition.makeCondition(
                        EntityCondition.makeCondition("thruDate", EntityOperator.EQUALS, null),
                        EntityOperator.OR,
                        EntityCondition.makeCondition("thruDate", EntityOperator.GREATER_THAN_EQUAL_TO, periodStartTs)
                )
        ), EntityOperator.AND);

        return EntityQuery.use(delegator)
                .from("EmployeePayrollAssignment")
                .where(cond)
                .queryList();
    }

    private static BigDecimal sumEmployeeAllowances(Delegator delegator, String orgPartyId, String partyId, Timestamp periodStartTs, Timestamp periodEndTs) throws GenericEntityException {
        EntityCondition cond = EntityCondition.makeCondition(Arrays.asList(
                EntityCondition.makeCondition("orgPartyId", EntityOperator.EQUALS, orgPartyId),
                EntityCondition.makeCondition("partyId", EntityOperator.EQUALS, partyId),
                EntityCondition.makeCondition("effectiveDate", EntityOperator.LESS_THAN_EQUAL_TO, periodEndTs),
                EntityCondition.makeCondition(
                        EntityCondition.makeCondition("thruDate", EntityOperator.EQUALS, null),
                        EntityOperator.OR,
                        EntityCondition.makeCondition("thruDate", EntityOperator.GREATER_THAN_EQUAL_TO, periodStartTs)
                )
        ), EntityOperator.AND);

        List<GenericValue> rows = EntityQuery.use(delegator).from("EmployeeAllowance").where(cond).queryList();
        BigDecimal total = BigDecimal.ZERO;
        for (GenericValue r : rows) total = total.add(bd(r.get("amount")));
        return total;
    }

    private static BigDecimal sumEmployeeDeductions(Delegator delegator, String orgPartyId, String partyId, Timestamp periodStartTs, Timestamp periodEndTs) throws GenericEntityException {
        EntityCondition cond = EntityCondition.makeCondition(Arrays.asList(
                EntityCondition.makeCondition("orgPartyId", EntityOperator.EQUALS, orgPartyId),
                EntityCondition.makeCondition("partyId", EntityOperator.EQUALS, partyId),
                EntityCondition.makeCondition("effectiveDate", EntityOperator.LESS_THAN_EQUAL_TO, periodEndTs),
                EntityCondition.makeCondition(
                        EntityCondition.makeCondition("thruDate", EntityOperator.EQUALS, null),
                        EntityOperator.OR,
                        EntityCondition.makeCondition("thruDate", EntityOperator.GREATER_THAN_EQUAL_TO, periodStartTs)
                )
        ), EntityOperator.AND);

        List<GenericValue> rows = EntityQuery.use(delegator).from("EmployeeDeduction").where(cond).queryList();
        BigDecimal total = BigDecimal.ZERO;
        for (GenericValue r : rows) total = total.add(bd(r.get("amount")));
        return total;
    }

    private static BigDecimal sumLoanInstallmentsDue(Delegator delegator, String orgPartyId, String partyId, Timestamp periodStartTs, Timestamp periodEndTs) throws GenericEntityException {
        // join EmployeeLoan + LoanInstallment: dueDate in period, status not paid
        List<GenericValue> loans = EntityQuery.use(delegator)
                .from("EmployeeLoan")
                .where("orgPartyId", orgPartyId, "partyId", partyId)
                .queryList();

        BigDecimal total = BigDecimal.ZERO;
        for (GenericValue loan : loans) {
            String loanId = loan.getString("loanId");

            EntityCondition cond = EntityCondition.makeCondition(Arrays.asList(
                    EntityCondition.makeCondition("loanId", EntityOperator.EQUALS, loanId),
                    EntityCondition.makeCondition("dueDate", EntityOperator.GREATER_THAN_EQUAL_TO, periodStartTs),
                    EntityCondition.makeCondition("dueDate", EntityOperator.LESS_THAN_EQUAL_TO, periodEndTs),
                    EntityCondition.makeCondition(
                            EntityCondition.makeCondition("paidDate", EntityOperator.EQUALS, null),
                            EntityOperator.OR,
                            EntityCondition.makeCondition("paidDate", EntityOperator.LESS_THAN, periodStartTs)
                    )
            ), EntityOperator.AND);

            List<GenericValue> inst = EntityQuery.use(delegator).from("LoanInstallment").where(cond).queryList();
            for (GenericValue i : inst) total = total.add(bd(i.get("installmentAmount")));
        }
        return total;
    }

    private static BigDecimal calculateIncomeTax(Delegator delegator, String orgPartyId, String countryGeoId, int taxYear, BigDecimal taxableIncome) throws GenericEntityException {
        // Minimal bracket model based on PayrollTaxConfig ranges.
        // You can enhance to progressive calculation; here we select matching bracket and apply.
        EntityCondition cond = EntityCondition.makeCondition(Arrays.asList(
                EntityCondition.makeCondition("orgPartyId", EntityOperator.EQUALS, orgPartyId),
                EntityCondition.makeCondition("countryGeoId", EntityOperator.EQUALS, countryGeoId),
                EntityCondition.makeCondition("taxYear", EntityOperator.EQUALS, taxYear)
        ), EntityOperator.AND);

        List<GenericValue> brackets = EntityQuery.use(delegator)
                .from("PayrollTaxConfig")
                .where(cond)
                .orderBy("minIncome ASC")
                .queryList();

        BigDecimal tax = BigDecimal.ZERO;
        for (GenericValue b : brackets) {
            BigDecimal min = bd(b.get("minIncome"));
            BigDecimal max = b.get("maxIncome") == null ? null : bd(b.get("maxIncome"));
            BigDecimal rate = b.get("taxRate") == null ? BigDecimal.ZERO : bd(b.get("taxRate"));
            BigDecimal add = b.get("additionalAmount") == null ? BigDecimal.ZERO : bd(b.get("additionalAmount"));

            boolean inRange = taxableIncome.compareTo(min) >= 0 && (max == null || taxableIncome.compareTo(max) <= 0);
            if (inRange) {
                tax = taxableIncome.multiply(rate).add(add);
                break;
            }
        }
        return tax.max(BigDecimal.ZERO);
    }

    private static BigDecimal calculateSocialSecurity(Delegator delegator, String orgPartyId, String countryGeoId, Timestamp onDate, BigDecimal gross) throws GenericEntityException {
        EntityCondition cond = EntityCondition.makeCondition(Arrays.asList(
                EntityCondition.makeCondition("orgPartyId", EntityOperator.EQUALS, orgPartyId),
                EntityCondition.makeCondition("countryGeoId", EntityOperator.EQUALS, countryGeoId),
                EntityCondition.makeCondition("effectiveDate", EntityOperator.LESS_THAN_EQUAL_TO, onDate),
                EntityCondition.makeCondition(
                        EntityCondition.makeCondition("thruDate", EntityOperator.EQUALS, null),
                        EntityOperator.OR,
                        EntityCondition.makeCondition("thruDate", EntityOperator.GREATER_THAN_EQUAL_TO, onDate)
                )
        ), EntityOperator.AND);

        GenericValue cfg = EntityQuery.use(delegator).from("SocialSecurityConfig").where(cond).queryFirst();
        if (cfg == null) return BigDecimal.ZERO;

        BigDecimal rate = bd(cfg.get("employeeRate"));
        BigDecimal maxBase = cfg.get("maxContributionBase") == null ? null : bd(cfg.get("maxContributionBase"));
        BigDecimal minBase = cfg.get("minContributionBase") == null ? null : bd(cfg.get("minContributionBase"));

        BigDecimal base = gross;
        if (maxBase != null && base.compareTo(maxBase) > 0) base = maxBase;
        if (minBase != null && base.compareTo(minBase) < 0) base = minBase;

        return base.multiply(rate).max(BigDecimal.ZERO);
    }

    private static GenericValue upsertResultHeader(Delegator delegator, String orgPartyId, String payrollRunId, String partyId, String currencyUomId) throws GenericEntityException {
        GenericValue existing = EntityQuery.use(delegator)
                .from("EmployeePayrollResult")
                .where("orgPartyId", orgPartyId, "payrollRunId", payrollRunId, "partyId", partyId)
                .queryFirst();

        if (existing != null) return existing;

        GenericValue res = delegator.makeValue("EmployeePayrollResult");
        res.set("payrollResultId", delegator.getNextSeqId("EmployeePayrollResult"));
        res.set("orgPartyId", orgPartyId);
        res.set("payrollRunId", payrollRunId);
        res.set("partyId", partyId);
        res.set("currencyUomId", currencyUomId);
        res.set("versionNumber", Long.valueOf(1));
        res.set("isPayslipGenerated", "N");
        res.set("isPayslipSent", "N");
        res.create();
        return res;
    }

    private static void clearExistingLinesAndTax(Delegator delegator, String payrollResultId) throws GenericEntityException {
        delegator.removeByAnd("EmployeePayrollResultLine", UtilMisc.toMap("payrollResultId", payrollResultId));
        delegator.removeByAnd("EmployeeTaxDetail", UtilMisc.toMap("payrollResultId", payrollResultId));
    }

    private static void createLine(Delegator delegator, String payrollResultId, String lineTypeId, String desc, BigDecimal amount) throws GenericEntityException {
        GenericValue line = delegator.makeValue("EmployeePayrollResultLine");
        line.set("resultLineId", delegator.getNextSeqId("EmployeePayrollResultLine"));
        line.set("payrollResultId", payrollResultId);
        line.set("lineTypeId", lineTypeId);
        line.set("description", desc);
        line.set("amount", amount);
        line.create();
    }

    private static void createTaxDetail(Delegator delegator, String payrollResultId, String taxTypeId, BigDecimal taxable, BigDecimal rate, BigDecimal tax) throws GenericEntityException {
        GenericValue td = delegator.makeValue("EmployeeTaxDetail");
        td.set("taxDetailId", delegator.getNextSeqId("EmployeeTaxDetail"));
        td.set("payrollResultId", payrollResultId);
        td.set("taxTypeId", taxTypeId);
        td.set("taxableAmount", taxable);
        td.set("taxRate", rate);
        td.set("calculatedTax", tax);
        td.create();
    }

    public static Map<String, Object> processPayrollRun(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        Map<String, Object> result = ServiceUtil.returnSuccess();

        try {
            String orgPartyId = (String) context.get("orgPartyId");
            String payrollRunId = (String) context.get("payrollRunId");
            Boolean recalc = (Boolean) context.get("recalculate");

            if (UtilValidate.isEmpty(orgPartyId) || UtilValidate.isEmpty(payrollRunId)) {
                return ServiceUtil.returnError("orgPartyId and payrollRunId are required");
            }

            GenericValue run = getRun(delegator, orgPartyId, payrollRunId);
            GenericValue period = getPeriod(delegator, orgPartyId, run.getString("payrollPeriodId"));

            // Convert PayrollPeriod dates (DATE) into Timestamps for comparisons
            Timestamp periodStartTs = UtilDateTime.toTimestamp(period.getDate("startDate"));
            // include whole end day
            Timestamp periodEndTs = UtilDateTime.toTimestamp(period.getDate("endDate"));
            periodEndTs = UtilDateTime.getDayEnd(periodEndTs);

            String currencyUomId = run.getString("currencyUomId");
            int taxYear = UtilDateTime.toCalendar(periodStartTs).get(Calendar.YEAR);

            // Determine country for tax/ss from PayrollOrganization (simplified)
            GenericValue org = EntityQuery.use(delegator).from("PayrollOrganization")
                    .where("orgPartyId", orgPartyId).queryOne();
            String countryGeoId = org != null ? org.getString("countryGeoId") : null;

            List<GenericValue> assignments = getActiveAssignments(delegator, orgPartyId, periodStartTs, periodEndTs);

            BigDecimal totalGross = BigDecimal.ZERO;
            BigDecimal totalDed = BigDecimal.ZERO;
            BigDecimal totalNet = BigDecimal.ZERO;

            int employeeCount = 0;

            for (GenericValue a : assignments) {
                String partyId = a.getString("partyId");
                employeeCount++;

                BigDecimal basic = bd(a.get("baseSalary"));
                BigDecimal allowances = sumEmployeeAllowances(delegator, orgPartyId, partyId, periodStartTs, periodEndTs);
                BigDecimal deductions = sumEmployeeDeductions(delegator, orgPartyId, partyId, periodStartTs, periodEndTs);
                BigDecimal loanDed = sumLoanInstallmentsDue(delegator, orgPartyId, partyId, periodStartTs, periodEndTs);

                BigDecimal gross = basic.add(allowances);
                BigDecimal taxableIncome = gross; // extend: subtract pre-tax deductions
                BigDecimal tax = (UtilValidate.isEmpty(countryGeoId)) ? BigDecimal.ZERO
                        : calculateIncomeTax(delegator, orgPartyId, countryGeoId, taxYear, taxableIncome);

                BigDecimal ss = (UtilValidate.isEmpty(countryGeoId)) ? BigDecimal.ZERO
                        : calculateSocialSecurity(delegator, orgPartyId, countryGeoId, periodEndTs, gross);

                BigDecimal totalDeductions = deductions.add(loanDed).add(tax).add(ss);
                BigDecimal net = gross.subtract(totalDeductions);

                // Upsert header and reset lines (if recalc)
                GenericValue res = upsertResultHeader(delegator, orgPartyId, payrollRunId, partyId, currencyUomId);

                if (Boolean.TRUE.equals(recalc)) {
                    clearExistingLinesAndTax(delegator, res.getString("payrollResultId"));
                }

                // Store header aggregates
                res.set("basicSalary", basic);
                res.set("allowancesTotal", allowances);
                res.set("grossSalary", gross);

                res.set("incomeTax", tax);
                res.set("socialSecurity", ss);
                res.set("loanDeductions", loanDed);
                res.set("otherDeductions", deductions);
                res.set("totalDeductions", totalDeductions);

                res.set("netSalary", net);

                // payment info snapshot
                res.set("paymentMethodId", a.get("paymentMethodId"));
                res.set("finAccountId", a.get("finAccountId"));

                res.store();

                // Lines (auditable)
                createLine(delegator, res.getString("payrollResultId"), LINE_BASIC, "Basic Salary", basic);
                if (allowances.compareTo(BigDecimal.ZERO) != 0) createLine(delegator, res.getString("payrollResultId"), LINE_ALLOWANCE, "Allowances", allowances);
                if (deductions.compareTo(BigDecimal.ZERO) != 0) createLine(delegator, res.getString("payrollResultId"), LINE_DEDUCTION, "Deductions", deductions);
                if (loanDed.compareTo(BigDecimal.ZERO) != 0) createLine(delegator, res.getString("payrollResultId"), LINE_LOAN, "Loan Installments", loanDed);
                if (tax.compareTo(BigDecimal.ZERO) != 0) createLine(delegator, res.getString("payrollResultId"), LINE_TAX, "Income Tax", tax);
                if (ss.compareTo(BigDecimal.ZERO) != 0) createLine(delegator, res.getString("payrollResultId"), LINE_SS, "Social Security", ss);
                createLine(delegator, res.getString("payrollResultId"), LINE_NET, "Net Salary", net);

                // Tax detail (simple)
                if (tax.compareTo(BigDecimal.ZERO) != 0) {
                    createTaxDetail(delegator, res.getString("payrollResultId"), "PAY_TAX_INCOME", taxableIncome, BigDecimal.ZERO, tax);
                }

                // YTD update (simplified; production: compute from all results)
                upsertYtd(delegator, orgPartyId, partyId, taxYear, currencyUomId, gross, tax, ss, allowances, BigDecimal.ZERO, net);

                totalGross = totalGross.add(gross);
                totalDed = totalDed.add(totalDeductions);
                totalNet = totalNet.add(net);
            }

            run.set("totalEmployees", Long.valueOf(employeeCount));
            run.set("totalGrossPay", totalGross);
            run.set("totalDeductions", totalDed);
            run.set("totalNetPay", totalNet);
            run.store();

            return result;

        } catch (Exception e) {
            Debug.logError(e, MODULE);
            return ServiceUtil.returnError("processPayrollRun failed: " + e.getMessage());
        }
    }

    private static void upsertYtd(Delegator delegator, String orgPartyId, String partyId, int year, String currencyUomId,
                                  BigDecimal gross, BigDecimal tax, BigDecimal ss, BigDecimal allowances, BigDecimal overtime, BigDecimal net)
            throws GenericEntityException {

        GenericValue ytd = EntityQuery.use(delegator)
                .from("EmployeeYTDSummary")
                .where("orgPartyId", orgPartyId, "partyId", partyId, "calendarYear", Long.valueOf(year))
                .queryFirst();

        if (ytd == null) {
            ytd = delegator.makeValue("EmployeeYTDSummary");
            ytd.set("employeeYtdSummaryId", delegator.getNextSeqId("EmployeeYTDSummary"));
            ytd.set("orgPartyId", orgPartyId);
            ytd.set("partyId", partyId);
            ytd.set("calendarYear", Long.valueOf(year));
            ytd.set("currencyUomId", currencyUomId);

            ytd.set("ytdGross", BigDecimal.ZERO);
            ytd.set("ytdTax", BigDecimal.ZERO);
            ytd.set("ytdSocialSecurity", BigDecimal.ZERO);
            ytd.set("ytdAllowances", BigDecimal.ZERO);
            ytd.set("ytdOvertime", BigDecimal.ZERO);
            ytd.set("ytdNet", BigDecimal.ZERO);

            ytd.create();
        }

        ytd.set("ytdGross", bd(ytd.get("ytdGross")).add(gross));
        ytd.set("ytdTax", bd(ytd.get("ytdTax")).add(tax));
        ytd.set("ytdSocialSecurity", bd(ytd.get("ytdSocialSecurity")).add(ss));
        ytd.set("ytdAllowances", bd(ytd.get("ytdAllowances")).add(allowances));
        ytd.set("ytdOvertime", bd(ytd.get("ytdOvertime")).add(overtime));
        ytd.set("ytdNet", bd(ytd.get("ytdNet")).add(net));
        ytd.set("lastCalculatedDate", now());
        ytd.store();
    }

    public static Map<String, Object> generatePayslipsForRun(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        try {
            String orgPartyId = (String) context.get("orgPartyId");
            String payrollRunId = (String) context.get("payrollRunId");

            if (UtilValidate.isEmpty(orgPartyId) || UtilValidate.isEmpty(payrollRunId)) {
                return ServiceUtil.returnError("orgPartyId and payrollRunId are required");
            }

            List<GenericValue> results = EntityQuery.use(delegator)
                    .from("EmployeePayrollResult")
                    .where("orgPartyId", orgPartyId, "payrollRunId", payrollRunId)
                    .queryList();

            for (GenericValue r : results) {
                // In production: generate PDF/HTML and create PayrollExportRequest + PayrollExportFile.
                // Here we just mark as generated and store payslipRef placeholder.
                r.set("isPayslipGenerated", "Y");
                r.set("payslipRef", "RUN:" + payrollRunId + "|RES:" + r.getString("payrollResultId"));
                r.store();
            }

            return ServiceUtil.returnSuccess();
        } catch (Exception e) {
            Debug.logError(e, MODULE);
            return ServiceUtil.returnError("generatePayslipsForRun failed: " + e.getMessage());
        }
    }

    public static Map<String, Object> buildBankTransferBatchForRun(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        Map<String, Object> out = ServiceUtil.returnSuccess();

        try {
            String orgPartyId = (String) context.get("orgPartyId");
            String payrollRunId = (String) context.get("payrollRunId");
            String cfgId = (String) context.get("bankTransferConfigId");

            if (UtilValidate.isEmpty(orgPartyId) || UtilValidate.isEmpty(payrollRunId) || UtilValidate.isEmpty(cfgId)) {
                return ServiceUtil.returnError("orgPartyId, payrollRunId, bankTransferConfigId are required");
            }

            GenericValue run = getRun(delegator, orgPartyId, payrollRunId);

            // Create batch
            GenericValue batch = delegator.makeValue("BankTransferBatch");
            String batchId = delegator.getNextSeqId("BankTransferBatch");
            batch.set("bankTransferBatchId", batchId);
            batch.set("orgPartyId", orgPartyId);
            batch.set("payrollRunId", payrollRunId);
            batch.set("bankTransferConfigId", cfgId);
            batch.set("currencyUomId", run.getString("currencyUomId"));
            batch.set("generatedDate", now());
            batch.create();

            BigDecimal total = BigDecimal.ZERO;
            long count = 0;

            List<GenericValue> results = EntityQuery.use(delegator)
                    .from("EmployeePayrollResult")
                    .where("orgPartyId", orgPartyId, "payrollRunId", payrollRunId)
                    .queryList();

            long seq = 1;
            for (GenericValue r : results) {
                BigDecimal net = bd(r.get("netSalary"));
                if (net.compareTo(BigDecimal.ZERO) <= 0) continue;

                GenericValue line = delegator.makeValue("BankTransferBatchLine");
                line.set("bankTransferBatchLineId", delegator.getNextSeqId("BankTransferBatchLine"));
                line.set("bankTransferBatchId", batchId);
                line.set("payrollResultId", r.getString("payrollResultId"));
                line.set("partyId", r.getString("partyId"));
                line.set("amount", net);
                line.set("currencyUomId", r.getString("currencyUomId"));
                line.set("sequenceNum", Long.valueOf(seq++));
                // iban/account should be sourced from PaymentMethod/FinAccount in production
                line.create();

                total = total.add(net);
                count++;
            }

            batch.set("totalAmount", total);
            batch.set("totalRecords", Long.valueOf(count));
            batch.store();

            out.put("bankTransferBatchId", batchId);
            return out;

        } catch (Exception e) {
            Debug.logError(e, MODULE);
            return ServiceUtil.returnError("buildBankTransferBatchForRun failed: " + e.getMessage());
        }
    }
}
