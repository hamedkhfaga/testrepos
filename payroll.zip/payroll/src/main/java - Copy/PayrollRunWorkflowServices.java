package org.apache.ofbiz.payroll.services;

import org.apache.ofbiz.base.util.Debug;
import org.apache.ofbiz.base.util.UtilDateTime;
import org.apache.ofbiz.base.util.UtilMisc;
import org.apache.ofbiz.base.util.UtilValidate;

import org.apache.ofbiz.entity.Delegator;
import org.apache.ofbiz.entity.GenericEntityException;
import org.apache.ofbiz.entity.GenericValue;

import org.apache.ofbiz.entity.transaction.TransactionUtil;
import org.apache.ofbiz.entity.util.EntityQuery;

import org.apache.ofbiz.service.DispatchContext;
import org.apache.ofbiz.service.LocalDispatcher;
import org.apache.ofbiz.service.ServiceUtil;

import org.apache.ofbiz.payroll.services.engine.PayrollProcessingEngine;

import java.sql.Timestamp;
import java.util.Map;

/**
 * PayrollRunWorkflowServices (FINAL)
 *
 * Workflow:
 * 1) createPayrollRun
 * 2) processPayrollRun (calculate)
 * 3) complianceCheckPayrollRun
 * 4) approvePayrollRun
 * 5) postPayrollRun (GL / INVOICE / BOTH / NONE) -> delegates to PayrollPostingServices
 *
 * Notes:
 * - Uses organizationPartyId everywhere (Option A migration)
 * - Uses userLogin from context (OFBiz standard)
 * - Audits via recordPayrollAuditEvent (non-blocking)
 * - Transaction boundaries for each workflow action
 */
public class PayrollRunWorkflowServices {

    public static final String MODULE = PayrollRunWorkflowServices.class.getName();

    // PayrollRun status ids (must exist as StatusItem)
    private static final String RUN_NEW       = "PAYRUN_NEW";
    private static final String RUN_PROCESSED = "PAYRUN_PROCESSED";
    private static final String RUN_APPROVED  = "PAYRUN_APPROVED";
    private static final String RUN_POSTED    = "PAYRUN_POSTED";

    // Accounting post options (must exist as StatusItem or as your own enum values)
    private static final String PAY_POST_NONE    = "PAY_POST_NONE";
    private static final String PAY_POST_GL      = "PAY_POST_GL";
    private static final String PAY_POST_INVOICE = "PAY_POST_INVOICE";
    private static final String PAY_POST_BOTH    = "PAY_POST_BOTH";

    // =========================================================
    // 1) Create Payroll Run
    // =========================================================
    public static Map<String, Object> createPayrollRun(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        LocalDispatcher dispatcher = dctx.getDispatcher();
        GenericValue userLogin = (GenericValue) context.get("userLogin");

        String payrollPeriodId = (String) context.get("payrollPeriodId");
        String organizationPartyId = firstOrg(context);
        String currencyUomId = (String) context.get("currencyUomId");
        String runName = (String) context.get("runName");
        String runTypeId = (String) context.get("runTypeId"); // optional

        if (UtilValidate.isEmpty(payrollPeriodId)) return ServiceUtil.returnError("payrollPeriodId is required");
        if (UtilValidate.isEmpty(organizationPartyId)) return ServiceUtil.returnError("organizationPartyId is required");
        if (UtilValidate.isEmpty(currencyUomId)) return ServiceUtil.returnError("currencyUomId is required");
        if (userLogin == null) return ServiceUtil.returnError("userLogin is required");

        boolean beganTx = false;
        try {
            beganTx = TransactionUtil.begin();

            // Validate PayrollPeriod exists for same org (recommended)
            GenericValue period = EntityQuery.use(delegator).from("PayrollPeriod")
                    .where("payrollPeriodId", payrollPeriodId,
                           "organizationPartyId", organizationPartyId)
                    .queryFirst();
            if (period == null) {
                return ServiceUtil.returnError("PayrollPeriod not found for org. payrollPeriodId=" + payrollPeriodId
                        + " organizationPartyId=" + organizationPartyId);
            }

            String payrollRunId = delegator.getNextSeqId("PayrollRun");
            Timestamp now = UtilDateTime.nowTimestamp();

            GenericValue run = delegator.makeValue("PayrollRun");
            run.set("payrollRunId", payrollRunId);
            run.set("organizationPartyId", organizationPartyId);
            run.set("payrollPeriodId", payrollPeriodId);
            run.set("runName", UtilValidate.isEmpty(runName) ? ("Run-" + payrollRunId) : runName);
            run.set("runTypeId", runTypeId);
            run.set("runDate", now);
            run.set("currencyUomId", currencyUomId);
            run.set("statusId", RUN_NEW);

            // tracking + flags
            if (run.getModelEntity().isField("createdByUserLoginId")) run.set("createdByUserLoginId", userLogin.getString("userLoginId"));
            if (run.getModelEntity().isField("createdDate")) run.set("createdDate", now);
            if (run.getModelEntity().isField("isGlPosted")) run.set("isGlPosted", "N");
            if (run.getModelEntity().isField("isInvoicePosted")) run.set("isInvoicePosted", "N");
            if (run.getModelEntity().isField("isCompliant")) run.set("isCompliant", "N");

            delegator.create(run);

            audit(dispatcher, userLogin, organizationPartyId,
                    "RUN_CREATE", "PayrollRun", payrollRunId,
                    null, "Created payroll run", getSourceIp(context));

            TransactionUtil.commit(beganTx);

            Map<String, Object> out = ServiceUtil.returnSuccess();
            out.put("payrollRunId", payrollRunId);
            return out;

        } catch (Exception e) {
            rollbackQuiet(beganTx, e);
            Debug.logError(e, "createPayrollRun failed", MODULE);
            return ServiceUtil.returnError("createPayrollRun failed: " + e.getMessage());
        }
    }

    // =========================================================
    // 2) Process (Calculate) Payroll Run
    // =========================================================
    public static Map<String, Object> processPayrollRun(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        LocalDispatcher dispatcher = dctx.getDispatcher();
        GenericValue userLogin = (GenericValue) context.get("userLogin");

        String payrollRunId = (String) context.get("payrollRunId");
        if (UtilValidate.isEmpty(payrollRunId)) return ServiceUtil.returnError("payrollRunId is required");
        if (userLogin == null) return ServiceUtil.returnError("userLogin is required");

        boolean beganTx = false;
        try {
            beganTx = TransactionUtil.begin();

            GenericValue run = mustGetRun(delegator, payrollRunId);
            String organizationPartyId = run.getString("organizationPartyId");

            // Allowed: NEW -> PROCESSED (reprocess allowed via forceRecalc)
            String statusId = run.getString("statusId");
            if (!RUN_NEW.equals(statusId) && !RUN_PROCESSED.equals(statusId)) {
                return ServiceUtil.returnError("PayrollRun must be NEW/PROCESSED to process. Current=" + statusId);
            }

            // Delegate engine
            PayrollProcessingEngine.process(delegator, run, userLogin.getString("userLoginId"));

            run.set("statusId", RUN_PROCESSED);
            run.store();

            audit(dispatcher, userLogin, organizationPartyId,
                    "RUN_PROCESS", "PayrollRun", payrollRunId,
                    null, "Processed payroll run", getSourceIp(context));

            TransactionUtil.commit(beganTx);
            return ServiceUtil.returnSuccess();

        } catch (Exception e) {
            rollbackQuiet(beganTx, e);
            Debug.logError(e, "processPayrollRun failed", MODULE);
            return ServiceUtil.returnError("processPayrollRun failed: " + e.getMessage());
        }
    }

    // =========================================================
    // 3) Compliance check
    // =========================================================
    public static Map<String, Object> complianceCheckPayrollRun(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        LocalDispatcher dispatcher = dctx.getDispatcher();
        GenericValue userLogin = (GenericValue) context.get("userLogin");

        String payrollRunId = (String) context.get("payrollRunId");
        if (UtilValidate.isEmpty(payrollRunId)) return ServiceUtil.returnError("payrollRunId is required");
        if (userLogin == null) return ServiceUtil.returnError("userLogin is required");

        boolean beganTx = false;
        try {
            beganTx = TransactionUtil.begin();

            GenericValue run = mustGetRun(delegator, payrollRunId);
            String organizationPartyId = run.getString("organizationPartyId");

            // Must be processed before compliance
            if (!RUN_PROCESSED.equals(run.getString("statusId")) && !RUN_APPROVED.equals(run.getString("statusId"))) {
                return ServiceUtil.returnError("PayrollRun must be PROCESSED before compliance check.");
            }

            // Minimal compliance flags (you can extend to generate PayrollComplianceReport)
            if (run.getModelEntity().isField("isCompliant")) run.set("isCompliant", "Y");
            if (run.getModelEntity().isField("complianceCheckedByUserLoginId")) run.set("complianceCheckedByUserLoginId", userLogin.getString("userLoginId"));
            if (run.getModelEntity().isField("complianceCheckDate")) run.set("complianceCheckDate", UtilDateTime.nowTimestamp());
            run.store();

            audit(dispatcher, userLogin, organizationPartyId,
                    "RUN_COMPLIANCE_OK", "PayrollRun", payrollRunId,
                    null, "Compliance checked", getSourceIp(context));

            TransactionUtil.commit(beganTx);
            return ServiceUtil.returnSuccess();

        } catch (Exception e) {
            rollbackQuiet(beganTx, e);
            Debug.logError(e, "complianceCheckPayrollRun failed", MODULE);
            return ServiceUtil.returnError("complianceCheckPayrollRun failed: " + e.getMessage());
        }
    }

    // =========================================================
    // 4) Approve Payroll Run
    // =========================================================
    public static Map<String, Object> approvePayrollRun(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        LocalDispatcher dispatcher = dctx.getDispatcher();
        GenericValue userLogin = (GenericValue) context.get("userLogin");

        String payrollRunId = (String) context.get("payrollRunId");
        if (UtilValidate.isEmpty(payrollRunId)) return ServiceUtil.returnError("payrollRunId is required");
        if (userLogin == null) return ServiceUtil.returnError("userLogin is required");

        boolean beganTx = false;
        try {
            beganTx = TransactionUtil.begin();

            GenericValue run = mustGetRun(delegator, payrollRunId);
            String organizationPartyId = run.getString("organizationPartyId");

            // Must be processed; compliance recommended
            if (!RUN_PROCESSED.equals(run.getString("statusId"))) {
                return ServiceUtil.returnError("PayrollRun must be PROCESSED to approve. Current=" + run.getString("statusId"));
            }

            run.set("statusId", RUN_APPROVED);
            if (run.getModelEntity().isField("approvedByUserLoginId")) run.set("approvedByUserLoginId", userLogin.getString("userLoginId"));
            if (run.getModelEntity().isField("approvedDate")) run.set("approvedDate", UtilDateTime.nowTimestamp());
            run.store();

            audit(dispatcher, userLogin, organizationPartyId,
                    "RUN_APPROVE", "PayrollRun", payrollRunId,
                    null, "Approved payroll run", getSourceIp(context));

            TransactionUtil.commit(beganTx);
            return ServiceUtil.returnSuccess();

        } catch (Exception e) {
            rollbackQuiet(beganTx, e);
            Debug.logError(e, "approvePayrollRun failed", MODULE);
            return ServiceUtil.returnError("approvePayrollRun failed: " + e.getMessage());
        }
    }

    // =========================================================
    // 5) Post Payroll Run (GL / INVOICE / BOTH / NONE)
    // =========================================================
    public static Map<String, Object> postPayrollRun(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        LocalDispatcher dispatcher = dctx.getDispatcher();
        GenericValue userLogin = (GenericValue) context.get("userLogin");

        String payrollRunId = (String) context.get("payrollRunId");
        String accountingPostOptionId = (String) context.get("accountingPostOptionId"); // optional override
        Boolean forceRepost = (Boolean) context.get("forceRepost");

        if (UtilValidate.isEmpty(payrollRunId)) return ServiceUtil.returnError("payrollRunId is required");
        if (userLogin == null) return ServiceUtil.returnError("userLogin is required");

        boolean beganTx = false;
        try {
            beganTx = TransactionUtil.begin();

            GenericValue run = mustGetRun(delegator, payrollRunId);
            String organizationPartyId = run.getString("organizationPartyId");

            if (!RUN_APPROVED.equals(run.getString("statusId")) && !RUN_POSTED.equals(run.getString("statusId"))) {
                return ServiceUtil.returnError("PayrollRun must be APPROVED to post. Current=" + run.getString("statusId"));
            }

            if (UtilValidate.isEmpty(accountingPostOptionId)) {
                // fallback to run field if present
                if (run.getModelEntity().isField("accountingPostOptionId")) {
                    accountingPostOptionId = run.getString("accountingPostOptionId");
                }
            }
            if (UtilValidate.isEmpty(accountingPostOptionId)) accountingPostOptionId = PAY_POST_GL; // safe default

            Map<String, Object> out = ServiceUtil.returnSuccess();

            if (PAY_POST_NONE.equals(accountingPostOptionId)) {
                audit(dispatcher, userLogin, organizationPartyId,
                        "RUN_POST_SKIP", "PayrollRun", payrollRunId,
                        null, "Post option NONE", getSourceIp(context));
                TransactionUtil.commit(beganTx);
                return out;
            }

            if (PAY_POST_GL.equals(accountingPostOptionId) || PAY_POST_BOTH.equals(accountingPostOptionId)) {
                Map<String, Object> ctx = UtilMisc.toMap(
                        "payrollRunId", payrollRunId,
                        "organizationPartyId", organizationPartyId,
                        "forceRepost", forceRepost,
                        "userLogin", userLogin
                );
                Map<String, Object> res = dispatcher.runSync("postPayrollRunToGl", ctx);
                if (ServiceUtil.isError(res)) return res;
                out.put("glJournalId", res.get("glJournalId"));
            }

            if (PAY_POST_INVOICE.equals(accountingPostOptionId) || PAY_POST_BOTH.equals(accountingPostOptionId)) {
                Map<String, Object> ctx = UtilMisc.toMap(
                        "payrollRunId", payrollRunId,
                        "organizationPartyId", organizationPartyId,
                        "vendorPartyId", context.get("vendorPartyId"),
                        "invoiceTypeId", context.get("invoiceTypeId"),
                        "forceRepost", forceRepost,
                        "userLogin", userLogin
                );
                Map<String, Object> res = dispatcher.runSync("postPayrollRunToInvoice", ctx);
                if (ServiceUtil.isError(res)) return res;
                out.put("invoiceId", res.get("invoiceId"));
            }

            // Mark run posted (do not rely only on posting service)
            run.set("statusId", RUN_POSTED);
            if (run.getModelEntity().isField("glPostedDate")) run.set("glPostedDate", UtilDateTime.nowTimestamp());
            run.store();

            audit(dispatcher, userLogin, organizationPartyId,
                    "RUN_POST", "PayrollRun", payrollRunId,
                    null, "Posted payroll run option=" + accountingPostOptionId, getSourceIp(context));

            TransactionUtil.commit(beganTx);
            return out;

        } catch (Exception e) {
            rollbackQuiet(beganTx, e);
            Debug.logError(e, "postPayrollRun failed", MODULE);
            return ServiceUtil.returnError("postPayrollRun failed: " + e.getMessage());
        }
    }

    // =========================================================
    // Helpers
    // =========================================================
    private static String firstOrg(Map<String, ?> context) {
        String organizationPartyId = (String) context.get("organizationPartyId");
        if (UtilValidate.isEmpty(organizationPartyId)) organizationPartyId = (String) context.get("orgPartyId");
        return organizationPartyId;
    }

    private static GenericValue mustGetRun(Delegator delegator, String payrollRunId) throws GenericEntityException {
        GenericValue run = EntityQuery.use(delegator).from("PayrollRun")
                .where("payrollRunId", payrollRunId)
                .queryOne();
        if (run == null) throw new IllegalArgumentException("PayrollRun not found: " + payrollRunId);
        return run;
    }

    private static void rollbackQuiet(boolean beganTx, Exception e) {
        try {
            if (beganTx) TransactionUtil.rollback(beganTx, e.getMessage(), e);
        } catch (Exception ignored) {}
    }

    private static String getSourceIp(Map<String, ?> context) {
        Object v = context.get("sourceIp");
        return v == null ? null : String.valueOf(v);
    }

    /**
     * Non-blocking audit hook. Requires a service:
     * recordPayrollAuditEvent(organizationPartyId,eventTypeId,entityName,recordId,oldValue,newValue,eventDate,userLoginId,sourceIp,userLogin)
     */
    private static void audit(LocalDispatcher dispatcher, GenericValue userLogin, String organizationPartyId,
                              String eventTypeId, String entityName, String recordId,
                              String oldValue, String newValue, String sourceIp) {
        try {
            Map<String, Object> ctx = UtilMisc.toMap(
                    "organizationPartyId", organizationPartyId,
                    "eventTypeId", eventTypeId,
                    "entityName", entityName,
                    "recordId", recordId,
                    "oldValue", oldValue,
                    "newValue", newValue,
                    "sourceIp", sourceIp,
                    "userLogin", userLogin
            );
            dispatcher.runSync("recordPayrollAuditEvent", ctx);
        } catch (Exception ignored) {
            // never block workflow due to audit
        }
    }
}
