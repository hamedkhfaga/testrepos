package org.apache.ofbiz.payroll;

import org.apache.ofbiz.entity.*;
import org.apache.ofbiz.entity.util.EntityQuery;
import org.apache.ofbiz.service.*;
import org.apache.ofbiz.base.util.*;

import java.sql.Timestamp;
import java.util.*;

public class PayrollMasterServices {

    public static Map<String, Object> createPayrollStructure(DispatchContext dctx, Map<String, ?> context)
            throws GenericEntityException {

        Delegator delegator = dctx.getDelegator();
        GenericValue userLogin = (GenericValue) context.get("userLogin");

        GenericValue gv = delegator.makeValue("PayrollStructure");
        gv.set("payrollStructureId", delegator.getNextSeqId("PayrollStructure"));
        gv.set("organizationPartyId", context.get("organizationPartyId"));
        gv.set("structureName", context.get("structureName"));
        gv.set("description", context.get("description"));
        gv.set("createdDate", UtilDateTime.nowTimestamp());
        gv.set("createdByUserLogin", userLogin.getString("userLoginId"));

        delegator.create(gv);
        return ServiceUtil.returnSuccess();
    }

    public static Map<String, Object> updatePayrollStructure(DispatchContext dctx, Map<String, ?> context)
            throws GenericEntityException {

        Delegator delegator = dctx.getDelegator();
        GenericValue gv = delegator.findOne("PayrollStructure",
                UtilMisc.toMap("payrollStructureId", context.get("payrollStructureId")), false);

        if (gv == null) return ServiceUtil.returnError("PayrollStructure not found");

        gv.setNonPKFields(context);
        gv.store();
        return ServiceUtil.returnSuccess();
    }

    public static Map<String, Object> deletePayrollStructure(DispatchContext dctx, Map<String, ?> context)
            throws GenericEntityException {

        Delegator delegator = dctx.getDelegator();
        delegator.removeByPrimaryKey("PayrollStructure",
                UtilMisc.toMap("payrollStructureId", context.get("payrollStructureId")));
        return ServiceUtil.returnSuccess();
    }

    public static Map<String, Object> getPayrollStructureList(DispatchContext dctx, Map<String, ?> context)
            throws GenericEntityException {

        List<GenericValue> list = EntityQuery.use(dctx.getDelegator())
                .from("PayrollStructure")
                .where("organizationPartyId", context.get("organizationPartyId"))
                .queryList();

        Map<String, Object> result = ServiceUtil.returnSuccess();
        result.put("list", list);
        return result;
    }

    /* ========================================================= */
    /* Employee Payroll Assignment CRUD                          */
    /* ========================================================= */

    public static Map<String, Object> createEmployeePayrollAssignment(
            DispatchContext dctx, Map<String, ?> context) throws GenericEntityException {

        Delegator delegator = dctx.getDelegator();
        GenericValue gv = delegator.makeValue("EmployeePayrollAssignment");
        gv.set("assignmentId", delegator.getNextSeqId("EmployeePayrollAssignment"));
        gv.setNonPKFields(context);
        delegator.create(gv);
        return ServiceUtil.returnSuccess();
    }

    public static Map<String, Object> updateEmployeePayrollAssignment(
            DispatchContext dctx, Map<String, ?> context) throws GenericEntityException {

        Delegator delegator = dctx.getDelegator();
        GenericValue gv = delegator.findOne("EmployeePayrollAssignment",
                UtilMisc.toMap("assignmentId", context.get("assignmentId")), false);

        if (gv == null) return ServiceUtil.returnError("Assignment not found");
        gv.setNonPKFields(context);
        gv.store();
        return ServiceUtil.returnSuccess();
    }

    public static Map<String, Object> deleteEmployeePayrollAssignment(
            DispatchContext dctx, Map<String, ?> context) throws GenericEntityException {

        dctx.getDelegator().removeByPrimaryKey("EmployeePayrollAssignment",
                UtilMisc.toMap("assignmentId", context.get("assignmentId")));
        return ServiceUtil.returnSuccess();
    }

    public static Map<String, Object> getEmployeePayrollAssignmentList(
            DispatchContext dctx, Map<String, ?> context) throws GenericEntityException {

        List<GenericValue> list = EntityQuery.use(dctx.getDelegator())
                .from("EmployeePayrollAssignment")
                .where("partyId", context.get("partyId"))
                .queryList();

        Map<String, Object> result = ServiceUtil.returnSuccess();
        result.put("list", list);
        return result;
    }
}
