package org.apache.ofbiz.payroll.services;

import org.apache.ofbiz.base.util.Debug;
import org.apache.ofbiz.base.util.UtilDateTime;
import org.apache.ofbiz.base.util.UtilValidate;
import org.apache.ofbiz.entity.Delegator;
import org.apache.ofbiz.entity.GenericEntityException;
import org.apache.ofbiz.entity.GenericValue;
import org.apache.ofbiz.entity.model.ModelEntity;
import org.apache.ofbiz.entity.model.ModelField;
import org.apache.ofbiz.entity.model.ModelFieldType;
import org.apache.ofbiz.entity.transaction.TransactionUtil;
import org.apache.ofbiz.entity.util.EntityQuery;
import org.apache.ofbiz.entity.util.EntityUtilProperties;
import org.apache.ofbiz.service.DispatchContext;
import org.apache.ofbiz.service.ServiceUtil;

import java.util.*;

/**
 * Payroll entity CRUD services.
 * - Generic CRUD methods (createEntity/updateEntity/deleteEntity/findEntity/listEntity)
 * - Thin wrappers per entity: createX/updateX/deleteX/findX/listX
 */
public class PayrollEntityServices {

    public static final String MODULE = PayrollEntityServices.class.getName();

    // ---- Entity whitelist for safety (prevents calling arbitrary entities) ----
    private static final Set<String> ALLOWED_ENTITIES = Set.of(
        "PayrollOrganization",
        "PayrollCurrencyRate",
        "PayrollStructure",
        "EmployeePayrollAssignment",
        "InternationalEmployeeInfo",
        "OvertimePolicy",
        "HrPolicySet",
        "HrPolicy",
        "PayrollTaxConfig",
        "SocialSecurityConfig",
        "EmployeeTaxProfile",
        "AllowanceType",
        "EmployeeAllowance",
        "DeductionType",
        "EmployeeDeduction",
        "EmployeeLoan",
        "LoanInstallment",
        "PayrollPeriod",
        "PayrollRun",
        "EmployeePayrollResult",
        "EmployeePayrollResultLine",
        "EmployeeTaxDetail",
        "EmployeeYTDSummary",
        "PayrollExportRequest",
        "PayrollExportFile",
        "PayslipBarcode",
        "PayslipDelivery",
        "PayrollEmailQueue",
        "PayrollSmsQueue",
        "BankTransferConfig",
        "BankTransferBatch",
        "BankTransferBatchLine",
        "PayrollAuditLog",
        "EmployeeDocumentAccess"
    );

    // =========================================================
    // Generic CRUD
    // =========================================================

    public static Map<String, Object> createEntity(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();
        Map<String, Object> result = ServiceUtil.returnSuccess();

        String entityName = (String) context.get("entityName");
        Map<String, Object> fields = castMap(context.get("fields"));

        if (!isAllowedEntity(entityName)) {
            return ServiceUtil.returnError("Entity not allowed: " + entityName);
        }
        if (fields == null) {
            return ServiceUtil.returnError("fields map is required");
        }

        boolean beganTx = false;
        try {
            beganTx = TransactionUtil.begin();

            GenericValue value = delegator.makeValue(entityName);
            sanitizeAndSetFields(delegator, entityName, value, fields);

            // Ensure PK present; if not, set first PK with delegator.getNextSeqId(entity)
            setMissingPrimaryKeyIfPossible(delegator, entityName, value);

            value.create();

            // return first PK as recordId (common pattern)
            String recordId = firstPrimaryKeyValue(delegator, entityName, value);
            result.put("recordId", recordId);

            TransactionUtil.commit(beganTx);
            return result;
        } catch (Exception e) {
            TransactionUtil.rollback(beganTx, e.getMessage(), e);
            Debug.logError(e, "createEntity failed for " + entityName, MODULE);
            return ServiceUtil.returnError("createEntity failed for " + entityName + ": " + e.getMessage());
        }
    }

    public static Map<String, Object> updateEntity(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();

        String entityName = (String) context.get("entityName");
        Map<String, Object> pk = castMap(context.get("pk"));
        Map<String, Object> fields = castMap(context.get("fields"));

        if (!isAllowedEntity(entityName)) {
            return ServiceUtil.returnError("Entity not allowed: " + entityName);
        }
        if (pk == null || pk.isEmpty()) {
            return ServiceUtil.returnError("pk map is required");
        }
        if (fields == null) {
            return ServiceUtil.returnError("fields map is required");
        }

        boolean beganTx = false;
        try {
            beganTx = TransactionUtil.begin();

            GenericValue existing = EntityQuery.use(delegator)
                .from(entityName)
                .where(pk)
                .queryOne();

            if (existing == null) {
                return ServiceUtil.returnError("Record not found for update: " + entityName + " pk=" + pk);
            }

            sanitizeAndSetFields(delegator, entityName, existing, fields);
            existing.store();

            TransactionUtil.commit(beganTx);
            return ServiceUtil.returnSuccess();
        } catch (Exception e) {
            TransactionUtil.rollback(beganTx, e.getMessage(), e);
            Debug.logError(e, "updateEntity failed for " + entityName, MODULE);
            return ServiceUtil.returnError("updateEntity failed for " + entityName + ": " + e.getMessage());
        }
    }

    public static Map<String, Object> deleteEntity(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();

        String entityName = (String) context.get("entityName");
        Map<String, Object> pk = castMap(context.get("pk"));

        if (!isAllowedEntity(entityName)) {
            return ServiceUtil.returnError("Entity not allowed: " + entityName);
        }
        if (pk == null || pk.isEmpty()) {
            return ServiceUtil.returnError("pk map is required");
        }

        boolean beganTx = false;
        try {
            beganTx = TransactionUtil.begin();

            GenericValue existing = EntityQuery.use(delegator)
                .from(entityName)
                .where(pk)
                .queryOne();

            if (existing == null) {
                return ServiceUtil.returnError("Record not found for delete: " + entityName + " pk=" + pk);
            }

            existing.remove();
            TransactionUtil.commit(beganTx);
            return ServiceUtil.returnSuccess();
        } catch (Exception e) {
            TransactionUtil.rollback(beganTx, e.getMessage(), e);
            Debug.logError(e, "deleteEntity failed for " + entityName, MODULE);
            return ServiceUtil.returnError("deleteEntity failed for " + entityName + ": " + e.getMessage());
        }
    }

    public static Map<String, Object> findEntity(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();

        String entityName = (String) context.get("entityName");
        Map<String, Object> pk = castMap(context.get("pk"));

        if (!isAllowedEntity(entityName)) {
            return ServiceUtil.returnError("Entity not allowed: " + entityName);
        }
        if (pk == null || pk.isEmpty()) {
            return ServiceUtil.returnError("pk map is required");
        }

        try {
            GenericValue gv = EntityQuery.use(delegator)
                .from(entityName)
                .where(pk)
                .queryOne();

            Map<String, Object> out = ServiceUtil.returnSuccess();
            out.put("record", (gv == null) ? null : gv.getAllFields());
            return out;
        } catch (Exception e) {
            Debug.logError(e, "findEntity failed for " + entityName, MODULE);
            return ServiceUtil.returnError("findEntity failed for " + entityName + ": " + e.getMessage());
        }
    }

    public static Map<String, Object> listEntity(DispatchContext dctx, Map<String, ?> context) {
        Delegator delegator = dctx.getDelegator();

        String entityName = (String) context.get("entityName");
        Map<String, Object> filters = castMap(context.get("filters"));
        List<String> orderBy = castList(context.get("orderBy"));

        Integer viewSize = (Integer) context.get("viewSize");
        Integer viewIndex = (Integer) context.get("viewIndex");

        if (!isAllowedEntity(entityName)) {
            return ServiceUtil.returnError("Entity not allowed: " + entityName);
        }

        try {
            EntityQuery eq = EntityQuery.use(delegator).from(entityName);

            if (filters != null && !filters.isEmpty()) {
                eq = eq.where(filters);
            }
            if (orderBy != null && !orderBy.isEmpty()) {
                eq = eq.orderBy(orderBy);
            }

            // simple pagination
            int size = (viewSize == null || viewSize <= 0) ? 50 : viewSize;
            int index = (viewIndex == null || viewIndex < 0) ? 0 : viewIndex;
            int offset = index * size;

            List<GenericValue> list = eq.queryList();
            int total = list.size();

            List<Map<String, Object>> page = new ArrayList<>();
            for (int i = offset; i < Math.min(offset + size, total); i++) {
                page.add(list.get(i).getAllFields());
            }

            Map<String, Object> out = ServiceUtil.returnSuccess();
            out.put("list", page);
            out.put("listSize", total);
            return out;
        } catch (Exception e) {
            Debug.logError(e, "listEntity failed for " + entityName, MODULE);
            return ServiceUtil.returnError("listEntity failed for " + entityName + ": " + e.getMessage());
        }
    }

    // =========================================================
    // Per-entity wrappers
    // Each wrapper accepts (DispatchContext, context) and calls generic with entityName.
    // In screens/controllers you call: createPayrollRun, listEmployeeDeduction, etc.
    // =========================================================

    // ---- helper to reduce duplication ----
    private static Map<String, Object> createWrap(DispatchContext dctx, Map<String, ?> context, String entityName) {
        Map<String, Object> ctx = new HashMap<>();
        ctx.put("entityName", entityName);
        ctx.put("fields", extractFields(context, entityName));
        return createEntity(dctx, ctx);
    }
    private static Map<String, Object> updateWrap(DispatchContext dctx, Map<String, ?> context, String entityName) {
        Map<String, Object> ctx = new HashMap<>();
        ctx.put("entityName", entityName);
        ctx.put("pk", extractPk(context, dctx.getDelegator(), entityName));
        ctx.put("fields", extractFields(context, entityName));
        return updateEntity(dctx, ctx);
    }
    private static Map<String, Object> deleteWrap(DispatchContext dctx, Map<String, ?> context, String entityName) {
        Map<String, Object> ctx = new HashMap<>();
        ctx.put("entityName", entityName);
        ctx.put("pk", extractPk(context, dctx.getDelegator(), entityName));
        return deleteEntity(dctx, ctx);
    }
    private static Map<String, Object> findWrap(DispatchContext dctx, Map<String, ?> context, String entityName) {
        Map<String, Object> ctx = new HashMap<>();
        ctx.put("entityName", entityName);
        ctx.put("pk", extractPk(context, dctx.getDelegator(), entityName));
        return findEntity(dctx, ctx);
    }
    private static Map<String, Object> listWrap(DispatchContext dctx, Map<String, ?> context, String entityName) {
        Map<String, Object> ctx = new HashMap<>();
        ctx.put("entityName", entityName);
        ctx.put("filters", extractFilters(context, entityName));
        ctx.put("orderBy", context.get("orderBy"));
        ctx.put("viewSize", context.get("viewSize"));
        ctx.put("viewIndex", context.get("viewIndex"));
        return listEntity(dctx, ctx);
    }

    // ===== AUTO-GENERATED WRAPPERS (one block per entity) =====
    public static Map<String, Object> createPayrollOrganization(DispatchContext dctx, Map<String, ?> context) { return createWrap(dctx, context, "PayrollOrganization"); }
    public static Map<String, Object> updatePayrollOrganization(DispatchContext dctx, Map<String, ?> context) { return updateWrap(dctx, context, "PayrollOrganization"); }
    public static Map<String, Object> deletePayrollOrganization(DispatchContext dctx, Map<String, ?> context) { return deleteWrap(dctx, context, "PayrollOrganization"); }
    public static Map<String, Object> findPayrollOrganization(DispatchContext dctx, Map<String, ?> context) { return findWrap(dctx, context, "PayrollOrganization"); }
    public static Map<String, Object> listPayrollOrganization(DispatchContext dctx, Map<String, ?> context) { return listWrap(dctx, context, "PayrollOrganization"); }

    public static Map<String, Object> createPayrollCurrencyRate(DispatchContext dctx, Map<String, ?> context) { return createWrap(dctx, context, "PayrollCurrencyRate"); }
    public static Map<String, Object> updatePayrollCurrencyRate(DispatchContext dctx, Map<String, ?> context) { return updateWrap(dctx, context, "PayrollCurrencyRate"); }
    public static Map<String, Object> deletePayrollCurrencyRate(DispatchContext dctx, Map<String, ?> context) { return deleteWrap(dctx, context, "PayrollCurrencyRate"); }
    public static Map<String, Object> findPayrollCurrencyRate(DispatchContext dctx, Map<String, ?> context) { return findWrap(dctx, context, "PayrollCurrencyRate"); }
    public static Map<String, Object> listPayrollCurrencyRate(DispatchContext dctx, Map<String, ?> context) { return listWrap(dctx, context, "PayrollCurrencyRate"); }

    public static Map<String, Object> createPayrollStructure(DispatchContext dctx, Map<String, ?> context) { return createWrap(dctx, context, "PayrollStructure"); }
    public static Map<String, Object> updatePayrollStructure(DispatchContext dctx, Map<String, ?> context) { return updateWrap(dctx, context, "PayrollStructure"); }
    public static Map<String, Object> deletePayrollStructure(DispatchContext dctx, Map<String, ?> context) { return deleteWrap(dctx, context, "PayrollStructure"); }
    public static Map<String, Object> findPayrollStructure(DispatchContext dctx, Map<String, ?> context) { return findWrap(dctx, context, "PayrollStructure"); }
    public static Map<String, Object> listPayrollStructure(DispatchContext dctx, Map<String, ?> context) { return listWrap(dctx, context, "PayrollStructure"); }

    public static Map<String, Object> createEmployeePayrollAssignment(DispatchContext dctx, Map<String, ?> context) { return createWrap(dctx, context, "EmployeePayrollAssignment"); }
    public static Map<String, Object> updateEmployeePayrollAssignment(DispatchContext dctx, Map<String, ?> context) { return updateWrap(dctx, context, "EmployeePayrollAssignment"); }
    public static Map<String, Object> deleteEmployeePayrollAssignment(DispatchContext dctx, Map<String, ?> context) { return deleteWrap(dctx, context, "EmployeePayrollAssignment"); }
    public static Map<String, Object> findEmployeePayrollAssignment(DispatchContext dctx, Map<String, ?> context) { return findWrap(dctx, context, "EmployeePayrollAssignment"); }
    public static Map<String, Object> listEmployeePayrollAssignment(DispatchContext dctx, Map<String, ?> context) { return listWrap(dctx, context, "EmployeePayrollAssignment"); }

    public static Map<String, Object> createInternationalEmployeeInfo(DispatchContext dctx, Map<String, ?> context) { return createWrap(dctx, context, "InternationalEmployeeInfo"); }
    public static Map<String, Object> updateInternationalEmployeeInfo(DispatchContext dctx, Map<String, ?> context) { return updateWrap(dctx, context, "InternationalEmployeeInfo"); }
    public static Map<String, Object> deleteInternationalEmployeeInfo(DispatchContext dctx, Map<String, ?> context) { return deleteWrap(dctx, context, "InternationalEmployeeInfo"); }
    public static Map<String, Object> findInternationalEmployeeInfo(DispatchContext dctx, Map<String, ?> context) { return findWrap(dctx, context, "InternationalEmployeeInfo"); }
    public static Map<String, Object> listInternationalEmployeeInfo(DispatchContext dctx, Map<String, ?> context) { return listWrap(dctx, context, "InternationalEmployeeInfo"); }

    public static Map<String, Object> createOvertimePolicy(DispatchContext dctx, Map<String, ?> context) { return createWrap(dctx, context, "OvertimePolicy"); }
    public static Map<String, Object> updateOvertimePolicy(DispatchContext dctx, Map<String, ?> context) { return updateWrap(dctx, context, "OvertimePolicy"); }
    public static Map<String, Object> deleteOvertimePolicy(DispatchContext dctx, Map<String, ?> context) { return deleteWrap(dctx, context, "OvertimePolicy"); }
    public static Map<String, Object> findOvertimePolicy(DispatchContext dctx, Map<String, ?> context) { return findWrap(dctx, context, "OvertimePolicy"); }
    public static Map<String, Object> listOvertimePolicy(DispatchContext dctx, Map<String, ?> context) { return listWrap(dctx, context, "OvertimePolicy"); }

    public static Map<String, Object> createHrPolicySet(DispatchContext dctx, Map<String, ?> context) { return createWrap(dctx, context, "HrPolicySet"); }
    public static Map<String, Object> updateHrPolicySet(DispatchContext dctx, Map<String, ?> context) { return updateWrap(dctx, context, "HrPolicySet"); }
    public static Map<String, Object> deleteHrPolicySet(DispatchContext dctx, Map<String, ?> context) { return deleteWrap(dctx, context, "HrPolicySet"); }
    public static Map<String, Object> findHrPolicySet(DispatchContext dctx, Map<String, ?> context) { return findWrap(dctx, context, "HrPolicySet"); }
    public static Map<String, Object> listHrPolicySet(DispatchContext dctx, Map<String, ?> context) { return listWrap(dctx, context, "HrPolicySet"); }

    public static Map<String, Object> createHrPolicy(DispatchContext dctx, Map<String, ?> context) { return createWrap(dctx, context, "HrPolicy"); }
    public static Map<String, Object> updateHrPolicy(DispatchContext dctx, Map<String, ?> context) { return updateWrap(dctx, context, "HrPolicy"); }
    public static Map<String, Object> deleteHrPolicy(DispatchContext dctx, Map<String, ?> context) { return deleteWrap(dctx, context, "HrPolicy"); }
    public static Map<String, Object> findHrPolicy(DispatchContext dctx, Map<String, ?> context) { return findWrap(dctx, context, "HrPolicy"); }
    public static Map<String, Object> listHrPolicy(DispatchContext dctx, Map<String, ?> context) { return listWrap(dctx, context, "HrPolicy"); }

    public static Map<String, Object> createPayrollTaxConfig(DispatchContext dctx, Map<String, ?> context) { return createWrap(dctx, context, "PayrollTaxConfig"); }
    public static Map<String, Object> updatePayrollTaxConfig(DispatchContext dctx, Map<String, ?> context) { return updateWrap(dctx, context, "PayrollTaxConfig"); }
    public static Map<String, Object> deletePayrollTaxConfig(DispatchContext dctx, Map<String, ?> context) { return deleteWrap(dctx, context, "PayrollTaxConfig"); }
    public static Map<String, Object> findPayrollTaxConfig(DispatchContext dctx, Map<String, ?> context) { return findWrap(dctx, context, "PayrollTaxConfig"); }
    public static Map<String, Object> listPayrollTaxConfig(DispatchContext dctx, Map<String, ?> context) { return listWrap(dctx, context, "PayrollTaxConfig"); }

    public static Map<String, Object> createSocialSecurityConfig(DispatchContext dctx, Map<String, ?> context) { return createWrap(dctx, context, "SocialSecurityConfig"); }
    public static Map<String, Object> updateSocialSecurityConfig(DispatchContext dctx, Map<String, ?> context) { return updateWrap(dctx, context, "SocialSecurityConfig"); }
    public static Map<String, Object> deleteSocialSecurityConfig(DispatchContext dctx, Map<String, ?> context) { return deleteWrap(dctx, context, "SocialSecurityConfig"); }
    public static Map<String, Object> findSocialSecurityConfig(DispatchContext dctx, Map<String, ?> context) { return findWrap(dctx, context, "SocialSecurityConfig"); }
    public static Map<String, Object> listSocialSecurityConfig(DispatchContext dctx, Map<String, ?> context) { return listWrap(dctx, context, "SocialSecurityConfig"); }

    public static Map<String, Object> createEmployeeTaxProfile(DispatchContext dctx, Map<String, ?> context) { return createWrap(dctx, context, "EmployeeTaxProfile"); }
    public static Map<String, Object> updateEmployeeTaxProfile(DispatchContext dctx, Map<String, ?> context) { return updateWrap(dctx, context, "EmployeeTaxProfile"); }
    public static Map<String, Object> deleteEmployeeTaxProfile(DispatchContext dctx, Map<String, ?> context) { return deleteWrap(dctx, context, "EmployeeTaxProfile"); }
    public static Map<String, Object> findEmployeeTaxProfile(DispatchContext dctx, Map<String, ?> context) { return findWrap(dctx, context, "EmployeeTaxProfile"); }
    public static Map<String, Object> listEmployeeTaxProfile(DispatchContext dctx, Map<String, ?> context) { return listWrap(dctx, context, "EmployeeTaxProfile"); }

    public static Map<String, Object> createAllowanceType(DispatchContext dctx, Map<String, ?> context) { return createWrap(dctx, context, "AllowanceType"); }
    public static Map<String, Object> updateAllowanceType(DispatchContext dctx, Map<String, ?> context) { return updateWrap(dctx, context, "AllowanceType"); }
    public static Map<String, Object> deleteAllowanceType(DispatchContext dctx, Map<String, ?> context) { return deleteWrap(dctx, context, "AllowanceType"); }
    public static Map<String, Object> findAllowanceType(DispatchContext dctx, Map<String, ?> context) { return findWrap(dctx, context, "AllowanceType"); }
    public static Map<String, Object> listAllowanceType(DispatchContext dctx, Map<String, ?> context) { return listWrap(dctx, context, "AllowanceType"); }

    public static Map<String, Object> createEmployeeAllowance(DispatchContext dctx, Map<String, ?> context) { return createWrap(dctx, context, "EmployeeAllowance"); }
    public static Map<String, Object> updateEmployeeAllowance(DispatchContext dctx, Map<String, ?> context) { return updateWrap(dctx, context, "EmployeeAllowance"); }
    public static Map<String, Object> deleteEmployeeAllowance(DispatchContext dctx, Map<String, ?> context) { return deleteWrap(dctx, context, "EmployeeAllowance"); }
    public static Map<String, Object> findEmployeeAllowance(DispatchContext dctx, Map<String, ?> context) { return findWrap(dctx, context, "EmployeeAllowance"); }
    public static Map<String, Object> listEmployeeAllowance(DispatchContext dctx, Map<String, ?> context) { return listWrap(dctx, context, "EmployeeAllowance"); }

    public static Map<String, Object> createDeductionType(DispatchContext dctx, Map<String, ?> context) { return createWrap(dctx, context, "DeductionType"); }
    public static Map<String, Object> updateDeductionType(DispatchContext dctx, Map<String, ?> context) { return updateWrap(dctx, context, "DeductionType"); }
    public static Map<String, Object> deleteDeductionType(DispatchContext dctx, Map<String, ?> context) { return deleteWrap(dctx, context, "DeductionType"); }
    public static Map<String, Object> findDeductionType(DispatchContext dctx, Map<String, ?> context) { return findWrap(dctx, context, "DeductionType"); }
    public static Map<String, Object> listDeductionType(DispatchContext dctx, Map<String, ?> context) { return listWrap(dctx, context, "DeductionType"); }

    public static Map<String, Object> createEmployeeDeduction(DispatchContext dctx, Map<String, ?> context) { return createWrap(dctx, context, "EmployeeDeduction"); }
    public static Map<String, Object> updateEmployeeDeduction(DispatchContext dctx, Map<String, ?> context) { return updateWrap(dctx, context, "EmployeeDeduction"); }
    public static Map<String, Object> deleteEmployeeDeduction(DispatchContext dctx, Map<String, ?> context) { return deleteWrap(dctx, context, "EmployeeDeduction"); }
    public static Map<String, Object> findEmployeeDeduction(DispatchContext dctx, Map<String, ?> context) { return findWrap(dctx, context, "EmployeeDeduction"); }
    public static Map<String, Object> listEmployeeDeduction(DispatchContext dctx, Map<String, ?> context) { return listWrap(dctx, context, "EmployeeDeduction"); }

    public static Map<String, Object> createEmployeeLoan(DispatchContext dctx, Map<String, ?> context) { return createWrap(dctx, context, "EmployeeLoan"); }
    public static Map<String, Object> updateEmployeeLoan(DispatchContext dctx, Map<String, ?> context) { return updateWrap(dctx, context, "EmployeeLoan"); }
    public static Map<String, Object> deleteEmployeeLoan(DispatchContext dctx, Map<String, ?> context) { return deleteWrap(dctx, context, "EmployeeLoan"); }
    public static Map<String, Object> findEmployeeLoan(DispatchContext dctx, Map<String, ?> context) { return findWrap(dctx, context, "EmployeeLoan"); }
    public static Map<String, Object> listEmployeeLoan(DispatchContext dctx, Map<String, ?> context) { return listWrap(dctx, context, "EmployeeLoan"); }

    public static Map<String, Object> createLoanInstallment(DispatchContext dctx, Map<String, ?> context) { return createWrap(dctx, context, "LoanInstallment"); }
    public static Map<String, Object> updateLoanInstallment(DispatchContext dctx, Map<String, ?> context) { return updateWrap(dctx, context, "LoanInstallment"); }
    public static Map<String, Object> deleteLoanInstallment(DispatchContext dctx, Map<String, ?> context) { return deleteWrap(dctx, context, "LoanInstallment"); }
    public static Map<String, Object> findLoanInstallment(DispatchContext dctx, Map<String, ?> context) { return findWrap(dctx, context, "LoanInstallment"); }
    public static Map<String, Object> listLoanInstallment(DispatchContext dctx, Map<String, ?> context) { return listWrap(dctx, context, "LoanInstallment"); }

    public static Map<String, Object> createPayrollPeriod(DispatchContext dctx, Map<String, ?> context) { return createWrap(dctx, context, "PayrollPeriod"); }
    public static Map<String, Object> updatePayrollPeriod(DispatchContext dctx, Map<String, ?> context) { return updateWrap(dctx, context, "PayrollPeriod"); }
    public static Map<String, Object> deletePayrollPeriod(DispatchContext dctx, Map<String, ?> context) { return deleteWrap(dctx, context, "PayrollPeriod"); }
    public static Map<String, Object> findPayrollPeriod(DispatchContext dctx, Map<String, ?> context) { return findWrap(dctx, context, "PayrollPeriod"); }
    public static Map<String, Object> listPayrollPeriod(DispatchContext dctx, Map<String, ?> context) { return listWrap(dctx, context, "PayrollPeriod"); }

    public static Map<String, Object> createPayrollRun(DispatchContext dctx, Map<String, ?> context) { return createWrap(dctx, context, "PayrollRun"); }
    public static Map<String, Object> updatePayrollRun(DispatchContext dctx, Map<String, ?> context) { return updateWrap(dctx, context, "PayrollRun"); }
    public static Map<String, Object> deletePayrollRun(DispatchContext dctx, Map<String, ?> context) { return deleteWrap(dctx, context, "PayrollRun"); }
    public static Map<String, Object> findPayrollRun(DispatchContext dctx, Map<String, ?> context) { return findWrap(dctx, context, "PayrollRun"); }
    public static Map<String, Object> listPayrollRun(DispatchContext dctx, Map<String, ?> context) { return listWrap(dctx, context, "PayrollRun"); }

    public static Map<String, Object> createEmployeePayrollResult(DispatchContext dctx, Map<String, ?> context) { return createWrap(dctx, context, "EmployeePayrollResult"); }
    public static Map<String, Object> updateEmployeePayrollResult(DispatchContext dctx, Map<String, ?> context) { return updateWrap(dctx, context, "EmployeePayrollResult"); }
    public static Map<String, Object> deleteEmployeePayrollResult(DispatchContext dctx, Map<String, ?> context) { return deleteWrap(dctx, context, "EmployeePayrollResult"); }
    public static Map<String, Object> findEmployeePayrollResult(DispatchContext dctx, Map<String, ?> context) { return findWrap(dctx, context, "EmployeePayrollResult"); }
    public static Map<String, Object> listEmployeePayrollResult(DispatchContext dctx, Map<String, ?> context) { return listWrap(dctx, context, "EmployeePayrollResult"); }

    public static Map<String, Object> createEmployeePayrollResultLine(DispatchContext dctx, Map<String, ?> context) { return createWrap(dctx, context, "EmployeePayrollResultLine"); }
    public static Map<String, Object> updateEmployeePayrollResultLine(DispatchContext dctx, Map<String, ?> context) { return updateWrap(dctx, context, "EmployeePayrollResultLine"); }
    public static Map<String, Object> deleteEmployeePayrollResultLine(DispatchContext dctx, Map<String, ?> context) { return deleteWrap(dctx, context, "EmployeePayrollResultLine"); }
    public static Map<String, Object> findEmployeePayrollResultLine(DispatchContext dctx, Map<String, ?> context) { return findWrap(dctx, context, "EmployeePayrollResultLine"); }
    public static Map<String, Object> listEmployeePayrollResultLine(DispatchContext dctx, Map<String, ?> context) { return listWrap(dctx, context, "EmployeePayrollResultLine"); }

    public static Map<String, Object> createEmployeeTaxDetail(DispatchContext dctx, Map<String, ?> context) { return createWrap(dctx, context, "EmployeeTaxDetail"); }
    public static Map<String, Object> updateEmployeeTaxDetail(DispatchContext dctx, Map<String, ?> context) { return updateWrap(dctx, context, "EmployeeTaxDetail"); }
    public static Map<String, Object> deleteEmployeeTaxDetail(DispatchContext dctx, Map<String, ?> context) { return deleteWrap(dctx, context, "EmployeeTaxDetail"); }
    public static Map<String, Object> findEmployeeTaxDetail(DispatchContext dctx, Map<String, ?> context) { return findWrap(dctx, context, "EmployeeTaxDetail"); }
    public static Map<String, Object> listEmployeeTaxDetail(DispatchContext dctx, Map<String, ?> context) { return listWrap(dctx, context, "EmployeeTaxDetail"); }

    public static Map<String, Object> createEmployeeYTDSummary(DispatchContext dctx, Map<String, ?> context) { return createWrap(dctx, context, "EmployeeYTDSummary"); }
    public static Map<String, Object> updateEmployeeYTDSummary(DispatchContext dctx, Map<String, ?> context) { return updateWrap(dctx, context, "EmployeeYTDSummary"); }
    public static Map<String, Object> deleteEmployeeYTDSummary(DispatchContext dctx, Map<String, ?> context) { return deleteWrap(dctx, context, "EmployeeYTDSummary"); }
    public static Map<String, Object> findEmployeeYTDSummary(DispatchContext dctx, Map<String, ?> context) { return findWrap(dctx, context, "EmployeeYTDSummary"); }
    public static Map<String, Object> listEmployeeYTDSummary(DispatchContext dctx, Map<String, ?> context) { return listWrap(dctx, context, "EmployeeYTDSummary"); }

    public static Map<String, Object> createPayrollExportRequest(DispatchContext dctx, Map<String, ?> context) { return createWrap(dctx, context, "PayrollExportRequest"); }
    public static Map<String, Object> updatePayrollExportRequest(DispatchContext dctx, Map<String, ?> context) { return updateWrap(dctx, context, "PayrollExportRequest"); }
    public static Map<String, Object> deletePayrollExportRequest(DispatchContext dctx, Map<String, ?> context) { return deleteWrap(dctx, context, "PayrollExportRequest"); }
    public static Map<String, Object> findPayrollExportRequest(DispatchContext dctx, Map<String, ?> context) { return findWrap(dctx, context, "PayrollExportRequest"); }
    public static Map<String, Object> listPayrollExportRequest(DispatchContext dctx, Map<String, ?> context) { return listWrap(dctx, context, "PayrollExportRequest"); }

    public static Map<String, Object> createPayrollExportFile(DispatchContext dctx, Map<String, ?> context) { return createWrap(dctx, context, "PayrollExportFile"); }
    public static Map<String, Object> updatePayrollExportFile(DispatchContext dctx, Map<String, ?> context) { return updateWrap(dctx, context, "PayrollExportFile"); }
    public static Map<String, Object> deletePayrollExportFile(DispatchContext dctx, Map<String, ?> context) { return deleteWrap(dctx, context, "PayrollExportFile"); }
    public static Map<String, Object> findPayrollExportFile(DispatchContext dctx, Map<String, ?> context) { return findWrap(dctx, context, "PayrollExportFile"); }
    public static Map<String, Object> listPayrollExportFile(DispatchContext dctx, Map<String, ?> context) { return listWrap(dctx, context, "PayrollExportFile"); }

    public static Map<String, Object> createPayslipBarcode(DispatchContext dctx, Map<String, ?> context) { return createWrap(dctx, context, "PayslipBarcode"); }
    public static Map<String, Object> updatePayslipBarcode(DispatchContext dctx, Map<String, ?> context) { return updateWrap(dctx, context, "PayslipBarcode"); }
    public static Map<String, Object> deletePayslipBarcode(DispatchContext dctx, Map<String, ?> context) { return deleteWrap(dctx, context, "PayslipBarcode"); }
    public static Map<String, Object> findPayslipBarcode(DispatchContext dctx, Map<String, ?> context) { return findWrap(dctx, context, "PayslipBarcode"); }
    public static Map<String, Object> listPayslipBarcode(DispatchContext dctx, Map<String, ?> context) { return listWrap(dctx, context, "PayslipBarcode"); }

    public static Map<String, Object> createPayslipDelivery(DispatchContext dctx, Map<String, ?> context) { return createWrap(dctx, context, "PayslipDelivery"); }
    public static Map<String, Object> updatePayslipDelivery(DispatchContext dctx, Map<String, ?> context) { return updateWrap(dctx, context, "PayslipDelivery"); }
    public static Map<String, Object> deletePayslipDelivery(DispatchContext dctx, Map<String, ?> context) { return deleteWrap(dctx, context, "PayslipDelivery"); }
    public static Map<String, Object> findPayslipDelivery(DispatchContext dctx, Map<String, ?> context) { return findWrap(dctx, context, "PayslipDelivery"); }
    public static Map<String, Object> listPayslipDelivery(DispatchContext dctx, Map<String, ?> context) { return listWrap(dctx, context, "PayslipDelivery"); }

    public static Map<String, Object> createPayrollEmailQueue(DispatchContext dctx, Map<String, ?> context) { return createWrap(dctx, context, "PayrollEmailQueue"); }
    public static Map<String, Object> updatePayrollEmailQueue(DispatchContext dctx, Map<String, ?> context) { return updateWrap(dctx, context, "PayrollEmailQueue"); }
    public static Map<String, Object> deletePayrollEmailQueue(DispatchContext dctx, Map<String, ?> context) { return deleteWrap(dctx, context, "PayrollEmailQueue"); }
    public static Map<String, Object> findPayrollEmailQueue(DispatchContext dctx, Map<String, ?> context) { return findWrap(dctx, context, "PayrollEmailQueue"); }
    public static Map<String, Object> listPayrollEmailQueue(DispatchContext dctx, Map<String, ?> context) { return listWrap(dctx, context, "PayrollEmailQueue"); }

    public static Map<String, Object> createPayrollSmsQueue(DispatchContext dctx, Map<String, ?> context) { return createWrap(dctx, context, "PayrollSmsQueue"); }
    public static Map<String, Object> updatePayrollSmsQueue(DispatchContext dctx, Map<String, ?> context) { return updateWrap(dctx, context, "PayrollSmsQueue"); }
    public static Map<String, Object> deletePayrollSmsQueue(DispatchContext dctx, Map<String, ?> context) { return deleteWrap(dctx, context, "PayrollSmsQueue"); }
    public static Map<String, Object> findPayrollSmsQueue(DispatchContext dctx, Map<String, ?> context) { return findWrap(dctx, context, "PayrollSmsQueue"); }
    public static Map<String, Object> listPayrollSmsQueue(DispatchContext dctx, Map<String, ?> context) { return listWrap(dctx, context, "PayrollSmsQueue"); }

    public static Map<String, Object> createBankTransferConfig(DispatchContext dctx, Map<String, ?> context) { return createWrap(dctx, context, "BankTransferConfig"); }
    public static Map<String, Object> updateBankTransferConfig(DispatchContext dctx, Map<String, ?> context) { return updateWrap(dctx, context, "BankTransferConfig"); }
    public static Map<String, Object> deleteBankTransferConfig(DispatchContext dctx, Map<String, ?> context) { return deleteWrap(dctx, context, "BankTransferConfig"); }
    public static Map<String, Object> findBankTransferConfig(DispatchContext dctx, Map<String, ?> context) { return findWrap(dctx, context, "BankTransferConfig"); }
    public static Map<String, Object> listBankTransferConfig(DispatchContext dctx, Map<String, ?> context) { return listWrap(dctx, context, "BankTransferConfig"); }

    public static Map<String, Object> createBankTransferBatch(DispatchContext dctx, Map<String, ?> context) { return createWrap(dctx, context, "BankTransferBatch"); }
    public static Map<String, Object> updateBankTransferBatch(DispatchContext dctx, Map<String, ?> context) { return updateWrap(dctx, context, "BankTransferBatch"); }
    public static Map<String, Object> deleteBankTransferBatch(DispatchContext dctx, Map<String, ?> context) { return deleteWrap(dctx, context, "BankTransferBatch"); }
    public static Map<String, Object> findBankTransferBatch(DispatchContext dctx, Map<String, ?> context) { return findWrap(dctx, context, "BankTransferBatch"); }
    public static Map<String, Object> listBankTransferBatch(DispatchContext dctx, Map<String, ?> context) { return listWrap(dctx, context, "BankTransferBatch"); }

    public static Map<String, Object> createBankTransferBatchLine(DispatchContext dctx, Map<String, ?> context) { return createWrap(dctx, context, "BankTransferBatchLine"); }
    public static Map<String, Object> updateBankTransferBatchLine(DispatchContext dctx, Map<String, ?> context) { return updateWrap(dctx, context, "BankTransferBatchLine"); }
    public static Map<String, Object> deleteBankTransferBatchLine(DispatchContext dctx, Map<String, ?> context) { return deleteWrap(dctx, context, "BankTransferBatchLine"); }
    public static Map<String, Object> findBankTransferBatchLine(DispatchContext dctx, Map<String, ?> context) { return findWrap(dctx, context, "BankTransferBatchLine"); }
    public static Map<String, Object> listBankTransferBatchLine(DispatchContext dctx, Map<String, ?> context) { return listWrap(dctx, context, "BankTransferBatchLine"); }

    public static Map<String, Object> createPayrollAuditLog(DispatchContext dctx, Map<String, ?> context) { return createWrap(dctx, context, "PayrollAuditLog"); }
    public static Map<String, Object> findPayrollAuditLog(DispatchContext dctx, Map<String, ?> context) { return findWrap(dctx, context, "PayrollAuditLog"); }
    public static Map<String, Object> listPayrollAuditLog(DispatchContext dctx, Map<String, ?> context) { return listWrap(dctx, context, "PayrollAuditLog"); }

    public static Map<String, Object> createEmployeeDocumentAccess(DispatchContext dctx, Map<String, ?> context) { return createWrap(dctx, context, "EmployeeDocumentAccess"); }
    public static Map<String, Object> findEmployeeDocumentAccess(DispatchContext dctx, Map<String, ?> context) { return findWrap(dctx, context, "EmployeeDocumentAccess"); }
    public static Map<String, Object> listEmployeeDocumentAccess(DispatchContext dctx, Map<String, ?> context) { return listWrap(dctx, context, "EmployeeDocumentAccess"); }

    // =========================================================
    // Internals
    // =========================================================

    private static boolean isAllowedEntity(String entityName) {
        return UtilValidate.isNotEmpty(entityName) && ALLOWED_ENTITIES.contains(entityName);
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> castMap(Object o) {
        if (o == null) return null;
        if (o instanceof Map) return (Map<String, Object>) o;
        return null;
    }

    @SuppressWarnings("unchecked")
    private static List<String> castList(Object o) {
        if (o == null) return null;
        if (o instanceof List) return (List<String>) o;
        return null;
    }

    private static void sanitizeAndSetFields(Delegator delegator, String entityName, GenericValue target, Map<String, Object> fields)
        throws GenericEntityException {

        ModelEntity me = delegator.getModelEntity(entityName);
        for (Map.Entry<String, Object> e : fields.entrySet()) {
            String fieldName = e.getKey();
            if (!me.isField(fieldName)) continue; // ignore unknown
            if (me.getPksByName().containsKey(fieldName) && e.getValue() == null) continue; // don't null PK

            target.set(fieldName, e.getValue());
        }

        // stamp helper: if record has createdDate and it's empty on create
        if (target.get("createdDate") == null && me.isField("createdDate")) {
            target.set("createdDate", UtilDateTime.nowTimestamp());
        }
    }

    private static void setMissingPrimaryKeyIfPossible(Delegator delegator, String entityName, GenericValue value)
        throws GenericEntityException {

        ModelEntity me = delegator.getModelEntity(entityName);
        List<String> pks = me.getPkFieldNames();
        if (pks == null || pks.isEmpty()) return;

        // For this payroll model, PKs are single id in most tables; support that case
        if (pks.size() == 1) {
            String pkField = pks.get(0);
            if (value.get(pkField) == null) {
                value.set(pkField, delegator.getNextSeqId(entityName));
            }
        }
    }

    private static String firstPrimaryKeyValue(Delegator delegator, String entityName, GenericValue value)
        throws GenericEntityException {

        ModelEntity me = delegator.getModelEntity(entityName);
        List<String> pks = me.getPkFieldNames();
        if (pks == null || pks.isEmpty()) return null;
        Object v = value.get(pks.get(0));
        return (v == null) ? null : String.valueOf(v);
    }

    /**
     * Extract only known entity fields from service context.
     * This allows calling services directly with normal parameters (no "fields" map needed).
     */
    private static Map<String, Object> extractFields(Map<String, ?> context, String entityName) {
        Map<String, Object> out = new HashMap<>();
        // if caller already provided fields map, accept it
        Object fieldsObj = context.get("fields");
        if (fieldsObj instanceof Map) {
            out.putAll(castMap(fieldsObj));
            return out;
        }
        // else: read all params and later sanitize by entity model
        for (Map.Entry<String, ?> e : context.entrySet()) {
            String k = e.getKey();
            if ("userLogin".equals(k) || "locale".equals(k) || "timeZone".equals(k) ||
                "entityName".equals(k) || "pk".equals(k) || "filters".equals(k) ||
                "orderBy".equals(k) || "viewSize".equals(k) || "viewIndex".equals(k)) {
                continue;
            }
            out.put(k, e.getValue());
        }
        return out;
    }

    private static Map<String, Object> extractPk(Map<String, ?> context, Delegator delegator, String entityName) {
        Object pkObj = context.get("pk");
        if (pkObj instanceof Map) return castMap(pkObj);

        Map<String, Object> pk = new HashMap<>();
        try {
            ModelEntity me = delegator.getModelEntity(entityName);
            for (String pkField : me.getPkFieldNames()) {
                Object v = context.get(pkField);
                if (v != null) pk.put(pkField, v);
            }
        } catch (Exception ignored) { }
        return pk;
    }

    private static Map<String, Object> extractFilters(Map<String, ?> context, String entityName) {
        Object filtersObj = context.get("filters");
        if (filtersObj instanceof Map) return castMap(filtersObj);

        // common list filters pattern: allow passing orgPartyId, statusId, partyId, payrollRunId, payrollPeriodId
        Map<String, Object> filters = new HashMap<>();
        for (String k : List.of("orgPartyId","statusId","partyId","payrollRunId","payrollPeriodId","payrollStructureId")) {
            if (context.get(k) != null) filters.put(k, context.get(k));
        }
        return filters.isEmpty() ? null : filters;
    }
}
